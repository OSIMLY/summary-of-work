// 引入console组件
const Console = resolve => require(['src/views/console/console.vue'], resolve)
//交付模块
const PageDeliveryTemplateBase = resolve => require(['src/views/m-delivery/schedule-template/template-base.vue'], resolve)
const PageDeliveryTemplateDetail = resolve => require(['src/views/m-delivery/schedule-template/template-detail.vue'], resolve)
const PageDeliveryTemplateRef = resolve => require(['src/views/m-delivery/schedule-template/showRef.vue'], resolve)
const PageDeliveryNodeAttribute = resolve => require(['src/views/m-delivery/schedule-template/node-attribute.vue'], resolve)

const routes = [
    //交付
    {
        path: '/delivery',
        component: Console,
        children: [
            { path: '', redirect: 'template-base'},
            { path: 'template-base', component: PageDeliveryTemplateBase},
            { path: 'template-detail', components: { default: PageDeliveryTemplateBase, popView: PageDeliveryTemplateDetail } },
            { path: 'node-attribute',components: { default: PageDeliveryTemplateDetail, popView: PageDeliveryNodeAttribute } },
            { path: 'template-ref', components:{ default: PageDeliveryTemplateBase, popView: PageDeliveryTemplateRef }}
        ]
    }
]

export default routes
