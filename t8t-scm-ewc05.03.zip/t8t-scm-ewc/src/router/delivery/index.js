import delivery from './delivery.js'

let routes = [].concat(
    delivery
)

export default routes
