// 引入console组件
const Console = resolve => require(['src/views/console/console.vue'], resolve)
// 组织架构
const PageOrganization = resolve => require(['src/components/page-organization/page-organization.vue'], resolve)
// 树demo
const Tree = resolve => require(['src/components/t8t-tree/tree-demo.vue'], resolve)

const routes = [
    // 系统管理
    {
        path: '/console',
        component: Console,
        children: [
            { path: 'page-organization', component: PageOrganization }
        ]
    },
    {
        path: '/system',
        component: Console,
        children: [
            { path: 'organization', component: PageOrganization }
        ]
    },
    {
        path: '/system',
        component: Console,
        children: [
            { path: 'tree', component: Tree }
        ]
    },
]

export default routes
