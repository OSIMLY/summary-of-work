import organization from './organization.js'

let routes = [].concat(
    organization
)

export default routes
