// 引入console组件
const Console = resolve => require(['src/views/console/console.vue'], resolve)

// 银行主数据
const PageBankBasedata = resolve => require(['src/views/m-finance/page-bank-basedata/index.vue'], resolve)
const PageBankBasedataView = resolve => require(['src/views/m-finance/page-bank-basedata/view-dialog.vue'], resolve)

const routes = [{
    path: '/finance',
    component: Console,
    children: [
        { path: 'basedata', component: PageBankBasedata },
        { path: 'basedata/view', components: { default: PageBankBasedata, popView: PageBankBasedataView } }
    ]
}]

export default routes
