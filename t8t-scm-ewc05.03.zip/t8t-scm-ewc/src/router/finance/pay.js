// 引入console组件
const Console = resolve => require(['src/views/console/console.vue'], resolve)

// 收款单与配置合在一起
const PagePayMethods = resolve => require(['src/views/m-finance/page-pay-methods/page-pay-methods.vue'], resolve)
const PagePayType = resolve => require(['src/views/m-finance/page-pay-type/page-pay-type.vue'], resolve)
const PagePayPurpose = resolve => require(['src/views/m-finance/page-pay-purpose/page-pay-purpose.vue'], resolve)
const PagePaymentMethodConfig = resolve => require(['src/views/m-finance/page-payment-method-config/page-payment-method-config.vue'], resolve)
const PagePaymentTypeConfig = resolve => require(['src/views/m-finance/page-payment-type-config/page-payment-type-config.vue'], resolve)
const PagePaymentMethodDistribution = resolve => require(['src/views/m-finance/page-payment-method-distribution/page-payment-method-distribution.vue'], resolve)
const pagePayRemit = resolve => require(['src/views/m-finance/page-pay-remit/page-pay-remit.vue'], resolve)
const PagePayRemitView = resolve => require(['src/views/m-finance/page-pay-remit/dialogEdit.vue'], resolve)
const PagePayRemitCreate = resolve => require(['src/views/m-finance/page-pay-remit/dialog.vue'], resolve)
const PagePayMethodsAllot = resolve => require(['src/views/m-finance/page-pay-methods-allot/page-pay-methods-allot.vue'], resolve)
const PagePayPlan = resolve => require(['src/views/m-finance/page-pay-plan/page-pay-plan.vue'], resolve)
const PagePayBills = resolve => require(['src/views/m-finance/page-pay-bills/page-pay-bills.vue'], resolve)
const PageVerifyCancelRecord = resolve => require(['src/views/m-finance/page-verify-cancel-record/page-verify-cancel-record.vue'], resolve)
const PagePayBillsCreate = resolve => require(['src/views/m-finance/page-pay-bills/dialog.vue'], resolve)
const PagePayBillsVerify = resolve => require(['src/views/m-finance/page-pay-bills/dialog-verify.vue'], resolve)
const PagePayPlanPay = resolve => require(['src/views/m-finance/page-pay-plan/dialog-pay.vue'], resolve)
const PagePayPlanSee = resolve => require(['src/views/m-finance/page-pay-plan/dialog-see.vue'], resolve)
const PageVerifyCancelRecordSee = resolve => require(['src/views/m-finance/page-verify-cancel-record/dialog-see.vue'], resolve)
const PagePayBillsUpdate = resolve => require(['src/views/m-finance/page-pay-bills/dialogEdit.vue'], resolve)
const PagePayBillsView = resolve => require(['src/views/m-finance/page-pay-bills/dialogEdit-VIEW.vue'], resolve)

const routes = [{
    path: '/finance',
    component: Console,
    children: [
        { path: 'page-pay-methods', component: PagePayMethods },
        { path: 'page-pay-type', component: PagePayType },
        { path: 'page-pay-purpose', component: PagePayPurpose },
        { path: 'page-payment-method-config', component: PagePaymentMethodConfig },
        { path: 'page-payment-type-config', component: PagePaymentTypeConfig },
        { path: 'page-payment-method-distribution', component: PagePaymentMethodDistribution },
        { path: 'page-pay-remit', component: pagePayRemit },
        { path: 'page-pay-remit/view', components: { default: pagePayRemit, popView: PagePayRemitView } },
        { path: 'page-pay-remit/create', components: { default: pagePayRemit, popView: PagePayRemitCreate } },
        { path: 'page-pay-methods-allot', component: PagePayMethodsAllot },
        { path: 'page-pay-bills', component: PagePayBills },
        { path: 'page-pay-bills/create', components: { default: PagePayBills, popView: PagePayBillsCreate } },
        { path: 'page-pay-bills/update', components: { default: PagePayBills, popView: PagePayBillsUpdate } },
        { path: 'page-pay-bills/verify', components: { default: PagePayBills, popView: PagePayBillsVerify } },
        { path: 'page-pay-bills/view', components: { default: PagePayBills, popView: PagePayBillsView } },
        { path: 'page-pay-plan', component: PagePayPlan },
        { path: 'page-pay-plan/pay', components: { default: PagePayPlan, popView: PagePayPlanPay } },
        { path: 'page-pay-plan/see', components: { default: PagePayPlan, popView: PagePayPlanSee } },
        { path: 'page-verify-cancel-record', component: PageVerifyCancelRecord },
        { path: 'page-verify-cancel-record/see', components: { default: PageVerifyCancelRecord, popView: PageVerifyCancelRecordSee } }
    ]
}]

export default routes
