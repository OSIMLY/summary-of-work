import pay from './pay.js'
import bankBaseData from './bankBaseData.js'

let routes = [].concat(
    pay,
    bankBaseData
)

export default routes
