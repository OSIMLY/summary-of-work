import Vue from 'vue'
import VueRouter from 'vue-router'
import api from 'src/utils/api.js'
import Cookie from 'js-cookie'

Vue.use(VueRouter)
// 判断是否生产环境
const debug = process.env.NODE_ENV !== 'production'

// 登录
import login from './login/index.js'
// 系统管理
import system from './system/index.js'
// 财务
import finance from './finance/index.js'
// workbench工作台
import workbench from './workbench/index.js'
// procenter
import procenter from './procenter/index.js'
// delivery交付
import delivery from './delivery/index.js'

const routes = [].concat(
    login,
    system,
    finance,
    workbench,
    procenter,
    delivery
)

// =========================================================================================
const router = new VueRouter({
    routes
})

router.beforeEach((to, from, next) => {
    // 不需要鉴权页面可以直接跳转
    if (to.meta.auth === false || debug === true) {
        return next()
    }
    // 鉴权页面
    let args = {
        ticket: Cookie.get('t8t-it-ticket'),
        accountId: Cookie.get('t8t-it-uid'),
        url: '#' + to.path
    }

    api.account.checkPermission(args)
        .then((res) => {
            if (res.data.status === 200 && res.data.result === true) {
                next()
            } else {
                Vue.prototype.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '没有权限！',
                    showCancelButton: false,
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    confirmButtonClass: 'is-plain'
                })
            }
        })
        .catch((err) => {
            Vue.prototype.$msgbox({
                title: '消息',
                type: 'warning',
                message: '网络连接失败，路由权限校验失败！',
                showCancelButton: false,
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                confirmButtonClass: 'is-plain'
            })
        })

})

export default router
