// 引入console组件
const Console = resolve => require(['src/views/console/console.vue'], resolve)
//待办任务
const PageProcenterDel = resolve => require(['src/views/m-procenter/page-pro-del/page-pro-del.vue'], resolve)
//已处理任务
const PageProcenterAlready = resolve => require(['src/views/m-procenter/page-pro-already/page-pro-already.vue'], resolve)

const routes = [
    //流程后台管理
    {
        path: '/procenter',
        component: Console,
        children: [
            { path: '', redirect: 'page-pro-del' },
            { path: 'page-pro-del', component: PageProcenterDel },
            { path: 'page-pro-already', component: PageProcenterAlready },
        ]
    }
]

export default routes
