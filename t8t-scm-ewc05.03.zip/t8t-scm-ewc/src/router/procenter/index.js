import procenter from './procenter.js'

let routes = [].concat(
    procenter
)

export default routes
