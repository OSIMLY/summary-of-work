import login from './login.js'

let routes = [].concat(
    login
)

export default routes
