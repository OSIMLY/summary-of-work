const Login = resolve => require(['src/views/login/login.vue'], resolve)

const routes = [
    {
        path: '/',
        redirect: '/login'
    },
    // 登录
    {
        path: '/login',
        meta: { auth: false },
        component: Login,
    },
]

export default routes
