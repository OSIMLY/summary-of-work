import workbench from './workbench.js'

let routes = [].concat(
    workbench
)

export default routes
