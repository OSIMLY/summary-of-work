// 引入console组件
const Console = resolve => require(['src/views/console/console.vue'], resolve)
const WorkBench = resolve => require(['src/views/workbench/workbench.vue'], resolve);

const routes = [
    // 可视化图表
    {
        path: '/workbench',
        component: Console,
        children: [
            { path: 'workbench', component: WorkBench }
        ]
    }
]

export default routes
