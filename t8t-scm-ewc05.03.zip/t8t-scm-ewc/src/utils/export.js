/**
 * Created by Carl.wu on 2017/3/21.
 */

import Config from 'src/config/server.js'
import Cookie from 'js-cookie'

function buildURL(obj) {
    let arr = [
        Config.gatewayAddr,
        encodeURIComponent(obj.service),
        encodeURIComponent(obj.method)
    ]

    let args = obj.args || {}
    args.page = args.page ? args.page : 1
    args.size = args.size ? args.size : 2000

    let _url = arr.join('/')
    let querys = 'action=export&uid=' + Cookie.get('t8t-it-uid') + '&ticket=' + Cookie.get('t8t-it-ticket')
        + '&headers=' + obj.headers + '&args=' + JSON.stringify(args)
        + '&sorts=' + obj.sorts

    _url += ('/?' + querys)

    return _url
}

export default function(obj) {
    let url = buildURL(obj)
    let a = document.createElement('a')
    a.href = url
    a.download = ''
    a.click()
}
