/*
 * @FileName: Utils
 * @Description:
 * @Date: 2017-03-06
 * @version: 1.0
 * @author: <carl.wu@corp.to8to.com>
 */
import Config from 'src/config/server.js'
import Cookie from 'js-cookie'
let Utils = {
    redirectLoginPage() {
        location.href = 'http://erp.to8to.com/index.php/admin/login'
    },
    // 上传url处理
    getUploadURL() {
        let _url = Config.gatewayAddr + '?action=file&uid=' + Cookie.get('t8t-it-uid') + '&ticket=' + Cookie.get('t8t-it-ticket')
        return _url
    },
    // url补全
    getFullURL(src) {
        let _url = Config.gatewayAddr + '?path=' + src + '&action=file&uid=' + Cookie.get('t8t-it-uid') + '&ticket=' + Cookie.get('t8t-it-ticket')
        return _url
    }
}

export default Utils
