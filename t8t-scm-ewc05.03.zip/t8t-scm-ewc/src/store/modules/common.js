import * as types from '../mutation-types'
import api from '../../utils/api'
import Vue from 'vue'
// 表格状态通用模块
const state = {
    search: {},
    //服务方法设置
    requireCfg: {
        service: 'organization',
        method: 'query'
    },
    // 表格数据源
    tableData: [],
    // 表格状态
    tableStatus: {
        // 视图状态
        viewStatus: {
            // 显示‘正在加载’层
            isLoading: true,
            // 显示内嵌编辑器
            isEditable: false,
            // 当前行
            currentRow: {},
            // 当前行序号
            currentIndex: 0,
            // 选中行
            selectedRows: []
        },
        // 分页状态
        pageStatus: {
            // 当前页码
            currentPage: 1,
            // 总页数（需要根据网关返回结果设置此项）
            totalPages: 0,
            // 每页显示条数
            pageSize: 20,
        },
        // 排序状态
        sortStatus: [],
        // 筛选状态
        filterStatus: {
            "id_gt": 0
        }
    }
}
//getters
const getters = {
    // 用于生成网关请求参数
    // 每次请求会同时携带分页、排序和搜索参数
    comArgs: state => {
        let queryArgs = {
            //分页
            "page": state.tableStatus.pageStatus.currentPage,
            "size": state.tableStatus.pageStatus.pageSize,
            //排序
            "sort": state.tableStatus.sortStatus
        }
        //搜索
        if (Object.keys(state.search).length !== 0) {
            queryArgs = Object.assign({}, queryArgs, state.search)
        }
        return queryArgs
    }
}
//actions
const actions = {
    //加载数据表数据
    comLoadTableData(context) {
        //显示正在加载
        context.commit(types.COM_SET_TAB_VIEW_ISLOADING, true)
        api[state.requireCfg.service][state.requireCfg.method](context.getters.comArgs)
            .then((res) => {
                if (res.data.status === 200) {
                    context.commit(types.COM_SET_TABLEDATA, res.data.result.rows)
                    context.commit(types.COM_SET_TAB_PAGE_TOTAL, res.data.result.total)
                    //隐藏正在加载
                    context.commit(types.COM_SET_TAB_VIEW_ISLOADING, false)
                }
            })
    }
}
//mutations
const mutations = {
    // 设置搜索参数，更新表格数据之前，可由子模块为此参数赋值
    [types.COM_SET_SEARCH](state, search) {
        state.search = search
        window.console.log("qqq",state.search)
    },
    //设置数据表数据
    [types.COM_SET_TABLEDATA](state, data) {
        state.tableData = data
    },
    //设置数据行
    [types.COM_SET_TAB_ROW](state, data) {
        Vue.set(state.tableData, data.index, data.value)
    },
    //添加数据行
    [types.COM_ADD_TAB_ROW](state, data) {
        state.tableData.unshift(data)
    },
    //删除数据行，data为id数组
    [types.COM_DEL_TAB_ROW](state, data) {
        for (let i = state.tableData.length - 1; i >= 0; i--) {
            if (data.indexOf(state.tableData[i].id) !== -1) {
                state.tableData.splice(i, 1)
            }
        }
    },
    //设置数据表状态
    [types.COM_SET_TABLESTATUS](state, data) {
        state.tableStatus = data
    },
    //设置数据表显示状态
    [types.COM_SET_TAB_VIEW](state, data) {
        if (data instanceof Array) {
            data.forEach((row) => {
                state.viewStatus[row.key] = row.value
            })
        } else if (typeof data === 'object') {
            state.viewStatus[data.key] = data.value
        }
    },
    //设置正在加载层显示状态
    [types.COM_SET_TAB_VIEW_ISLOADING](state, data) {
        state.tableStatus.viewStatus.isLoading = data
    },
    //设置数据表可编辑状态
    [types.COM_SET_TAB_VIEW_ISEDITABLE](state, data) {
        state.tableStatus.viewStatus.isEditable = data
    },
    //设置当前行
    [types.COM_SET_TAB_VIEW_CURRENTROW](state, data) {
        state.tableStatus.viewStatus.currentRow = data
    },
    //设置当前行序号
    [types.COM_SET_TAB_VIEW_CURRENTINDEX](state, data) {
        state.tableStatus.viewStatus.currentIndex = data
    },
    //设置选中的行
    [types.COM_SET_TAB_VIEW_SELECTEDROWS](state, data) {
        state.tableStatus.viewStatus.selectedRows = data
    },
    //设置分页信息
    [types.COM_SET_TAB_PAGE](state, data) {
        state.tableStatus.pageStatus = data
    },
    //重置分页、排序、筛选信息
    //页码重置为1，每页显示20条，如有其他需求可以追加进来
    [types.COM_RESET_TAB_PSF](state, data) {
        let initPageStatus = {
            currentPage: 1,
            pageSize: 20,
        }
        let initSortStatus = []
        state.tableStatus.pageStatus = initPageStatus
        state.tableStatus.SortStatus = initSortStatus
    },
    //设置当前页
    [types.COM_SET_TAB_PAGE_CURRENTPAGE](state, data) {
        state.tableStatus.pageStatus.currentPage = data
    },
    //设置总页数
    [types.COM_SET_TAB_PAGE_TOTAL](state, data) {
        state.tableStatus.pageStatus.totalPages = data
    },
    //设置每页显示行数
    [types.COM_SET_TAB_PAGE_PAGESIZE](state, data) {
        state.tableStatus.pageStatus.pageSize = data
    },
    //设置排序方式
    [types.COM_SET_TAB_SORT](state, data) {
        state.tableStatus.sortStatus = data
    },
    //设置筛选方式
    [types.COM_SET_TAB_FILTER](state, data) {
        state.tableStatus.filterStatus = data
    },
    //设置load表单请求服务方法requireCfg
     [types.COM_SET_REQUIRECFG](state, data) {
        state.requireCfg = data
    },
}
export default {
    state,
    getters,
    actions,
    mutations
}
