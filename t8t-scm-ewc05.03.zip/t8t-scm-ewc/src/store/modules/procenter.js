import * as types from '../mutation-types'
import api from '../../utils/api'
import Vue from 'vue'
// initial state
const state = {
    search: {
        name_like: null,
        typeCode: null,
        functionCode: null,
        isDel: null
    },
    treeData: [],
    commonData: {
        isDel: [{
            text: '已禁用',
            value: 1
        }, {
            text: '已启用',
            value: 0
        }],
        contactUser: [{
            text: 'Lanbert.zhang',
            value: 1000
        }, {
            text: 'lily.lee',
            value: 0
        }]
    },
    typeCodeOptions: [],
    functionCodeOptions: [],
    tableData: [],
    tableStatus: {
        viewStatus: {
            isLoading: true,
            isEditable: false,
            currentRow: {},
            currentIndex: 0,
            SelectedRows: [],
            SelectedRow: {},
            SelectedIndex: 0
        },
        pageStatus: {
            currentPage: 1,
            totalPages: 0,
            pageSize: 20,
            pageCount: 0
        },
        sortStatus: [],
        filterStatus: {
            "id_gt": 0
        }
    },
    dialogStatus: {
        isShow: false,
        status: 'retrieve'
    }
}

// getters
const getters = {
    search: state => state.search,
    Args: state => {
        let queryArgs = {
            //分页
            "page": state.tableStatus.pageStatus.currentPage,
            "size": state.tableStatus.pageStatus.pageSize,
            //排序
            "sort": state.tableStatus.sortStatus,
            //搜索
            "search": {
                "name_like": state.search.name_like,
                "typeCode": state.search.typeCode,
                "functionCode": state.search.functionCode,
                "isDel": state.search.isDel
            }
        }
        return queryArgs
    }
}

// actions
const actions = {
    resetOrganization({ commit }, data) {
        commit(types.SET_SEARCH, data);
    },
    getConfigData({ commit }) {
        api.allSystemCode.list(
            {
                "fatherCode": "001003"
            })
            .then((res) => {
                if (res.data.status === 200) {
                    commit(types.SET_TYPECODEOPTIONS, res.data.result)
                }
            });
        api.allSystemCode.list(
            {
                "fatherCode": "001004"
            })
            .then((res) => {
                if (res.data.status === 200) {
                    commit(types.SET_FUNCTIONCODEOPTIONS, res.data.result)
                }
            });
    },
    proTreeData({ commit }, payload) {
        api.organization.queryTree(payload)
            .then((res) => {
                if (res.data.status === 200) {
                    commit(types.SET_TREEDATA, res.data.result)
                }
            });
    },
    //加载数据表数据
    loadTableData1(context) {
        //显示正在加载
        context.commit(types.SET_TAB_VIEW_ISLOADING, true)
        api.organization.query(context.getters.Args)
            .then((res) => {
                if (res.data.status === 200) {
                    context.commit(types.SET_TABLEDATA, res.data.result.rows)
                    context.commit(types.SET_TAB_PAGE_TOTAL, res.data.result.total)
                    //隐藏正在加载
                    context.commit(types.SET_TAB_VIEW_ISLOADING, false)
                }
            })
    }
}

// mutations
const mutations = {
    [types.SET_SEARCH](state, search) {
        state.search = search
    },
    [types.SET_TREEDATA](state, data) {
        state.treeData.push(data)
    },
    [types.SET_TYPECODEOPTIONS](state, data) {
        state.typeCodeOptions = data.rows
    },
    [types.SET_FUNCTIONCODEOPTIONS](state, data) {
        state.functionCodeOptions = data.rows
    },
    //设置数据表数据
    [types.SET_TABLEDATA](state, data) {
        state.tableData = data
    },
    //设置数据行
    [types.SET_TAB_DATA_ROW](state, data) {
        Vue.set(state.tableData, data.index, data.value)
    },
    //添加数据行
    [types.ADD_TAB_DATA_ROW](state, data) {
        state.tableData.unshift(data)
    },
    //删除数据行，data为id数组
    [types.DEL_TAB_DATA_ROW](state, data) {
        for (let i = state.tableData.length - 1; i >= 0; i--) {
            if (data.indexOf(state.tableData[i].id) !== -1) {
                state.tableData.splice(i, 1)
            }
        }
    },
    //设置数据表状态
    [types.SET_TABLESTATUS](state, data) {
        state.tableStatus = data
    },
    //设置数据表显示状态
    [types.SET_TAB_VIEW](state, data) {
        if (data instanceof Array) {
            data.forEach((row) => {
                state.viewStatus[row.key] = row.value
            })
        } else if (typeof data === 'object') {
            state.viewStatus[data.key] = data.value
        }
    },
    //设置正在加载层显示状态
    [types.SET_TAB_VIEW_ISLOADING](state, data) {
        state.tableStatus.viewStatus.isLoading = data
    },
    //设置数据表可编辑状态
    [types.SET_TAB_VIEW_ISEDITABLE](state, data) {
        state.tableStatus.viewStatus.isEditable = data
    },
    //设置当前行
    [types.SET_TAB_VIEW_CURRENTROW](state, data) {
        state.tableStatus.viewStatus.currentRow = data
    },
    //设置当前行序号
    [types.SET_TAB_VIEW_CURRENTINDEX](state, data) {
        state.tableStatus.viewStatus.currentIndex = data
    },
    //设置分页信息
    [types.SET_TAB_PAGE](state, data) {
        state.tableStatus.pageStatus = data
    },
    //重置分页、排序、筛选信息
    [types.RESET_TAB_PSF](state, data) {
        let initPageStatus = {
            currentPage: 1,
            pageSize: 20,
        }
        let initSortStatus = []
        state.tableStatus.pageStatus = initPageStatus
        state.tableStatus.SortStatus = initSortStatus
    },
    //设置当前页
    [types.SET_TAB_PAGE_CURRENTPAGE](state, data) {
        state.tableStatus.pageStatus.currentPage = data
    },
    //设置总页数
    [types.SET_TAB_PAGE_TOTAL](state, data) {
        state.tableStatus.pageStatus.totalPages = data
    },
    //设置每页显示行数
    [types.SET_TAB_PAGE_PAGESIZE](state, data) {
        state.tableStatus.pageStatus.pageSize = data
    },
    //设置排序方式
    [types.SET_TAB_SORT](state, data) {
        state.tableStatus.sortStatus = data
    },
    //设置筛选方式
    [types.SET_TAB_FILTER](state, data) {
        state.tableStatus.filterStatus = data
    },
    //dialog
    [types.INIT_DIALOG](state, data) {
        state.dialogStatus.isShow = data.isShow
        state.dialogStatus.status = data.status
    },
    [types.SET_DIALOG_STATUS_ISSHOW](state, data) {
        state.dialogStatus.isShow = data
    },
    [types.SET_TABLE_SELECTEDROWS](state, data) {
        state.tableStatus.viewStatus.SelectedRows = data
    },
    [types.SET_TABLE_SELECTEDROW](state, data) {
        state.tableStatus.viewStatus.SelectedRow = data.row
        state.tableStatus.viewStatus.SelectedIndex = data.index
    }
}

export default {
    state,
    getters,
    actions,
    mutations
}
