import * as types from '../mutation-types'
import api from '../../utils/api'
import Vue from 'vue'
// 财务配置管理 - 款项用途配置模块
// 初始化状态
const state = {
    // 辅助资料
    commonData: {
        // 业务类型
        businessTypes: [{
            text: '常规',
            value: '1'
        }, {
            text: '特殊',
            value: '2'
        }],
        // 收款对象
        debitObjects: [{
            text: '公司',
            value: 1
        }, {
            text: '业主',
            value: 2
        }],
        // 收款类型
        debitTypes: [{
            text: '现金',
            value: 1
        }, {
            text: '转账',
            value: 2
        }],
        // 状态
        status: [{
            text: '作废',
            value: 0
        }, {
            text: '有效',
            value: 1
        }]
    },
    invalidSuccess: null,
    // 对话框
    dialogStatus: {
        isShow: false,
        status: 'retrieve'
    },
    dialogVisible: false,
    formData: {
        code: '003005',
        name: null,
        organizationCode: null,
        channelType: null,
        status: null,
        createUser: null
    },
    editType: '新增'
}
// getters
const getters = {
}

// actions
const actions = {
    getCommonData({ commit }) {
        api.allSystemCode.list(
            {
                "fatherCode": "001003"
            })
            .then((res) => {
                if (res.data.status === 200) {
                    commit(types.SET_TYPECODEOPTIONS, res.data.result)
                }
            });
    },
    initTreeData({ commit }, payload) {
        api.organization.queryTree(payload)
            .then((res) => {
                if (res.data.status === 200) {
                    commit(types.SET_TREEDATA, res.data.result)
                }
            });
    },
    updatePayMethods({ commit }, formData) {
        //发起请求,提交表单
        api.debitChannel.create({ debitChannel })
            .then((res) => {
                if (res.data.status === 200) {
                    commit(types.PAYMETHODS_SET_DIALOGVISIBLE, false)
                    var editType = state.editType
                    Vue.prototype.$msgbox({
                        title: '消息',
                        type: 'success',
                        message: editType + '成功',
                        showCancelButton: false,
                        confirmButtonText: '知道了',
                        confirmButtonClass: 'is-plain'
                    })
                }
            })
    },
    // 发送作废操作请求并设置返回状态
    invalidPayMethods({ commit }, data) {
        api.debitChannel.queryPage({ data })
            .then((res) => {
                if (res.status.status === 200) {
                    commit(tpyes.PAYMETHODS_SET_INVALIDSUCCESS, true)
                } else {
                    commit(tpyes.PAYMETHODS_SET_INVALIDSUCCESS, false)
                }
            })
    }
}

// mutations
const mutations = {
    //添加、编辑弹窗表单
    [types.PAYMETHODS_SET_DIALOG](state, data) {
        state.formData = data.formData
        state.dialogVisible = true
        state.editType = data.editType
    },
    [types.PAYMETHODS_SET_DIALOGVISIBLE](state, data) {
        state.dialogVisible = data
    },
    //提交设置表单的状态
    [types.PAYMETHODS_SET_DIALOGFORM](state, data) {
        state.formData = data
    },
    //作废操作返回状态
    [types.PAYMETHODS_SET_INVALIDSUCCESS](state, data) {
        state.invalidSuccess = data
    }
}

export default {
    state,
    getters,
    actions,
    mutations
}
