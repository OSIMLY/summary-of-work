// 操作store的state
export const SEARCH = function (state, searchValue) {
    state.searchValue = searchValue.searchValue
}
