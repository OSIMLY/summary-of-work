import Vue from 'vue'
import Vuex from 'vuex'

import * as actions from './actions'
import * as getters from './getters'
import * as mutations from './mutations'
import * as types from './mutation-types'
//通用模块
import common from './modules/common'
//组织机构模块
import organization from './modules/organization'
//支付方式模块
import api from '../utils/api.js'
import Service from '../utils/Service'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'

const store = new Vuex.Store({
    state: {
        sidebarData: [],
    },
    modules: {
        common,
        organization
    },
    mutations: {
        SET_SIDEBARDATA(state, data) {
            state.sidebarData = data
        },
    },
    actions: {
        tree2table({ commit }, payload) {
            api.organization.queryByParentId(payload)
                .then((res) => {
                    if (res.data.status === 200) {
                        commit('SET_TABLEDATA', res.data.result.rows)
                        commit(types.SET_TAB_VIEW_ISLOADING, false)
                    }
                })
                .catch((error) => {
                    console.log(error)
                })
        },
        initSidebarData({ commit }, payload) {
            api.account.listMenuTree(payload)
            .then(res => {
                if (res.data.status === 200) {
                    commit('SET_SIDEBARDATA', res.data.result)
                    return
                }
            })
        }
    }
})

export default store
