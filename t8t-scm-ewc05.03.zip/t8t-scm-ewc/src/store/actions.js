import * as types from './mutation-types'
// 触发mutations
export const search = function ({ commit }) {
    commit(types.SEARCH, {
        searchValue: 'has changed'
    })
}
