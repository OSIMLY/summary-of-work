// 获取store的state方法
export const getSearchValue = function (state) {
    return state.searchValue
}
