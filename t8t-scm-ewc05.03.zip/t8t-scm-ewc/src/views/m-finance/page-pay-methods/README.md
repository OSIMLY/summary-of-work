收款方式配置页
author：allen.yao,jinyu.gao,jiangyin.su
