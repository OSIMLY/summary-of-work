<template>
    <div>
        <el-dialog title="付款方式分配" class="pay-dialog" v-model="dialogVisible" @close="btnCancleClick()">
            <el-form :label-position="labelPosition"
                     :model="formData"
                     :label-width="formLabelWidth"
                     :rules="rules"
                     ref="payForm"
                     @keyup.enter.native="btnOKClick()">
                <el-form-item label="组织" prop="organizationIds">
                    <el-select v-model="formData.organizationIds" multiple :disabled="editable" placeholder="--请选择--" >
                        <el-option v-for="item in organizationList" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="业务类型" prop="businessTypeName">
                    <el-input v-model="formData.businessTypeName" :disabled="true" ></el-input>
                </el-form-item>
                <el-form-item label="付款对象" prop="payObjectName">
                    <el-input v-model="formData.payObjectName" :disabled="true" ></el-input>
                </el-form-item>
                <el-form-item label="付款类型" prop="payTypeId">
                    <el-select v-model="formData.payTypeId" :disabled="editable" placeholder="--请选择--" @change="changePayType">
                        <el-option v-for="item in payTypeList" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="付款主体" prop="payOrganizationName">
                    <el-input v-model="formData.payOrganizationName" :disabled="true"></el-input>
                </el-form-item>
                <el-form-item label="付款方式" prop="payChannelId">
                    <el-select v-model="formData.payChannelId" :disabled="editable" placeholder="--请选择--" @change="changePayMethod">
                        <el-option v-for="item in payChannelList" :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>

            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="btnOKClick()" type="primary" :loading="isLoading">确定</el-button>
                <el-button @click="btnCancleClick()">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
    import * as types from 'src/store/mutation-types.js';
    import Cookie from 'js-cookie';
    import apiPayMethodDistribution from 'src/services/finance/payMethodDistribution.js';
    import apiPayMethodConfig from 'src/services/finance/payMethodConfig.js';
    import apiPayTypeConfig from 'src/services/finance/payTypeConfig.js';
    import apiCommon from 'src/services/commonApi/commonApi.js';
    import * as config from './config';
    export default {
        name: 'pay-dialog',
        data() {
            return {
                labelPosition: 'right',
                formLabelWidth: '120px',
                rules: config.rules,
                //辅助资料配置
                organizationList: [],   // 组织列表
//                businessTypeList: [],   // 业务类型列表
//                payObjectList: [],      // 付款对象列表
                payTypeList: [],      // 付款类型列表
//                payOrganizationList: [],// 付款组织列表
                payChannelList: [],    // 付款方式列表
                //表单
                formData: config.formData,
                isLoading: false
            }
        },
        props: ['rowId','editType'],
        computed: {
            dialogVisible() {
                return true
            },
            editable() {
                return this.editType === 'see'
            }
        },
        created() {
            //请求所选行的数据
            if (this.rowId) {
                var args = {
                    id:this.rowId
                };
                this.loadPayMethodsFormData(args)
            };
            //请求辅助资料配置
            this.getFunOptions(["001004013", "001004014"], 'organizationList');//组织
//            this.getCommonOptions('11008','businessTypeList');//业务类型列表
//            this.getCommonOptions('61004','payObjectList');//付款对象列表
            this.getPayTypeConfigOption('payTypeList');//付款类型列表
//            this.getFunOptions(["001004013"], 'payOrganizationList');//付款组织
            this.getPayMethodConfigOption('payChannelList');//付款方式列表
        },
        methods: {
            changePayMethod(value){
                for(let i = 0; i < this.payChannelList.length;i++) {
                    if (value === this.payChannelList[i].value) {
                        this.formData.payOrganizationName = this.payChannelList[i].payOrganizationName
                    }
                }
            },
            changePayType(value){
                for(let i = 0; i < this.payTypeList.length;i++) {
                    if (value === this.payTypeList[i].value) {
                        this.formData.businessTypeName = this.payTypeList[i].businessTypeName;
                        this.formData.payObjectName = this.payTypeList[i].payObjectName
                    }
                }
            },
            btnOKClick() {
                this.$refs['payForm'].validate(valid=>{
                    if (valid) {
                        var formData = Object.assign({},this.formData)
                        var editType = this.editType
                        formData.organizationIds = formData.organizationIds.toString();
                        if (editType==='add') {
                            this.addPayMethods(formData)
                        }
                        else if (editType==='edit') {
                            formData.updateUser = parseInt(Cookie.get('t8t-it-uid'))
                            this.updatePayMethods(formData)
                        }
                    }
                    else {
                        return false
                    }
                })
            },
            btnCancleClick() {
                this.$refs['payForm'].resetFields();
                this.$emit('close')
            },
            //新增提交
            addPayMethods(formData){
                var channelDistribution = formData;
                this.isLoading = true;
                //发起请求,提交表单
                apiPayMethodDistribution.create({channelDistribution})
                    .then((res) => {
                        if (res.data.status === 200 && res.data.result > 1) {
                            //隐藏正在加载
                            this.isLoading = false;
                            this.$refs['payForm'].resetFields();
                            this.$emit('close');
                            this.$msgbox({
                                title: '消息',
                                type: 'success',
                                message: '新增成功',
                                showCancelButton: false,
                                confirmButtonText: '知道了',
                                confirmButtonClass: 'is-plain'
                            });
                            this.$emit('getTableData')
                        }
                        else {
                            this.isLoading = false;
                            this.$message.error(res.data.message)
                        }
                    })
            },
            //编辑提交
            updatePayMethods(formData) {
                var channelDistribution = formData
                this.isLoading = true
                //发起请求,提交表单
                apiPayMethodDistribution.update({channelDistribution})
                    .then((res) => {
                        if (res.data.status === 200 && res.data.result === 1) {
                            //隐藏正在加载
                            this.isLoading = false
                            this.$refs['payForm'].resetFields();
                            this.$emit('close')
                            this.$msgbox({
                                title: '消息',
                                type: 'success',
                                message: '编辑成功',
                                showCancelButton: false,
                                confirmButtonText: '知道了',
                                confirmButtonClass: 'is-plain'
                            })
                            this.$emit('getTableData')
                        }
                        else {
                            this.isLoading = false;
                            this.$message.error(res.data.message)
                        }
                    })
            },
            //请求弹窗行的数据
            loadPayMethodsFormData(args) {
                apiPayMethodDistribution.findByIdNames(args).then((res) => {
                        if (res.data.status === 200) {
                            var rowData = res.data.result;
                            var organizationIdsArr = rowData.organizationIds.split(',')
                            var organizationIdsInt = [];
                            //字符串数组转化为INT 数组
                            organizationIdsArr.forEach(function(data,index,arr){
                                organizationIdsInt.push(+data)
                            });
                            rowData.organizationIds = organizationIdsInt;
                            this.formData =  rowData
                        }
                    })
            },
            //辅助资料
            getCommonOptions: function(fatherCode,selectName) {
                let arg =  {
                    page: 1,
                    search: {
                        pPropertyCode: fatherCode
                    },
                    size: 100
                }
                let list = []
                apiCommon.queryUnionParent(arg)
                    .then((res) => {
                        if (res.data.status === 200) {
                            res.data.result.forEach((item) => {
                                if (item.propertyStatus===1) {
                                    list.push({
                                        value: item.id,
                                        label: item.propertyName
                                    })
                                };
                            });
                            this[selectName] = list;

                        }
                    })
            },
            //组织职能
            getFunOptions: function(codeArray, selectName) {
                apiCommon.queryByFunctionCode({"funcCodes": codeArray})
                .then((res => {
                    let list = []
                    if (res.data.status === 200) {
                        res.data.result.forEach((item) => {
                            if (item.isDel===0) {
                                list.push({
                                    value: item.id,
                                    label: item.name
                                })
                            };
                        })
                        this[selectName] = list
                    }
                }))
            },
            //可用付款方式
            getPayMethodConfigOption: function (selectName) {
                apiPayMethodConfig.query().then((res => {
                        let list = []
                        if (res.data.status === 200) {
                            res.data.result.forEach((item) => {
                                if (item.status === 1) {
                                    list.push({
                                        value: item.id,
                                        label: item.name,
                                        payOrganizationName: item.organizationName,
                                    })
                                };
                            })
                            this[selectName] = list
                        }
                    }))
            },
            //可用付款类型
            getPayTypeConfigOption: function (selectName) {
                apiPayTypeConfig.query().then((res => {
                    let list = []
                    if (res.data.status === 200) {
                        res.data.result.forEach((item) => {
                            if (item.status === 1) {
                                list.push({
                                    value: item.id,
                                    label: item.name,
                                    businessTypeName: item.businessTypeName,
                                    payObjectName: item.payObjectName,
                                })
                            };
                        })
                        this[selectName] = list
                    }
                }))
            }
        }
    }

</script>

<style lang="css" scoped>
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    .pay-dialog .el-dialog{
        width: 450px;
    }
    .el-select-dropdown__wrap {
        max-height: 185px !important;
    }
    .pay-dialog .el-form-item__content {
        width: 250px;
    }
    .pay-dialog .el-select {
        width: 100%;
    }
</style>
