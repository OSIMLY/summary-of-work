page-pay-methods 收款方式配置
page-pay-type 收款类型配置
page-pay-purpose 款项用途配置
page-pay-methods-distribution 收款方式分配
page-pay-plan 收款计划单
page-pay-bills 收款单
page-verify-cancel-record 核销记录
