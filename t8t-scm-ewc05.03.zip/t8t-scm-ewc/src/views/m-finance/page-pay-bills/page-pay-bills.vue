<template>
    <div class="page-pay-bills">
        <t8t-breadcrumb :data="breadcrumbData"></t8t-breadcrumb>
        <t8t-search
            :fields="fields"
            :selectSource="selectSource"
            @submit="submitSearch"
            >
        </t8t-search>
        <div class="g-main-container-column">
            <t8t-toolbar
                @ADD="onBtn1"
                @VIEW="onBtn2"
                @AUDITING-SUBMIT="onBtn3"
                @ANTI-AUDITING="onBtn4"
                @REJECT="onBtn5"
                @EDIT="onBtn6"
                @ACCEPTANCE="onBtn7"
            >
            </t8t-toolbar>
            <t8t-table
                :columns="columns"
                :service="service"
                :method="method"
                :commonData="selectSource"
                :args="args"
                ref="t8ttable"
                @row-double-click="onView"
            >
                <!--用于自定义列模板-->
                <template slot="verifyStatus" scope="scope">
                    <span
                        v-if="scope.row['verifyStatus']!==3"
                        style="color:red; font-size: 25px"
                    >●</span>
                    <span
                        v-else-if="scope.row['verifyStatus']===3"
                        style="color:green; font-size: 25px"
                    >●</span>
                </template>
                <template slot="receiptVoucherUrl" scope="scope">
                    <el-button type="small" @click.stop="showImgDialog(scope.row['receiptVoucherUrl'])">查看凭证</el-button>
                </template>
            </t8t-table>
        </div>
        <!-- 查看图片弹窗 -->
        <el-dialog v-model="imgDialog" @close="closeImgDialog" ref="imgDialogRef" size="full" class="g-transparent-dialog">
            <div class="g-img-container">
                <img :src="imgSrc" alt="">
            </div>
        </el-dialog>
        <!-- 驳回确认弹窗 -->
        <el-dialog v-model="rejDialog" title="驳回确认" @close="closeRejDialog" ref="rejDialogRef">
            <div class="textarea-container">
                <el-input type="textarea" v-model="textareaText" :autosize="{minRows: 5, maxRows: 5}" placeholder="请输入驳回原因"></el-input>
            </div>
            <div slot="footer">
                <el-button type="primary" @click="onRejBtn">驳回</el-button>
                <el-button @click="closeRejDialog">关闭</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
// import T8tBreadcrumb from 'src/components/t8t-breadcrumb/t8t-breadcrumb.vue'
// import T8tTable from 'src/components/t8t-table/t8t-table.vue'
// import T8tToolbar from 'src/components/t8t-toolbar/t8t-toolbar.vue'
// import T8tSearch from 'src/components/t8t-search/t8t-search.vue'
import commonApi from 'src/services/commonApi/commonApi.js'
import api from 'src/services/finance/bills.js'
import Service from 'src/services/finance/Service.js'
import columns from './indexColumns.json'
import Cookie from 'js-cookie'
import Utils from 'src/utils/Utils.js'
import wkfApi from 'src/services/finance/hello.js'
export default {

    name: 'page-pay-bills',

    data () {
        return {
            rejDialog: false,
            textareaText: '',
            imgDialog: false,
            imgSrc: '',
            breadcrumbData: [{ title: '财务' },{ title: '资金管理' },{ title: '收款单' }],
            columns: columns,
            service: Service.FINA_BILLS.name,
            method: Service.FINA_BILLS.methods.QUERYFLAT,
            args: {
                receiptLeftJoinQueryDTO: {
                    "code": ""
                },
                sort:["id_desc"]
            },

            //搜索表单项配置
            fields: [
                {type: 'input',label: '单据编号',name: 'code'},
                {type: 'select',label: '业务类型',name: 'bizId', selectSourceKey:'bizOptions'},
                {type: 'select',label: '收款类型',name: 'receiptTypeId', selectSourceKey:'receiptTypeOptions'},
                {type: 'input',label: '项目ID',name: 'projectId'},
                {type: 'select',label: '单据状态',name: 'orderStatus', selectSourceKey:'orderStatusOptions'},
                {type: 'select',label: '核销状态',name: 'verifyStatus', selectSourceKey:'verifyStatusOptions'}
            ],
            //搜索select类型下拉列表数据，对应fields的selectSourceKey
            selectSource: {
                bizOptions: [],
                receiptTypeOptions: [],
                orderStatusOptions: [{
                    text: '审核中',
                    value: 1
                },{
                    text: '已审核',
                    value: 2
                },{
                    text: '重新审核',
                    value: 3
                }],
                verifyStatusOptions: [{
                    text: '未核销',
                    value: 1
                },{
                    text: '部分核销',
                    value: 2
                },{
                    text: '已核销',
                    value: 3
                }]
            }
        }
    },
    created() {
        // 业务类型
        this.getCommonOptions('11008','bizOptions')
        // 收款类型
        this.getCommonOptions('61002','receiptTypeOptions')
    },
    watch: {
        $route: function () {
            this.$refs['t8ttable'].reloadTable()
        }
    },
    methods: {
        // 双击查看
        onView() {
            let CurrentRow = this.$refs['t8ttable'].getCurrentRow()
            this.$router.push({ path: 'page-pay-bills/view', query: { id: CurrentRow.receiptOrderId, status: CurrentRow.orderStatus } })
        },
        //新增
        onBtn1() {
            this.$router.push({path: '/finance/page-pay-bills/create'})
        },
        //查看
        onBtn2() {
            // 单行判断
            if (this.checkSelection() === false) return false
            let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
            this.$router.push({ path: 'page-pay-bills/view', query: { id: selectRow.receiptOrderId, status: selectRow.orderStatus } })
        },
        //审核
        onBtn3() {
            // 单行判断
            if(this.checkSelection() === false) return false

            let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
            // 勾选数据不是待审核
            if(selectRow.orderStatus !== 1){
                this.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '审核中状态才能进行审核操作',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                })
                return false
            }else {
                // 待审核状态弹窗确认审核
                this.$confirm('确认将所选收款单审核通过？', '审核确认', {
                        confirmButtonText: '审核',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }
                )
                .then(() => {
                    // 点击确定按钮
                    let args = {
                        "req": {
                            "taskId": selectRow.taskId,
                            "procInsId": selectRow.wkfId,
                            "executor": Cookie.get('t8t-it-uid'),
                            "workflow": {
                                "isPass": true
                            },
                            "biz": {
                                auditorId: +Cookie.get('t8t-it-uid'),
                                receiptOrderId: selectRow.receiptOrderId,
                                auditResult: 1
                            }
                        }
                    }
                    wkfApi.complete(args)
                    .then((res) => {
                        if(res.data.status === 200){
                            // 成功弹窗
                            this.$msgbox({
                                title: '消息',
                                type: 'success',
                                message: '审核成功',
                                showCancelButton: false,
                                confirmButtonText: '知道了',
                                confirmButtonClass: 'is-plain'
                            })
                            this.$refs['t8ttable'].reloadTable()
                        } else {
                            // 失败弹窗
                            this.$msgbox({
                                title: '消息',
                                type: 'error',
                                message: res.data.message,
                                showCancelButton: false,
                                confirmButtonText: '知道了',
                                confirmButtonClass: 'is-plain'
                            })
                        }
                    })
                })
                .catch(() => {
                    // 关闭弹窗
                })
            }

        },
        //反审核
        onBtn4() {
            // 单行判断
            if(this.checkSelection() === false) return false
            let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
            // 勾选数据不是审核通过状态
            if(selectRow.orderStatus !== 2){
                this.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '已审核状态才能进行反审核操作',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                })
                return false
            }
            // 审核通过但不是未核销
            if(selectRow.orderStatus === 2 && selectRow.verifyStatus !==1){
                this.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '未核销状态才能进行反审核操作',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                })
                return false
            }
            // 审核通过并且是未核销 弹窗确认反审核
            this.$confirm('确认将所选收款单反审核通过？', '反审核确认', {
                    confirmButtonText: '反审核',
                    cancelButtonText: '取消',
                    type: 'warning'
                }
            )
            .then(() => {
                // 点击确定按钮
                // let args = {
                //     auditorId: +Cookie.get('t8t-it-uid'),
                //     receiptOrderIds: [selectRow.receiptOrderId]
                // }
                var args = {
                        "req":{
                            "idOrKey":"financeReceiptCheck",
                            "startById":0,
                            "businessKey": ''+selectRow.receiptOrderId,
                            "starter": Cookie.get('t8t-it-uid'),
                            "workflow": {
                                "url": '/biz/t8t-fi-rvm/app',
                                "method": 'receipt.order.anti.audit',
                                "formkey": "http://scm.to8to.com/#/finance/page-pay-bills"
                            },
                            "biz":{
                                auditorId: +Cookie.get('t8t-it-uid'),
                                receiptOrderId: selectRow.receiptOrderId,
                            }
                        }
                    }
                wkfApi.start(args)
                .then((res) => {
                    if(res.data.status === 200){
                        // 反审核通过弹窗
                        this.$msgbox({
                            title: '消息',
                            type: 'success',
                            message: '反审核成功',
                            showCancelButton: false,
                            confirmButtonText: '知道了',
                            confirmButtonClass: 'is-plain'
                        })
                        this.$refs['t8ttable'].reloadTable()
                    }else{
                        // 失败弹窗
                        this.$msgbox({
                            title: '消息',
                            type: 'error',
                            message: res.data.message,
                            showCancelButton: false,
                            confirmButtonText: '知道了',
                            confirmButtonClass: 'is-plain'
                        })
                    }
                })
            })
            .catch(() => {
                // 关闭弹窗
            })
        },
        //驳回
        onBtn5() {
            // 单行判断
            if(this.checkSelection() === false) return false
            let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
            // 不是待审核状态
            if(selectRow.orderStatus !==1){
                this.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '审核中状态才能驳回',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                })
                return false
            }
            // 弹窗驳回确认
            this.rejDialog = true
        },
        //调整
        onBtn6() {
            // 单行判断
            // if (this.checkSelection() === false) return false
            // let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
            // this.$router.push({ path: 'page-pay-bills/update', query: { id: selectRow.receiptOrderId } })
            this.$router.push({path: '/finance/page-pay-bills/create', query: { mode: 'tz' }})
        },
        // 核销
        onBtn7() {
            // 单行判断
            if(this.checkSelection() === false) return false
            let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
            // 非审核通过状态
            if(selectRow.orderStatus !== 2){
                this.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '已审核状态才能进行核销',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                })
                return false
            }
            // 如是审核通过但已核销状态
            if(selectRow.orderStatus === 2 && selectRow.verifyStatus ===3){
                this.$msgbox({
                    title: '消息',
                    type: 'warning',
                    message: '已核销，请选择其它收款单',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                })
                return false
            }
            // 审核通过状态并且非已核销
            this.$router.push({
                path: '/finance/page-pay-bills/verify',
                query: {
                    projectId: selectRow.projectId, receiptRoleId: selectRow.receiptRoleId, receiptorId: selectRow.receiptorId,
                    code: selectRow.code
                }
            })

        },
        checkSelection() {
            let selections = this.$refs['t8ttable'].getSelectRows()
            if(selections.length===0){
                this.$message.error('请勾选收款单后再试。')
                return false
            }else if(selections.length>1){
                this.$message.error('请对单条数据进行操作。')
                return false
            }
            return true
        },
        showImgDialog(src){
            this.imgSrc = Utils.getFullURL(src)
            this.imgDialog = true
        },
        closeImgDialog() {
            this.imgSrc = ''
            this.imgDialog = false
        },
        submitSearch(obj) {
            this.args = { receiptLeftJoinQueryDTO: obj, sort:["id_desc"] }
        },
        getCommonOptions: function(fatherCode,selectName) {
            let arg =  {
                page: 1,
                search: {
                    pPropertyCode: fatherCode
                },
                size: 100
            }
            let list = []
            commonApi.queryUnionParent(arg)
            .then((res) => {
                if (res.data.status === 200) {
                    res.data.result.forEach((item) => {
                        if (item.propertyStatus===1) {
                            list.push({
                                value: item.id,
                                text: item.propertyName
                            })
                        };
                    })
                    this.selectSource[selectName] = list
                }
            })
        },
        onRejBtn(){
            if(this.textareaText===''){
                this.$message.warning('请输入驳回原因')
            }else{
                // 驳回
                let selectRow = this.$refs['t8ttable'].getSelectRows()[0]
                let args = {
                    auditorId: +Cookie.get('t8t-it-uid'),
                    receiptOrderIds: [selectRow.receiptOrderId],
                    remark: this.textareaText
                }
                api.reject(args)
                .then((res) => {
                    if(res.data.status === 200 && res.data.result === 1){
                        // 驳回成功
                        this.$msgbox({
                            title: '消息',
                            type: 'success',
                            message: '驳回成功',
                            showCancelButton: false,
                            confirmButtonText: '知道了',
                            confirmButtonClass: 'is-plain'
                        })
                        this.closeRejDialog()
                        this.$refs['t8ttable'].reloadTable()
                    }else{
                        // 驳回失败
                        this.$msgbox({
                            title: '消息',
                            type: 'error',
                            message: res.data.message,
                            showCancelButton: false,
                            confirmButtonText: '知道了',
                            confirmButtonClass: 'is-plain'
                        })
                        this.closeRejDialog()
                    }
                })
            }
        },
        closeRejDialog() {
            this.rejDialog = false
            this.textareaText = ''
        }
    }
}
</script>

<style
    lang="css"
    scoped
>
    .img-container{
        display: flex;
        justify-content: center;
    }
    .textarea-container{
        margin: 0 30px;
    }
</style>
