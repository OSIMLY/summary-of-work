<template>
    <div class="page-organization">
        <t8t-breadcrumb :data="breadcrumbData"></t8t-breadcrumb>
        <search></search>
        <div class="g-main-container">
            <div class="t8t-tree-container">
                <t8t-basetree :data="treeData"></t8t-basetree>
            </div>
            <el-button @click="onClick">导出</el-button>
            <div class="list-container">
                <t8t-toolbar
                    @VIEW="onView"
                    @EDIT="onEdit"
                    ref="toolbar"
                ></t8t-toolbar>
                <el-button @click="clickon">添加</el-button>
                <t8t-datetime-picker
                    v-model="timeSelect"
                    type="datetime"
                    @change="changeTime"
                    bindValue="1489718139"
                    endFormater="yyyy"
                >
                </t8t-datetime-picker>

                <t8t-table
                    :columns="columns"
                    :service="service"
                    :method="method"
                    :editable="true"
                    ref="table"
                >

                </t8t-table>
            </div>
        </div>
        <t8t-dialog v-if="isShow"></t8t-dialog>
    </div>
</template>

<script>
    import T8tBreadcrumb from '../../components/t8t-breadcrumb/t8t-breadcrumb.vue'
    import T8tDialog from './t8t-dialog.vue'
    import Search from './search.vue'
    import T8tToolbar from '../../components/t8t-toolbar/t8t-toolbar.vue'
    import T8tBasetree from './t8t-tree.vue'
    import axios from 'src/utils/axios.js'
    import exportUtils from 'src/utils/export.js'
    import T8tDivision from 'src/components/t8t-division/index'
    import Perm from 'src/services/permission/Perm.js'
    import options from 'src/components/t8t-division/division.json'
    import BankService from 'src/services/finance/Service.js'
    import T8tDatetimePicker from 'src/components/t8t-form/dateTimePicker.vue'
    import T8tTable from 'src/components/t8t-table/t8t-table.vue'
    import Service from 'src/services/finance/Service.js'

    export default {
        name: 'org-index',
        components: {
            T8tBreadcrumb,
            T8tDialog,
            Search,
            T8tToolbar,
            T8tDivision,
            T8tDatetimePicker,
            T8tTable
        },
        data() {
            return {
                service: Service.FINA_BILLS.name,
                method: Service.FINA_BILLS.methods.QUERYFLAT,
                columns: [
                    { "prop": "verifyStatus", "label": "核销状态" },
                    { "prop": "code", "label": "单据编号" },
                    { "prop": "createTime", "label": "创建时间", formatter: "dateParser",
                        editor: {
                            type: "datetime",
                            endFormater: 'timestamp'
                        }
                    }
                ],
                dfv: null,
                dfv2: null,
                timeSelect: "",
                breadcrumbData: [{
                    title: '系统管理'
                },
                {
                    title: '主数据'
                },
                {
                    title: '组织机构'
                }
                ],
                params: {
                    bucket: 'myfirst',
                    module: 'finance'
                },
                division: "",
                df:"12",
                onS: true,
                options: options,
                haha: []
            }
        },
        computed: {
            treeData() {
                return this.$store.state.organization.treeData
            },
            isShow: {
                get() {
                    return this.$store.state.organization.dialogStatus.isShow
                },
                set(value) {
                    this.status = this.$store.state.organization.dialogStatus.status
                    this.$store.commit('SET_DIALOG_STATUS_ISSHOW', value)
                }
            }
        },
        created() {
            this.$store.dispatch('initTreeData')
            this.$store.dispatch('loadTableData1')
            let that = this
        },
        mounted () {

        },
        methods: {
            clickon () {
//                this.$refs['table'].addNewRow()
                console.log(this.$refs['table'].dataSource[0])
            },
            changeTime (time, time2) {
                console.log(this.timeSelect)
            },
            onchange2(a) {

            },
            onView(symbol, event) {
                this.$refs['toolbar'].disableBySymbol(symbol)
            },
            onEdit() {
                this.df = "130203000000"
            },
            onClick() {
                exportUtils({
                    service: BankService.FINA_BASEDATA.name,
                    method: BankService.FINA_BASEDATA.methods.EXCEL_QUERY,
                    args: this.args,
                    headers: '银行账号,开户支行,银行,创建时间,创建人,是否默认,关联对象,账户对象,状态,账户名称',
                    sorts: "bankAccount,bankBranchName,bankName,createTime,createName,defaultName,openingAccountName,roleTypeName,statusName,userName"
                })
            },
            onChange (value) {

            }
        }
    }

</script>

<style lang="css" scoped>
.list-container{
    display: flex;
    -ms-flex: 1;
    flex: 1;
    -ms-flex-direction: column;
    flex-direction: column;
    overflow: auto;
}
</style>


<style>
</style>
