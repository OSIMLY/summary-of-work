<template>
    <el-dialog title="查看组织" class="organization-dialog" v-model="isShow" size="small">
        <el-form :model="localRow" ref="dialogForm" inline>
            <el-tabs v-model="activePane" type="card">
                <el-tab-pane label="基本信息" name="baseInfo">
                    <el-form-item label="上级组织" label-width="100px">
                        <el-input v-model="localRow.parentName"  icon="search" :disabled="true"></el-input>
                    </el-form-item>
                    <el-form-item label="禁用状态" label-width="100px">
                        <el-select v-model="localRow.isDel" placeholder="请选择" :disabled="true">
                            <el-option label="是" :value="1"></el-option>
                            <el-option label="否" :value="0"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="组织编码" label-width="100px">
                        <el-input v-model="localRow.code" :disabled="true"></el-input>
                    </el-form-item>
                    <el-form-item label="联系人" label-width="100px">
                        <input type="hidden" v-model="localRow.contactUser" :disabled="true" />
                        <el-select
                                :disabled="status==='retrieve'"
                                clearable
                                filterable
                                remote
                                v-model="localRow.contactEmployee.enName"
                                :value="localRow.contactUser"
                                v-on:change="onSelectChange"
                                placeholder="请输入英文名或中文名查询"
                                :remote-method="remoteMethod"
                                :loading="loading">
                            <el-option
                                    v-for="item in empName"
                                    :key="item.id"
                                    :label="item.name"
                                    :value="item.id">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="组织名称" label-width="100px">
                        <el-input v-model="localRow.name" disabled></el-input>
                    </el-form-item>
                    <el-form-item label="联系电话" label-width="100px">
                        <el-input  v-model="localRow.contactEmployee.phoneId" :disabled="true"></el-input>
                    </el-form-item>
                    <el-form-item label="组织形态" label-width="100px">
                        <el-select placeholder="请选择" v-model="localRow.typeCode" :disabled="status!=='update'">
                            <el-option v-for="item in typeCodeOptions" :label="item.name" :value="item.code"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="邮编" label-width="100px">
                        <el-input v-model="localRow.postCode" :disabled="status==='retrieve'"></el-input>
                    </el-form-item>
                    <el-form-item label="详细地址" class="wide" label-width="100px">
                        <el-input v-model="localRow.location" :disabled="status==='retrieve'"></el-input>
                    </el-form-item>
                    <el-form-item label="描述" class="wide" :rows="3" resize="none" label-width="100px">
                        <el-input v-model="localRow.description" type="textarea" :rows="3" resize="none" :disabled="status==='retrieve'"></el-input>
                    </el-form-item>
                    <el-form-item label="组织职能" class="wide" label-width="100px">
                        <el-checkbox-group v-model="localRow.functionCodes" :disabled="status!=='update'">
                            <el-checkbox v-for="item in functionCodeOptions" :label="item.code">{{item.name}}</el-checkbox>
                        </el-checkbox-group>
                    </el-form-item>
                </el-tab-pane>
                <el-tab-pane label="其他信息" name="otherInfo">
                    <el-form-item label="创建人员" label-width="100px">
                        <el-input :value="localRow.createUserName" disabled></el-input>
                    </el-form-item>
                    <el-form-item label="创建时间" label-width="100px">
                        <el-input :value="localRow.createTime | toDate" disabled></el-input>
                    </el-form-item>
                    <el-form-item label="修改人员" label-width="100px">
                        <el-input :value="localRow.updateUserName" disabled></el-input>
                    </el-form-item>
                    <el-form-item label="修改时间" label-width="100px">
                        <el-input :value="localRow.updateTime | toDate" disabled></el-input>
                    </el-form-item>
                </el-tab-pane>
            </el-tabs>
        </el-form>
        <div slot="footer" class="dialog-footer" v-if="status!=='retrieve'">
            <el-button @click="btnOKClick" :disabled="!initSuccess" :loading="submitLoading" type="primary">确定</el-button>
            <el-button @click="btnCancleClick">取消</el-button>
        </div>
    </el-dialog>
</template>
<script>
    import api from 'src/utils/api.js'
    export default {
        name: 't8t-dialog',
        data() {
            return {
                initSuccess: false,
                submitLoading: false,
                requestTime: 0,
                loading: false,
                activePane: 'baseInfo',
                localIndex: 0,
                localRow: {
                    "contactEmployee": {
                        "enName": null
                    },
                    "code": "",
                    "contactUser": null,
                    "contactUserName": null,
                    "createTime": null,
                    "createUser": null,
                    "description": "null",
                    "functionCodes": [],
                    "id": null,
                    "isDel": null,
                    "location": "",
                    "name": "",
                    "parentId": null,
                    "postCode": "",
                    "typeCode": "",
                    "updateTime": null,
                    "updateUser": null,
                    "updateUserName": null
                    },
                status: 'retrieve',
                empName: []
            }
        },
        computed: {
            isShow: {
                get() {
                    let that = this
                    this.status = this.$store.state.organization.dialogStatus.status
                    let isShow = this.$store.state.organization.dialogStatus.isShow

                    if (isShow) {
                        let id = this.$store.state.organization.tableStatus.viewStatus.SelectedRow.id
                        api.organization.findById(id)
                        .then((res) => {
                            if (res.data.status == 200 && res.data.result != null) {
                                that.initSuccess = true
                                that.localRow = Object.assign(that.localRow, res.data.result)
                            } else {
                                that.$message.error(res.data.message)
                            }
                        })
                        .catch((err) => {
                            that.$message.error('加载数据失败')
                        })
                    }

                    return isShow
                },
                set(value) {
                    if (value === false) {
                        // 关闭的时候清空次数
                        this.requestTime = 0
                    }
                    this.status = this.$store.state.organization.dialogStatus.status
                    this.$store.commit('SET_DIALOG_STATUS_ISSHOW', value)
                }
            },
            typeCodeOptions() {
                return this.$store.state.organization.typeCodeOptions
            },
            functionCodeOptions() {
                return this.$store.state.organization.functionCodeOptions
            }
        },
        methods: {
            onSelectChange(contactUser) {
                // 初始化加载数据的时候也会触发onSelectChange事件
                if (this.requestTime > 0) this.localRow.contactUser = contactUser
            },
            remoteMethod(query) {
                let that = this
                if (query != '') {
                    this.loading = true
                    let args = {
                        search: { name: query },
                        page: 0,
                        size: 100
                    }
                    api.employee.queryFull(args)
                    .then( (res) => {
                        that.loading = false
                        ++that.requestTime
                        if (res.data.status === 200) {
                            let _empMap = res.data.result.rows.map(item => {
                                return { id: item.id, enName: item.enName, name: (item.enName + '（' + item.name + '）') };
                            });
                            that.empName = _empMap
                        } else {
                            
                        }
                    } )
                }
            },
            handleClose() {
            },
            btnOKClick() {
                let that = this
                var args = {
                    organization: this.localRow
                }
                this.submitLoading = true
                api.organization.update(args)
                    .then((res) => {
                        that.submitLoading = false
                        if (res.data.status === 200 && res.data.result === 1) {
                            this.$message({
                                message: '提交成功',
                                type: 'success'
                            });
                            this.$store.commit('SET_DIALOG_STATUS_ISSHOW', false)
                            this.$store.dispatch('loadTableData1')
                        }else{
                            this.$message.error(res.data.message)
                        }
                    })
                    .catch( (error) => {
                        that.submitLoading = false
                        this.$message.error('数据提交失败！')
                    } )
            },
            btnCancleClick() {
                this.$store.commit('SET_DIALOG_STATUS_ISSHOW', false)
            }
        }
    }

</script>
<style lang="css">
.organization-dialog .el-form--inline .el-form-item__label {
    float: left !important;
}
</style>
<style lang="css" scoped>
    .organization-dialog .el-input,
    .organization-dialog .el-select {
        width: 200px;
    }
    .organization-dialog .el-form-item{
        width: 49%;
        margin-right: 0;
    }
    .organization-dialog .wide.el-form-item{
        width: 100%;
    }
    .organization-dialog .wide.el-form-item .el-input,
    .organization-dialog .wide.el-form-item .el-textarea{
        width: 540px;
    }
    .el-checkbox-group{
        width: 520px;
    }
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    .organization-dialog .el-dialog__body{
        padding-top: 0;
    }
    .organization-dialog .el-dialog__body * {
        font-size: 12px;
    }
    .organization-dialog .el-dialog{
        width: 725px;
    }
    .organization-dialog .el-input__inner{
        height: 32px;
    }
    .el-form--inline .el-form-item__label{
        verticle-align: top;
    }
    .el-checkbox+.el-checkbox:nth-child(7){
        margin-left: 0px;
    }
</style>
