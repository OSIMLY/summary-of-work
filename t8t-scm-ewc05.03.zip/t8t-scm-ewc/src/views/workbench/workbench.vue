<template>
    <div class="right-content-w">
        <t8t-breadcrumb :data="breadcrumbData"></t8t-breadcrumb>

        <div class="workbench-content">
            <div class="workbench" v-show="showWorkBench">
                <div class="workbench-panel">
                    <div class="workbench-title">
                        <div class="workbench-subscribe">
                            <h3 class="workbench-panel-top-title">我的订阅</h3>
                        </div>
                        <div class="workbench-more">
                            <p>
                                <a title="数据中心入口" href="javascript:;">更多 &gt;&gt;</a>
                            </p>
                        </div>
                    </div>

                    <div class="workbench-body">
                        <div class="workbench-carousel">
                            <el-carousel  :indicatorPosition="'none'" :interval="4000" arrow="always">
                                <template v-for="(chart, index) in switch_charts">
                                    <el-carousel-item>
                                        <To8toChart class="chart-picture"  v-if="chart.show" :option="chart.option" :loading="chart.loading" :resizable="true"></To8toChart>
                                    </el-carousel-item>
                                </template>
                            </el-carousel>
                        </div>
                    </div>
                </div>
            </div>

            <div class="user-space">
                <div class="workbench-panel">
                    <div class="workbench-title">
                        <div class="workbench-subscribe">
                            <div class="user-task-lists">
                                <template v-for="(task, $index) in taskLists">
                                    <div class="user-task" :class="{'active': task.active}" @click="changeTabPage(task, $index)">{{task.name}}（{{task.count}}）</div>
                                    <div class="user-interval">|</div>
                                </template>
                            </div>
                        </div>
                        <div class="workbench-more">
                            <p>
                                <a :href="linkToTask">更多 &gt;&gt;</a>
                            </p>
                        </div>
                    </div>
                    <div class="workbench-body">
                        <div v-for="task in listTask">
                            <template v-if="active=='0'">
                                <p><span>您有 </span><a :href="task.formKey + '?procInsId=' + task.procInsId + '&taskId=' + task.taskId">{{task.procName}}(编号:{{task.businessKey}})</a><span> 需要处理,当前环节为{{task.nodeName}}，任务生成时间为：{{formatTime(task.createTime)}}.</span></p>
                            </template>
                            <template v-else-if="active=='1'">
                                <p><span>您发起的 </span><a :href="task.formKey + '?procInsId=' + task.procInsId + '&taskId=' + task.taskId">{{task.procName}}(编号:{{task.markKey}})</a><span> ，当前环节为{{task.nodeName}}，（处理人：{{displayShortUserName(task.candidateName)}}）.</span></p>
                            </template>
                            <template v-else-if="active=='2'">
                            </template>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<style type="text/css" scoped>
    .workbench-carousel .el-carousel__item{
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .workbench-carousel .el-carousel__item img{
        width: 100%;
        height: 100%;
    }
    .chart-picture{
        width: calc(100% - 120);
        height: 100%;
    }
    h3, p{
        margin: 0;
        font-weight: normal;
        font-family: 'Microsoft YaHei', 微软雅黑, 'Open Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
    }
    .right-content-w{
        position: relative;
        display: flex;
    }
    .workbench-content{
        width: calc(100% - 50px);
        height: calc(100% - 92px);
        min-width: 1101px;
        margin: 25px;
        flex: 1;
        display: flex;
        flex-flow: column;
    }
    .workbench{
        height: 348px;
        margin-bottom: 25px;
    }
    .user-space{
        border: 1px solid #ddd;
        flex: 1;
        display: flex;
        min-height:120px;
        flex-direction: column;
    }
    .workbench .workbench-panel{
        border: 1px solid #ddd;
        height: 100%;
    }
    .workbench .workbench-panel .workbench-title{
        display: flex;
        position: relative;
        background-color: #fafafa;
        line-height: 45px;
        border-bottom: 1px solid #ddd;
    }
    .workbench .workbench-panel .workbench-title .workbench-more{
        width: 100px;
        line-height: 45px;
        text-align: center;
    }
    .workbench .workbench-panel .workbench-title .workbench-more p a,
    .user-space .workbench-panel .workbench-title .workbench-more p a{
        text-decoration: none;
        color: #888;
        font-size: 12px;
    }
    .workbench .workbench-panel .workbench-title .workbench-more p a:hover,
    .user-space .workbench-panel .workbench-title .workbench-more p a:hover{
        color: deepskyblue;
    }
    .workbench .workbench-panel .workbench-title .workbench-subscribe,
    .user-space .workbench-panel .workbench-title .workbench-subscribe{
        flex: 1;
    }
    .workbench .workbench-panel .workbench-title .workbench-subscribe .workbench-panel-top-title{
        padding-left: 15px;
        font-size: 14px;
    }
    .user-space .workbench-panel{
        display: flex;
        flex-direction: column;
    }
    .user-space .workbench-panel .workbench-title{
        display: flex;
        position: relative;
        background-color: #fafafa;
        line-height: 52px;
        height: 52px;
        min-height: 52px;
        border-bottom: 1px solid #ddd;
    }
    .user-space .workbench-panel .workbench-title .workbench-more{
        width: 100px;
        line-height: 52px;
        height: 52px;
        text-align: center;
    }
    .user-task-lists{
        display: flex;
    }
    .user-task-lists .user-task{
        font-size: 14px;
        padding: 0 15px;
        flex: row;
    }
    .user-task-lists .user-interval{
        flex: row;
        font-size: 14px;
        padding: 0;
    }
    .user-task-lists .user-interval:last-child{
        display: none;
    }
    .user-task-lists .user-task.active, .user-task-lists .user-task:hover{
        color: #338bed;
        border-bottom: 1px solid #338bed;
        cursor: pointer;
    }
    .user-space .workbench-panel .workbench-body{
        padding: 20px;
        overflow: auto;
        flex: 1;
        display: block;
    }
    .user-space .workbench-panel .workbench-body div p a{
        text-decoration: none;
        color: #428bca;
    }
    .user-space .workbench-panel .workbench-body div p{
        line-height: 26px;
        font-size: 14px;
    }
    .workbench .workbench-panel .workbench-body .workbench-carousel,
    .user-space .workbench-panel .workbench-body .workbench-carousel{
        height: 100%;
    }
    .user-space-detail{
        padding: 5px;
        width: 100%;
        min-height: 100%;
        background-color: yellowgreen;
    }
    .chart-parent{
        width: calc(100% - 120px);
        height: 100%;
        position: relative;
        display: flex;
    }
    .vue-echarts{
        position: relative;
    }
    .el-carousel__item h3 {
        color: #475669;
        font-size: 18px;
        opacity: 0.75;
        margin: 0;
    }
    .el-carousel__item:nth-child(2n) {
        background-color: #ffffff;
    }
    .el-carousel__item:nth-child(2n+1) {
        background-color: #d3dce6;
    }
</style>

<script>
    import To8toChart from 'vue-echarts-v3'
    import WorkBench from 'src/services/workbench/workBench.js'
    import chartTransfer from 'src/services/workbench/chartTransfer.js'
    import Cookie from 'js-cookie'
    import AxiosSrc from 'axios'

    export default{
        data(){
            return {
                father_code: "001010001",
                switch_charts: [],
                account_id : Cookie.get('t8t-it-uid'),
                ticket : Cookie.get('t8t-it-ticket'),
                breadcrumbData: [{
                    title: '首页'
                }],
                showWorkBench: true,
                firstPage: true,
                linkToTask: 'javascript:;',
                listTask: [],
                active: 1,
                taskLists:[
                    {
                        name: '待办任务',
                        count: 0,
                        active: true,
                        link: 'http://scm.to8to.com/#/procenter/page-pro-del',
                        lists: []
                    },
                    {
                        name: '在办任务',
                        count: 0,
                        active: false,
                        link: 'http://scm.to8to.com/#/procenter/page-pro-already',
                        lists: []
                    },
                    {
                        name: '告警信息',
                        count: 0,
                        active: false,
                        link: '/index.php/Flow/flow/deal',
                        lists: []
                    },
                ]
            }
        },
        computed:{
            showWorkBench: function () {
                return this.switch_charts.length != 0;
            }
        },
        mounted(){
            this.initChart();
            this.initToDoTask();
            this.initDoingTask();
            this.initWaring();
        },
        create(){
        },
        methods:{
            changeTabPage(task, index){
                this.taskLists.forEach(function (task) {
                    task.active = false;
                });
                task.active = true;
                this.linkToTask = task.link;
                this.listTask = task.lists;
                this.active = index;
            },
            formatTime(timeStamp){
                /* 增加日期格式函数 */
                Date.prototype.format = function(format) {
                    let date = {
                        "M+": this.getMonth() + 1,
                        "d+": this.getDate(),
                        "h+": this.getHours(),
                        "m+": this.getMinutes(),
                        "s+": this.getSeconds(),
                        "q+": Math.floor((this.getMonth() + 3) / 3),
                        "S+": this.getMilliseconds()
                    };
                    if (/(y+)/i.test(format)) {
                        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
                    }
                    for (let k in date) {
                        if (new RegExp("(" + k + ")").test(format)) {
                            format = format.replace(RegExp.$1, RegExp.$1.length == 1
                                ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
                        }
                    }
                    return format;
                };
                let d = new Date();
                d.setTime(timeStamp * 1000);
                return d.format('yyyy-MM-dd h:m:s');
            },
            initChart(){
                let that = this;
                let args = {
                    "fatherUrl" : "#/workbench/workbench",
                    "accountID": this.account_id
                };
                WorkBench.queryWorkBenchByFatherUrl(args)
                .then(function (response) {
                    if(response.status == 200){
                        let result = response.data.result;
                        if(!result){
                            return;
                        }
                        that.switch_charts = [];
                        for(let i=0; i<result.length; i++){
                            let url = result[i]['url'];
                            let report_type = url.split('_')[url.split('_').length - 1];
                            let report_name = '';
                            if (report_type == 'month') {
                                report_name = '月报';
                            } else if(report_type == 'week') {
                                report_name = '周报';
                            } else if(report_type == 'daily') {
                                report_name = '日报';
                            }
                            let obj = {
                                url : url,
                                show: true,
                                report_name: report_name,
                                loading: true,
                                option:  {series:[]}
                            };
                            that.switch_charts.push(obj);
                        }
                        if(that.switch_charts.length > 0){
                            that.obtainChartConfigure();
                            that.showWorkBench = true;
                        } else {
                            /* 无工作台时不显示数据 */
                            that.showWorkBench = false;
                        }
                    } else {
                        that.showWorkBench = false;
                    }
                })
                .catch(function (error) {
                    console.log(error)
                });
            },
            obtainChartConfigure(){
                let that = this;
                let chartItems = [];
                let base_url = WorkBench.getVisualURL();
                this.switch_charts.forEach(function(cfg, index){
                    let item = cfg['url'];
                    chartItems.push(item);
                });
                let data = {
                    'uid': this.account_id,
                    'ticket': this.ticket,
                    'action': 'dataCenter',
                    'appName': 'erp',
                    'sort': 'WORKBENCH',
                    'chartItems': chartItems
                };
                AxiosSrc.get(
                    base_url,
                    {
                        params: data
                    }
                ).then(function (response) {
                    let data = response.data.result;
                    that.switch_charts.forEach(
                        function (item) {
                            let url = item['url'];
                            that.$set(item, 'loading', false);
                            if (data['result'] == 0) {
                                console.log('data center no auth, ', data);
                                return;
                            }
                            let configure = data[url];
                            if(configure){
                                let option = chartTransfer.displayChart(configure);
                                that.$nextTick(function () {
                                    that.$set(item, 'option', option);
                                    that.$set(item, 'show', true);
                                })
                            }
                        }
                    );
                    if(that.switch_charts.length > 0){
                        document.getElementsByClassName('el-carousel__item')[0].style.display = 'block';
                    }
                }).catch(function (error) {
                    that.switch_charts.forEach(
                        function (item) {
                            that.$set(item, 'show', false);
                            that.$set(item, 'loading', false);
                        }
                    );
                    console.log(error);
                });
            },
            initToDoTask(){
                /* 初始化 待办任务 */
                let that = this;
                let args = {
                    "query": {
                        "candidate": this.account_id
                    },
                    "page": 1,
                    "size": 10
                };
                WorkBench.queryUserTaskWeb(args)
                .then(function (response) {
                    let status = response.status;
                    if (status != 200){
                        console.log(response.statusText);
                    }
                    let result = response.data.result;
                    if(!result){
                        return;
                    }
                    let rows = result.rows;
                    let total = result.total;
                    let needDeal = that.taskLists[0];
                    if(rows){
                        that.$set(needDeal, 'lists', rows);
                        that.$set(needDeal, 'count', total);
                    } else {
                        that.$set(needDeal, 'count', 0);
                    }
                    if(that.firstPage){
                        that.changeTabPage(needDeal, 0);
                    } else {
                        that.firstPage = false;
                    }
                })
                .catch(function (error) {
                    console.log(error)
                });
            },
            initDoingTask(){
                /* 初始化 在办任务 */
                let that = this;
                let args = {
                    "query" : {
                        "starter": this.account_id
                    },
                    "page": 1,
                    "size": 10
                };
                WorkBench.queryUserTaskByStart(args)
                .then(function (response) {
                    let status = response.status;
                    if (status != 200){
                        console.log(response.statusText);
                    }
                    let result = response.data.result;
                    if(!result){
                        return;
                    }
                    let rows = result.rows;
                    let total = result.total;
                    let needDeal = that.taskLists[1];
                    if(rows){
                        that.$set(needDeal, 'lists', rows);
                        that.$set(needDeal, 'count', total);
                    } else {
                        that.$set(needDeal, 'count', 0);
                    }
                })
                .catch(function (error) {
                    console.log(error)
                });
            },
            displayShortUserName(usernames){
                let name = Cookie.get('t8t-it-username');
                let nameList = [name];
                if(!usernames){
                    return '无';
                } else if(usernames.length > 3){
                    usernames.forEach(function (element) {
                        if(nameList.length < 3){
                            if(element != name){
                                nameList.push(element);
                            }
                        }
                    });
                    return nameList.join(', ');
                } else{
                    return usernames.join(', ');
                }
            },
            displayAllUserName(usernames){
                return usernames.join(', ');
            },
            initWaring(){
                /* 初始化 告警任务接口 */
            }
        },
        components: {
            To8toChart
        },
        name: 'workbench'
    }
</script>
