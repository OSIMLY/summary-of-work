<template>
    <el-dialog @close="closeDialog" v-model="isDialogShow" size="full" class="t8t-full-dialog">
        <div class="t8t-full-dialog-container">
            <!-- 顶部按钮区 -->
            <div class="full-dialog-toolbar-container">
                <div class="toolbar-container">
                </div>
            </div>
            <div class="full-dialog-form-container container-center">
                <el-tabs v-model="tab_info" @tab-click="handleClick">
                    <el-tab-pane label="基本信息" name="base">
                        <el-row :gutter="20">
                            <el-col :span="4"><div class="grid-content">ID：</div></el-col>
                            <el-col :span="8"><div class="grid-content">{{detailInfo.id}}</div></el-col>
                            <el-col :span="4"><div class="grid-content">名称：</div></el-col>
                            <el-col :span="8"><div class="grid-content">{{detailInfo.name}}</div></el-col>
                            <el-col :span="4"><div class="grid-content">内部工期：</div></el-col>
                            <el-col :span="8"><div class="grid-content">{{detailInfo.insideSchdule}}天</div></el-col>
                            <el-col :span="4"><div class="grid-content">外部工期：</div></el-col>
                            <el-col :span="8"><div class="grid-content">{{detailInfo.outsideSchdule}}天</div></el-col>
                            <el-col :span="4"><div class="grid-content">节点总数：</div></el-col>
                            <el-col :span="8"><div class="grid-content">{{detailInfo.nodeNumber}}个</div></el-col>
                            <el-col :span="4"><div class="grid-content">状态：</div></el-col>
                            <el-col :span="8"><div class="grid-content">{{detailInfo.moduleStatus == 1 ? '启用' : '禁用'}}</div></el-col>
                        </el-row>
                    </el-tab-pane>
                    <el-tab-pane label="编辑信息" name="other">
                        <el-row :gutter="20">
                            <el-col :span="5"><div class="grid-content">创建人：</div></el-col>
                            <el-col :span="7"><div class="grid-content">{{detailInfo.createUserName}}</div></el-col>
                            <el-col :span="5"><div class="grid-content">创建时间：</div></el-col>
                            <el-col :span="7"><div class="grid-content">{{detailInfo.createTime | dateParser}}</div></el-col>
                            <el-col :span="5"><div class="grid-content">最后变更人：</div></el-col>
                            <el-col :span="7"><div class="grid-content">{{detailInfo.updateUserName}}</div></el-col>
                            <el-col :span="5"><div class="grid-content">最后变更时间：</div></el-col>
                            <el-col :span="7"><div class="grid-content">{{detailInfo.updateTime | dateParser}}</div></el-col>
                        </el-row>
                    </el-tab-pane>
                </el-tabs>
            </div>
            <div class="full-dialog-tabs-container">
                <el-tabs v-model="tab_list" @tab-click="handleClick">
                    <el-tab-pane label="节点信息" name="attr">
                        <div class="my-container">
                            <div class="my-toolbar">
                                <el-button
                                    type="primary"
                                    size="small"
                                    icon="plus"
                                    @click="addNode"
                                >新增节点</el-button>
                                <el-button
                                    type="danger"
                                    size="small"
                                    icon="close"
                                    @click="delNode"
                                >删除节点</el-button>
                                <el-button
                                    type="primary"
                                    size="small"
                                    class="el-icon-check"
                                    @click="saveNode"
                                > 保存</el-button>
                            </div>
                            <t8t-table
                                ref="infoTable"
                                :columns="infoColumns"
                                :service="infoService"
                                :method="infoMethod"
                                :args="infoArgs"
                                :isLoading="isLoading"
                                :commonData="commonOptionsConfig"
                                :templateData="infoTemplateData"
                                :pageBar="true"
                                :editable="true"
                                @selection-change="selectionChange"
                            >
                                <template slot="id" scope="scope">
                                    <a href="javascript:;" @click="showDetail(scope.row['id'],scope.row['nodeTypeName'])">{{scope.row['id']}}</a>
                                </template>
                            </t8t-table>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="节点关系" name="relation">
                        <div class="my-container">
                            <div class="my-toolbar">
                                <el-button
                                    type="primary"
                                    size="small"
                                    icon="plus"
                                    @click="addNodeRel"
                                >新增关系</el-button>
                                     <el-button
                                    type="danger"
                                    size="small"
                                    icon="close"
                                    @click="delNodeRel"
                                >删除关系</el-button>
                                <el-button
                                     type="primary"
                                    size="small"
                                    class="el-icon-check"
                                    @click="saveNodeRel"
                                >保存关系</el-button>
                            </div>
                            <t8t-table
                                ref="relNodeTable"
                                :columns="relationColumns"
                                :templateData="relationTmpData"
                                :service="relationService"
                                :method="relationMethod"
                                :args="relationArgs"
                                :pageBar="true"
                                :editable="true"
                                :commonData="commonOptionsConfig"
                                @cell-form-item-change="nodeRelRowChange"
                            >
                                <template slot="headId" scope="scope" >
                                    <el-select
                                        v-model="scope.row['headId']"
                                        :filterable="true"
                                        @change="changeRelHeadId(arguments[0], scope.column,scope.row, scope.cell)">
                                        <el-option
                                        v-for="item in nodeList"
                                        :label="item.value"
                                        :value="item.value">
                                        <span style="float:left">{{item.value}}</span>
                                        <span style="float:right; color:#8492a6;font-size:13px">{{item.label}}</span>
                                        </el-option>
                                    </el-select>
                                </template>
                                <template slot="tailId" scope="scope" >
                                    <el-select
                                        v-model="scope.row['tailId']"
                                        :filterable="true"
                                        @change="changeRelTailId(arguments[0], scope.column,scope.row, scope.cell)">
                                        <el-option
                                        v-for="item in nodeList"
                                        :label="item.value"
                                        :value="item.value">
                                        <span style="float:left">{{item.value}}</span>
                                        <span style="float:right; color:#8492a6;font-size:13px">{{item.label}}</span>
                                        </el-option>
                                    </el-select>
                                </template>
                            </t8t-table>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="引用关系" name="reference">
                        <div class="my-container">
                            <t8t-table
                                ref="relationTable"
                                :columns="referenceColumns"
                                :service="referenceService"
                                :method="referenceMethod"
                                :args="referenceArgs"
                                :pageBar="true"
                                :commonData="commonOptionsConfig"
                            >
                            </t8t-table>
                        </div>
                    </el-tab-pane>
                </el-tabs>
            </div>
        </div>
    </el-dialog>
</template>

<script>
    import commonApi from 'src/services/commonApi/commonApi.js'
    //import T8tDatePicker from 'src/components/t8t-form/dateTimePicker.vue'
    import Service from 'src/services/delivery/Service.js'
    import TemplateOperator from 'src/services/delivery/template-base.js'
    import axios from 'src/utils/axios.js'
    import Cookie from 'js-cookie'
    import DateUtils from 'src/utils/DateUtils.js'
    export default {
        name: 'template-detail',
        data() {
            return {
                tab_info: 'base',
                tab_list: 'attr',
                isDialogShow:true,
                isLoading:false,
                detailInfo:{
                    createTime: '',
                    createUser: '',
                    createUserName: '',
                    effectTime: '',
                    id: '',
                    insideSchdule: '',
                    moduleStatus: '',
                    name: '',
                    nodeNumber: '',
                    outsideSchdule: '',
                    updateTime: '',
                    updateUser: '',
                    updateUserName: ''
                },
                infoColumns:
                    [
                        {
                            "prop": "id",
                            "label": "ID"
                        },
                        {
                            "prop": "nodeType",
                            "label": "类型",
                            "list": "nodeType",
                            "editor": {
                                "type": "select",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "parentId",
                            "label": "父节点ID",
                            "list": "parentId",
                            "editor": {
                                "type": "select",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "relationType",
                            "label": "父子关系类型",
                            "list": "relationType",
                            "editor": {
                                "type": "select",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "lastNode",
                            "label": "是否为末级",
                            "list": "isLast",
                            "editor": {
                                "type": "select",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "billType",
                            "label": "单据类型",
                            "list": "billType",
                            "editor": {
                                "type": "select"
                            }
                        },
                        {
                            "prop": "createMoment",
                            "label": "创建时机",
                            "list": "createMoment",
                            "editor": {
                                "type": "select",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "offset",
                            "label": "偏移量",
                            "editor": {
                                "type": "input",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "itemStatus",
                            "label": "状态",
                            "list": "itemStatus",
                            "editor": {
                                "type": "select",
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        },
                        {
                            "prop": "effectTime",
                            "label": "生效日期",
                            "formatter": "dateParser",
                            "editor":{
                                "type":"datetime",
                                "endFormater": 'timestamp',
                                "rules": [{
                                    "required": true,
                                    "message": "不能为空"
                                }]
                            }
                        }
                    ],
                infoTemplateData:{
                    "id":null,
                    "nodeType": null,
                    "parentId": null,
                    "relationType": null,
                    "lastNode": null,
                    "billType": null,
                    "createMoment": null,
                    "offset": "",
                    "itemStatus": null,
                    "effectTime": null
                },
                relationColumns:
                    [
                        { "prop": "id", "label": "ID" },
                        { "prop": "headId", "label": "头节点ID"},
                        { "prop": "headNodeTypeName", "label": "头节点类型"  },
                        { "prop": "tailId", "label": "尾节点ID" },
                        { "prop": "tailNodeTypeName", "label": "尾节点类型" },
                        { "prop": "advance", "label": "提前量" , editor: {
                                                                                type: 'input',
                                                                                rules: [{
                                                                                            pattern:/^[0-9]*$/,
                                                                                            required: true,
                                                                                            message: "请填写正确的提前量"
                                                                                       }]
                        }},
                        { "prop": "relationType", "label": "关系类型" , "list":"nodeRelTypes", editor: {
                                                                                type: 'select',
                                                                                rules: [{
                                                                                            required: true,
                                                                                            message: "关系类型不能为空"
                                                                                       }]
                        }},
                        { "prop": "relationStatus", "label": "启用状态", "list":"nodeRelStatus", editor: {
                                                                                type: 'select',
                                                                                rules: [{
                                                                                            required: true,
                                                                                            message: "启用状态不能为空"
                                                                                       }]
                        }},{ "prop": "triggerType", "label": "触发类型", "list":"triggerTypes", editor: {
                                                                                type: 'select',
                                                                                rules: [{
                                                                                            required: true,
                                                                                            message: "触发类型不能为空"
                                                                                       }]
                        }},
                        { "prop": "effectTime", "label": "生效日期", "formatter": "dateParser" , editor: {
                                                                                type: 'datetime', endFormater: 'timestamp',
                                                                                rules: [{
                                                                                            required: true,
                                                                                            message: "生效日期不能为空"
                                                                                       }]
                        }}
                    ],
                    relationTmpData:{
                              id:null,
                              headId:null,
                              headNodeTypeName:null,
                              tailId:null,
                              tailNodeTypeName:null,
                              advance:null,
                              relationType:null,
                              relationStatus:null,
                              triggerType:null,
                              effectTime:null

                    },
                referenceColumns:
                    [
                        { "prop": "scheduleId", "label": "排期模板ID" },
                        { "prop": "scheduleId", "label": "排期模板名称" , "list":"scheduleInfo"},
                        { "prop": "quotationId", "label": "报价模板ID" },
                        { "prop": "quotationName", "label": "报价模板名称" },
                        { "prop": "quotationStatus", "label": "报价模板状态" ,"list":"itemStatus" },
                        { "prop": "quotationEffectime", "label": "报价模板生效日期" , "formatter": "dateParser"}
                    ],
                commonOptionsConfig: {
                    nodeType: [], // 类型
                    parentId: [],
                    relationType: [], //父子关系类型
                    isLast: [
                        { value: 1, text: '是'},
                        { value: 0, text: '否'}
                    ], //是否为末级
                    createMoment: [], //创建时机
                    billType: [], //单据类型
                    itemStatus: [
                        { value: 1, text: '启用'},
                        { value:0, text: '禁用'}
                    ], //行状态
                    nodeRelStatus:[
                        {
                           value:0,
                           text:'禁用',
                        },{
                           value:1,
                           text:'启用',
                        }
                  ],
                  triggerTypes:[
                        {
                           value:0,
                           text:'手动',
                        },{
                           value:1,
                           text:'自动',
                        }
                  ],
                  nodeRelTypes:[],
                  scheduleInfo:[{
                       text: this.$route.query.name,
                       value: Number.parseInt(this.$route.query.id)
                   }
                  ]

                },
                infoService: Service.TEMPLATE.name,
                infoMethod:  Service.TEMPLATE.methods.moduleItemQueryPage,
                infoArgs: {search: {moduleId: this.$route.query.id}},
                infoSelectedRows:[],
                relationService: Service.TEMPLATE.name,
                relationArgs: {search: {moduleId_eq: this.$route.query.id}},
                relationMethod:  Service.TEMPLATE.methods.NodeRelation,
                referenceService: Service.TEMPLATE.name,
                referenceMethod:  Service.TEMPLATE.methods.referenceRelation,
                referenceArgs:{moduleId: this.$route.query.id},
                nodeList:[]

            };
        },
        created (){
            if(!this.$route.query.id){
                this.$msgbox({
                    title: '消息',
                    type: 'error',
                    message: '参数错误！',
                    confirmButtonText: '知道了',
                    confirmButtonClass: 'is-plain'
                },function(){
                    //todo 没传参数的情况
                });
                return false;
            }
            TemplateOperator.getById({id: this.$route.query.id})
                .then((res) => {
                    if (res.data.status === 200) {
                        this.detailInfo =  res.data.result
                    }
                });
            this.getParentId();
            this.getCommonOptions('41101','nodeType');
            this.getCommonOptions('41102','relationType');
            this.getCommonOptions('41103','createMoment');
            this.getCommonOptions('11605','billType');
            this.getCommonOptions('41104','nodeRelTypes')
            this.getNodeList(this.$route.query.id)
        },
        filters: {
            dateParser(text) {
                let dateString;
                let objDate = new Date(text * 1000);
                if (text === 0 || text === null) {
                    dateString = ""
                } else {
                    dateString = DateUtils(objDate, 'yyyy-mm-dd HH:MM:ss')
                }
                return dateString
            }
        },
        methods: {
            closeDialog() {
                this.$router.go(-1)
            },
            handleClick(tab, event) {
            },
            getParentId(){
                TemplateOperator.moduleItemQueryPage({page:1, size:200,search: {moduleId:this.$route.query.id,lastNode:0}})
                    .then((res) => {
                        if (res.data.status === 200) {
                            let rows = res.data.result.rows;
                            let list = [{text: 0, value: 0}];
                            for(let i in rows){
                                list.push({text: rows[i].id, value: rows[i].id});
                            }
                            this.commonOptionsConfig.parentId = list;
                        }
                    });
            },
            //辅助资料
            getCommonOptions: function(fatherCode,selectName) {
                let arg =  {
                    page: 1,
                    search: {
                        pPropertyCode: fatherCode
                    },
                    size: 100
                }
                let list = []
                commonApi.queryUnionParent(arg)
                    .then((res) => {
                        if (res.data.status === 200) {
                            res.data.result.forEach((item) => {
                                if (item.propertyStatus===1) {
                                    list.push({
                                        value: item.id,
                                        text: item.propertyName
                                    })
                                }
                            });
                            this.commonOptionsConfig[selectName] = list;
                            this.commonOptionsConfig[selectName].unshift({value:null,text: '请选择'});
                        }
                    })
            },

            //行变化事件
            selectionChange (rows){
                //已选择行
                this.infoSelectedRows = rows;
            },
            addNode() {
                this.$refs['infoTable'].addNewRow()
            },
            delNode() {
                if(this.infoSelectedRows.length > 0){
                    for(let i in this.infoSelectedRows){
                        if(this.infoSelectedRows[i].id){
                            this.$message.error('已保存的节点不能被删除！')
                            return false;
                        }
                    }
                    this.$refs['infoTable'].delRows()
                }else{
                    this.$message.error('请选择需要删除的节点！')
                }
            },
            saveNode() {
                let rows =  this.$refs['infoTable'].getActionLog(false);
                let data = {};
                data.addModuleItems = this.formatRowData(rows.addedRows);
                data.updateModuleItems = this.formatRowData(rows.editedRows);
                this.$refs['infoTable'].validate((isValid) => {
                    if (isValid && data.addModuleItems && data.updateModuleItems) {
                        this.isLoading = true;
                        TemplateOperator.moduleItemSave(data)
                            .then((res) => {
                                if (res.data.status === 200) {
                                    this.$msgbox({
                                        title: '消息',
                                        type: 'success',
                                        message: '保存成功！',
                                        confirmButtonText: '知道了',
                                        confirmButtonClass: 'is-plain'
                                    },function(){
                                        //this.reloadTable('infoTable');

                                    });
                                    this.isLoading = false;
                                    //重置行记录状态
                                    this.$refs['infoTable'].getActionLog(true);
                                    //更新节点总数
                                    if(data.addModuleItems.length){
                                        this.detailInfo.nodeNumber += data.addModuleItems.length;
                                    }
                                    //更新节点列表
                                    this.getParentId();
                                    this.getNodeList(this.$route.query.id);
                                    this.$refs['infoTable'].reloadTable();

                                }else{
                                    this.$msgbox({
                                        title: '消息',
                                        type: 'error',
                                        message: res.data.message,
                                        confirmButtonText: '知道了',
                                        confirmButtonClass: 'is-plain'
                                    });
                                    this.isLoading = false;
                                }
                            });
                    }
                });
            },
            formatRowData (rowData){

                for(let i in rowData){
                    if(rowData[i].parentId == ''){
                        rowData[i].parentId = 0;
                    }else{
                        rowData[i].parentId = +rowData[i].parentId;
                    }
                    if(rowData[i].relationType == ''){
                        rowData[i].relationType = 0;
                    }else{
                        rowData[i].relationType = +rowData[i].relationType;
                    }
                    if(rowData[i].billType == ''){
                        rowData[i].billType = 0;
                    }else{
                        rowData[i].billType = +rowData[i].billType;
                    }
                    rowData[i].updateUser = +Cookie.get('t8t-it-uid');
                    if(rowData[i].id){

                    }else{
                        rowData[i].moduleId = this.$route.query.id;
                        rowData[i].createUser = +Cookie.get('t8t-it-uid');
                    }
                    if(rowData[i].lastNode == 1 && !rowData[i].billType){
                        this.$msgbox({
                            title: '消息',
                            type: 'error',
                            message: '末级节点必须添加单据类型！',
                            confirmButtonText: '知道了',
                            confirmButtonClass: 'is-plain'
                        });
                        return false;
                    }
                    if(rowData[i].lastNode == 0 && rowData[i].billType){
                        this.$msgbox({
                            title: '消息',
                            type: 'error',
                            message: '非末级节点不能添加单据类型！',
                            confirmButtonText: '知道了',
                            confirmButtonClass: 'is-plain'
                        });
                        return false;
                    }
                }
                return rowData;
            },
            addNodeRel(){
                 let totalRows = this.$refs['relNodeTable'].totalRows;
                 this.$refs['relNodeTable'].addNewRow(totalRows)
            },
            delNodeRel(){
                if(this.$refs['relNodeTable'].selectedRows.length < 1){
                    this.$message.error('请选择需要删除的关系！')
                }
                let flage = true;
                this.$refs['relNodeTable'].selectedRows.forEach((item) => {
                    if(typeof(item.id) !== 'undefined' && item.id > 0){
                        this.$message.error('已保存的节点不能被删除！')
                        flage = false;
                    }
                })

               if(flage) this.$refs['relNodeTable'].delRows()
            },
            getNodeList(moduleId){
                let args = {
                    search:{moduleId_eq: Number.parseInt(moduleId)},
                    fields:['id', 'nodeTypeName', 'nodeType'],
                    page:1,
                    size:500
                }
                   axios({
                        method: Service.TEMPLATE.methods.moduleItemQueryPage,
                        service: Service.TEMPLATE.name,
                        args: args
                    }).then((res) => {
                        if (res.data.status === 200) {
                               this.nodeList = []
                               let list = res.data.result.rows
                               list.forEach((item) =>{
                                   let tmp = {
                                         value:item.id,
                                        label:item.nodeTypeName
                                   }
                                   this.nodeList.push(tmp)
                               })

                        }
                    })
            },
            nodeRelRowChange(cell,value){
              // console.info(cell)
            },
            changeRelHeadId(data, index, row, cell){
                let nodes_list = this.nodeList
                var ndata = {}
                if(typeof(nodes_list) != 'object' || nodes_list.length < 1) return;
                    for (let i = nodes_list.length - 1; i >= 0; i--) {
                    if(nodes_list[i]['value'] == data){
                         ndata = {
                            headId:nodes_list[i]['value'],
                            headNodeTypeName:nodes_list[i]['label']
                        }
                    }
                }
                let list = this.$refs['relNodeTable'].dataSource
                let line = cell.$index;
                let oldData = list[line]
                Object.assign(oldData, ndata)
                this.$refs['relNodeTable'].dataSource[line] = oldData
            },
               changeRelTailId(data, index, row, cell){
                let nodes_list = this.nodeList
                var ndata = {}
                if(typeof(nodes_list) != 'object' || nodes_list.length < 1) return;
                    for (let i = nodes_list.length - 1; i >= 0; i--) {
                    if(nodes_list[i]['value'] == data){
                         ndata = {
                            tailId:nodes_list[i]['value'],
                            tailNodeTypeName:nodes_list[i]['label']
                        }

                    }
                }
                let list = this.$refs['relNodeTable'].dataSource
                let line = cell.$index;
                let oldData = list[line]
                Object.assign(oldData, ndata)
                this.$refs['relNodeTable'].dataSource[line] = oldData
            },
            saveNodeRel(){
                let list = this.$refs['relNodeTable'].dataSource
                let addItems = []
                let udpItems = []
                if(!Number.isFinite(Number(this.$route.query.id))){
                    this.$message.error('模板排期不存在')
                    return
                }
                this.$refs['relNodeTable'].validate((isValid) => {
                    if(isValid){
                                let flage = true
                               list.forEach((item, i) => {
                                       if(Number.isNaN(Number(item.headId)) || item.headId === null){
                                            this.$message.error(`第${i + 1}行头结点不能为空！`)
                                            flage = false
                                            return
                                       }
                                       if(Number.isNaN(Number(item.tailId)) || item.tailId === null){
                                            this.$message.error(`第${i + 1}行尾结点不能为空！`)
                                            flage = false
                                             return
                                       }
                                       if(!flage) return
                                       // item.effectTime = Number.isFinite(item.effectTime) ?
                                       //      item.effectTime :
                                       //      +Date.parse(item.effectTime).toString().substr(0,10);
                                        if(item.id == null){

                                             addItems.push({     //新增列表
                                                                "moduleId":this.$route.query.id,
                                                                "headId":item.headId,
                                                                "tailId":item.tailId,
                                                                "advance":item.advance,
                                                                "relationType":item.relationType,
                                                                "createUser":Cookie.get('t8t-it-uid'),
                                                                "relationStatus":item.relationStatus,
                                                                "triggerType":item.triggerType,
                                                                "effectTime":item.effectTime,
                                                           })
                                          }else{
                                            udpItems.push({
                                                                "moduleId":this.$route.query.id,
                                                                "id":item.id,
                                                                "headId":item.headId,
                                                                "tailId":item.tailId,
                                                                "advance":item.advance,
                                                                "relationType":item.relationType,
                                                                "updateUser":Cookie.get('t8t-it-uid'),
                                                                "relationStatus":item.relationStatus,
                                                                "triggerType":item.triggerType,
                                                                "effectTime":item.effectTime,
                                                           })
                                          }


                                        })
                                if(!flage || (udpItems.length < 1 && addItems.length < 1)) return;
                                let args = {
                                        "addItemRelations" : addItems,
                                        "updateItemRelations":udpItems
                                }

                                    axios({
                                        method: Service.TEMPLATE.methods.NodeRelationSave,
                                        service: Service.TEMPLATE.name,
                                        args: args
                                      }).then((res) => {
                                                    if (res.data.status === 200) {
                                                        this.$message({
                                                            type: 'success',
                                                            message: '修改成功！'
                                                        });
                                                        this.$refs['relNodeTable'].reloadTable()
                                                    }else{
                                                        this.$message({
                                                            type: 'error',
                                                            message: res.data.message
                                                        })
                                                    }
                                        })
                                    }
                })

            },
            //查看详情
            showDetail: function(id,nodeType){
                this.$router.push({
                    path: '/delivery/node-attribute',
                    query:{id: id, nodeType: nodeType}
                })
            },
        }
    };

</script>

<style lang="css" scoped>
    .t8t-full-dialog .my-container{
        display: flex;
        flex: 1;
        flex-direction: column;
        padding: 0 30px;
    }
    .t8t-full-dialog .my-toolbar{
        margin-bottom: 15px;
    }
</style>

<style>
    .t8t-full-dialog .el-dialog__header{
        padding: 0;
    }
    .t8t-full-dialog .el-dialog__body{
        padding: 0;
        height: 100%;
    }
    .t8t-full-dialog .t8t-full-dialog-container{
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .t8t-full-dialog .full-dialog-tabs-container{
        flex: 1;
        margin-bottom: 20px;
    }
    .t8t-full-dialog .full-dialog-toolbar-container{
        height: 38px;
        background-color: #1e3046;
    }
    .t8t-full-dialog .toolbar-container{
        width: 1220px;
        margin: 0 auto;
        padding-left: 15px;
        height: 100%;
        display: flex;
        align-items: center;
        background-color: #1e3046;
    }
    .t8t-full-dialog .toolbar-container .toolbar-button{
        padding: 0 12px;
        height: 26px;
        font-size: 12px;
        background-color: #1e3046;
        color: #d1dde9;
        border: 1px solid #09131d;
    }
    .t8t-full-dialog .toolbar-container .toolbar-button:hover{
        color: #1e3046;
        background-color: #d2deeb;
    }
    .t8t-full-dialog .container-center{
        width: 1220px;
        margin-left: auto;
        margin-right: auto;
    }
    .t8t-full-dialog .el-form{
        display: flex;
        flex-wrap: wrap;
    }
    .t8t-full-dialog .form-item-container{
        width: 25%;
    }
    .t8t-full-dialog .full-dialog-form-container{
        margin-bottom: 10px;
        min-height: 240px;
    }
    .t8t-full-dialog .full-dialog-form-container .el-form-item__content{
        width: 180px;
    }
    .t8t-full-dialog .full-dialog-tabs-container{
        display: flex;
    }
    .t8t-full-dialog .el-tabs{
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    .t8t-full-dialog .full-dialog-tabs-container .el-tabs__item{
        font-size: 12px;
        height: 22px;
        line-height: 22px;
        margin-top: 13px;
        margin-bottom: 12px;
    }
    .t8t-full-dialog .el-tabs__header{
        border-top: 2px solid #eff7fa;
        border-bottom: 2px solid #eff7fa;
    }
    .t8t-full-dialog .full-dialog-tabs-container .el-tabs__active-bar{
        height: 1px;
    }
    .t8t-full-dialog .el-tabs__item + .el-tabs__item {
        border-left: 1px solid #d4dce7;
    }
    .t8t-full-dialog .el-tabs__nav-wrap{
        width: 1220px;
        margin: 0 auto;
    }
    .t8t-full-dialog .el-tabs__content{
        flex: 1;
        display: flex;
        /*        width: 1220px;
                margin: 0 auto;*/
    }
    .t8t-full-dialog .el-tab-pane{
        display: flex;
        flex: 1;
        flex-wrap: wrap;
        overflow: auto;
    }
    /* 顶部tab */
    .t8t-full-dialog .full-dialog-form-container .el-tabs__item{
        font-size: 12px;
        height: 22px;
        line-height: 22px;
        margin-top: 13px;
        margin-bottom: 12px;
    }
    .t8t-full-dialog .full-dialog-form-container .el-tabs__header {
        border-top: 0;
        border-bottom: 0;
    }
    .el-row {
        padding-left: 20px;
        width:600px;
        margin-bottom: 20px;
    &:last-child {
         margin-bottom: 0;
     }
    }
    .el-col {
        border-radius: 4px;
    }
    .bg-purple-dark {
        background: #99a9bf;
    }
    .bg-purple {
        background: #d3dce6;
    }
    .bg-purple-light {
        background: #e5e9f2;
    }
    .grid-content {
        border-radius: 4px;
        min-height: 36px;
    }
    .row-bg {
        padding: 10px 0;
        background-color: #f9fafc;
    }
    .el-tabs__active-bar{
        height:1px;
    }
</style>
