export default {

    gatewayAddr: 'https://scmgw.to8to.com'

}
