sidebar组件
author：allen.yao
