<template>
    <el-upload
        action="action"
        :headers="headers"
        :multiple="multiple"
        :data="data"
        name="name"
        :with-credentials="withCredentials"
        :show-file-list="showFileList"
        :drag="drag"
        :accept="accept"
        :list-type="listType"
        :auto-upload="autoUpload"
        :file-list="fileList"
        @on-preview="onPreview"
        @on-remove="onSuccess"
        @on-error="onError"
        @on-progress="onProgress"
        @on-change="onChange"
        @before-upload="beforeUpload"
    >
    </el-upload>
</template>

<script>
    import Server from 'src/config/server.js'
    export default {
        name: 't8t-upload',
        data () {
            return {
            }
        },
        props: {
            action: {
                type: String,
                default: Server.gatewayAddr
            },
            data: Object,
            headers: Object,
            multiple: {
                type: Boolean,
                default: false
            },
            name: {
                type: String,
                default: 'file'
            },
            'withCredentials': Boolean,
            'show-file-list': {
                type: Boolean,
                default: false
            },
            drag: {
                type: Boolean,
                default: false
            },
            accept: String
        },
        methods: {
            onPreview (file) {
                this.$emit('on-preview', file)
            },
            onRemove (file, fileList) {
                this.$emit('onRemove', file, fileList)
            },
            onSuccess (response, file, fileList) {
                this.$emit('on-success', response, file, fileList)
            },
            onError (err, file, fileList) {
                this.$emit('on-error', err, file, fileList)
            },
            onProgress (event, file, fileList) {
                this.$emit('on-progress', event, file, fileList)
            },
            onChange (file, fileList) {
                this.$emit('on-change', file, fileList)
            },
            beforeUpload (file) {
                if (!this.checkFileType(file)) {
                    return false
                }
                this.$emit('before-upload', file)
            },
            checkFileType (file) {
                return true
            }
        }
    }
</script>

<style lang="css" scoped>

</style>
