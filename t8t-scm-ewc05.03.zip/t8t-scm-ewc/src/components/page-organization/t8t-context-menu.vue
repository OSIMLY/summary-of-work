<template>
    <transition name="fade">
        <div :style="ctxStyle" v-clickoutside="handleOutsideClick" v-show="menuVisible" class="ctx-menu-content">
            <slot></slot>
            <div class="el-table-filter">
                <ul class="el-table-filter__list">
                    <li class="el-table-filter__list-item" v-for="item in items" @click="itemClick(item)"><i :class="item.icon" style="margin-right:10px"></i>{{ item.name }}</li>
                </ul>
            </div>
        </div>
    </transition>
</template>

<script>
    import Clickoutside from '../element-ui/lib/utils/clickoutside'
    export default {
        name: 'CtxMenu',
        data() {
            return {
                test: 0
            }
        },
        directives: {
            Clickoutside
        },
        props: {
            items: {
                type: Array,
                default() {
                    return [{
                        name: '新建',
                        action: 'add',
                        icon: 'el-icon-plus'
                    }, {
                        name: '编辑',
                        action: 'edit',
                        icon: 'el-icon-edit'
                    }, {
                        name: '删除',
                        action: 'delete',
                        icon: 'el-icon-delete'
                    }, {
                        name: '查看',
                        action: 'view',
                        icon: 'el-icon-search'
                    }]
                }
            },
            menuVisible: Boolean,
            menuTop: Number,
            menuLeft: Number
        },
        methods: {
            handleOutsideClick(event) {
                this.menuVisible = false
            },
            setPositionFromEvent(event) {
                const {
                    pageX,
                    pageY
                } = event
                this.menuTop = pageY - (document.body.scrollTop)
                this.menuLeft = pageX
            },
            openMenu: function (event) {
                this.menuVisible = true
                this.setPositionFromEvent(event)
                event.preventDefault()
                event.stopPropagation()
                return false
            },
            closeMenu: function (event) {
                this.menuVisible = false
            },
            itemClick: function (item) {
                console.log(item)
                this.$emit('menuClick', item.action)
                this.closeMenu()
            }
        },
        computed: {
            ctxStyle() {
                return {
                    'top': (this.menuTop || 0) + 'px',
                    'left': (this.menuLeft || 0) + 'px'
                }
            }
        }
    }

</script>

<style lang="css">
    .ctx-menu {
        -webkit-touch-callout: none;
        /* iOS Safari */
        -webkit-user-select: none;
        /* Chrome/Safari/Opera */
        -khtml-user-select: none;
        /* Konqueror */
        -moz-user-select: none;
        /* Firefox */
        -ms-user-select: none;
        /* Internet Explorer/Edge */
        user-select: none;
    }

    .ctx-menu-content {
        z-index: 5000;
        top: 0;
        left: 0;
        min-width: 100px;
        position: absolute;
        padding: 0px 0px;
        line-height: 24px;
    }

    .ctx-menu-content ul {
        list-style: none;
        padding: 0px 0px;
        margin: 0px;
    }

    .ctx-menu-content ul li {
        padding-left: 10px;
        padding-right: 10px;
    }

    .ctx-menu-content ul li:hover {
        /*background-color: gray;*/
        background-color: #e5e9f2;
        color: #475669;
    }

    .fade-enter-active,
    .fade-leave-active {
        transition: opacity .5s
    }

    .fade-enter,
    .fade-leave-active {
        opacity: 0
    }
</style>
