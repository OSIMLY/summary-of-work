<template>
    <div class="t8t-table">
        <!--按钮组-->
        <div class="toolbar-container">
            <!--<el-button
                size="toolbar"
                v-show="!isEditable"
                @click="btnInsertClick()"
            >添加</el-button>-->
            <el-button
                size="toolbar"
                v-show="!isEditable"
                :disabled="isEditable"
                @click="btnEdit"
            >修改</el-button>
            <!--<el-button
                size="toolbar"
                @click="btnDeleteClick()"
            >删除</el-button>-->
            <el-button
                size="toolbar"
                v-show="!isEditable"
                :disabled="isEditable"
                @click="btnLook"
            >查看</el-button>
        </div>
        <!--数据表-->
        <div class="table-container">
            <el-table
                ref="mainTable"
                height="theHeight"
                border
                stripe
                v-loading="isLoading"
                :data="localData"
                :style="{height:'100%'}"
                :row-class-name="tableRowClassName"
                @current-change="handleCurrentRowChange"
                @row-dblclick="handleRowDblclick"
                @selection-change="handleSelectionChange"
                @row-click="handleRowClick"
                @sort-change="handleSortChange"
            >
                <el-table-column
                    header-align="center"
                    align="center"
                    type="selection"
                    fixed
                    width="38"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="code"
                    label="组织编码"
                    sortable="custom"
                    min-width="200"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    prop="name"
                    label="组织名称"
                    sortable="custom"
                    min-width="200"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="typeCode"
                    :formatter="fmtTypeCode"
                    label="组织形态"
                    sortable="custom"
                    min-width="200"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="contactUser"
                    label="联系人"
                    sortable="custom"
                    :formatter="fmtContactUser"
                    min-width="200"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    prop="location"
                    label="地址"
                    sortable="custom"
                    min-width="200"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="isDel"
                    label="禁用状态"
                    sortable="custom"
                    min-width="200"
                    :formatter="fmtIsDel"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="description"
                    label="描述"
                    sortable="custom"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
            </el-table>
        </div>
        <!--分页栏-->
        <div class="pagenav-container">
            <t8t-el-pagination
                @current-change="handleCurrentPageChange"
                @size-change="handleSizeChange"
                :current-page="currentPage"
                :total="totalPages"
                layout="sizes, first, prev, jumper, next, last, refresh, ->, total"
                :page-sizes="[5,10,20,30,50]"
                :page-size="pageSize"
            >
            </t8t-el-pagination>
        </div>
    </div>
</template>

<script>
    import T8tTableInput from '../t8t-table/t8t-table-input.vue'
    import T8tTableSelect from '../t8t-table/t8t-table-select.vue'
    export default {
        name: 'T8tTable',
        components: {
            T8tTableInput,
            T8tTableSelect
        },
        data() {
            return {
                localData: [],
                isEditable: false,
                selection: [],
            }
        },
        computed: {
            //表格数据
            tableData: {
                get() {
                    return this.$store.state.organization.tableData
                },
                set(value) {
                    this.$store.commit('SET_TABLEDATA', value)
                }
            },
            //空数据行模板
            blankData: {
                get() {
                    let strBlankData = JSON.stringify(this.$store.state.blankData)
                    return JSON.parse(strBlankData)
                }
            },
            //通用数据
            commonData() {
                return this.$store.state.organization.commonData
            },
            typeCodeOptions() {
                return this.$store.state.organization.typeCodeOptions
            },
            functionCodeOptions() {
                return this.$store.state.organization.functionCodeOptions
            },
            //表格状态
            tableStatus: {
                get() {
                    return this.$store.state.organization.tableStatus
                },
                set(value) {
                    this.$store.commit('SET_TABLESTATUS', value)
                }
            },
            //当前行数据对象
            currentRow: {
                get() {
                    return this.$store.state.organization.tableStatus.viewStatus.currentRow
                },
                set(value) {
                    this.$store.commit('SET_TAB_VIEW_CURRENTROW', value)
                }
            },
            //当前行序号
            currentIndex: {
                get() {
                    return this.$store.state.organization.tableStatus.viewStatus.currentIndex
                },
                set(value) {
                    this.$store.commit('SET_TAB_VIEW_CURRENTINDEX', value)
                }
            },
            //是否显示加载中画面
            isLoading: {
                get() {
                    return this.$store.state.organization.tableStatus.viewStatus.isLoading
                },
                set(value) {
                    this.$store.commit('SET_TAB_VIEW_ISLOADING', value)
                }
            },
            //当前页
            currentPage: {
                get() {
                    return this.$store.state.organization.tableStatus.pageStatus.currentPage
                },
                set(value) {
                    this.$store.commit('SET_TAB_PAGE_CURRENTPAGE', value)
                }
            },
            //每页条目数量
            pageSize: {
                get() {
                    return this.$store.state.organization.tableStatus.pageStatus.pageSize
                },
                set(value) {
                    this.$store.commit('SET_TAB_PAGE_PAGESIZE', value)
                }
            },
            //页码总数
            totalPages: {
                get() {
                    return this.$store.state.organization.tableStatus.pageStatus.totalPages
                },
                set(value) {
                    this.$store.commit('SET_TAB_PAGE_TOTAL', value)
                }
            },
            //排序状态
            sortStatus: {
                get() {
                    return this.$store.state.organization.tableStatus.sortStatus
                },
                set(value) {
                    this.$store.commit('SET_TAB_SORT', value)
                }
            },
            // add by allen.yao
            SelectedRows: {
                get() {
                    return this.$store.state.organization.tableStatus.SelectedRows
                },
                set(value) {
                    this.$store.commit('SET_TABLE_SelectedRows', value)
                }
            }
        },
        watch: {
            //state变化更新本地数据localData
            tableData: {
                handler: function (val, oldVal) {
                    this.localData = []
                    let strTableData = JSON.stringify(val)
                    this.localData = JSON.parse(strTableData)
                    console.log(this.localData)
                }
            },
            //切换编辑状态
            isEditable: function (val, oldVal) {
                if (val && !oldVal) {
                    this.clearSelection()
                    this.localData.unshift(this.blankData)
                } else if (oldVal && !val) {
                    this.localData.shift()
                }
            }
        },
        methods: {
            /*事件回调函数*/
            //处理选中行变化
            handleSelectionChange(val) {
                this.selection = val
            },
            //处理页码变化
            handleCurrentPageChange(val) {
                this.$store.commit('SET_TAB_PAGE_CURRENTPAGE', val)
                this.$store.dispatch('loadTableData1')
            },
            //处理每页行数变化
            handleSizeChange(val) {
                this.$store.commit('SET_TAB_PAGE_PAGESIZE', val)
                this.$store.dispatch('loadTableData1')
            },
            //处理行双击事件
            handleRowDblclick(row, event) {
                this.showEditDialog('retrieve')
            },
            //处理行单击事件
            handleRowClick(row, event, column) {
                if (column.type !== 'selection' && !this.isEditable) {
                    this.$refs.mainTable.toggleRowSelection(row)
                }
            },
            //处理当前行改变
            handleCurrentRowChange(curRow, oldRow) {
                let index = this.localData.indexOf(curRow)
                this.currentRow = curRow
                this.currentIndex = index
            },
            //显示对话框
            showEditDialog(arg) {
                if (!this.isEditable) {
                    this.$store.commit('INIT_DIALOG', {
                        isShow: true,
                        status: arg
                    })
                }
            },
            //点击新增按钮
            btnInsertClick() {
                //this.localData.unshift(this.blankData)
                this.currentRow = this.blankData
                this.currentIndex = 0
                this.showEditDialog()
            },
            btnEdit() {
                // 编辑
                if (this.selection.length === 0) {
                    this.$msgbox({
                        title: '消息',
                        type: 'warning',
                        message: '请选择要处理的行。',
                        showCancelButton: false,
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        confirmButtonClass: 'is-plain'
                    })
                    return
                } else {
                    this.showEditDialog('update')
                }
            },
            btnLook() {
                // 查看
                if (this.selection.length === 0) {
                    this.$msgbox({
                        title: '消息',
                        type: 'warning',
                        message: '请选择要处理的行。',
                        showCancelButton: false,
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        confirmButtonClass: 'is-plain'
                    })
                    return
                } else {
                    this.showEditDialog('retrieve')
                }
            },
            //点击删除按钮
            btnDeleteClick() {
                let index
                let selectedIndex = []
                if (this.selection.length === 0) {
                    this.$message.error('请选择要处理的行。')
                } else {
                    this.$confirm('确定删除此项吗？', '提示', {
                        type: 'warning'
                    }).then(() => {
                        this.selection.forEach((item) => {
                            selectedIndex.push(item.id)
                        })
                        if (!this.isEditable) {
                            this.$store.commit('DEL_TAB_DATA_ROW', selectedIndex)
                        }
                        this.$message({
                            type: 'success',
                            message: '删除成功！'
                        })
                    })
                }
            },
            //清除选区
            clearSelection() {
                this.$refs.mainTable.clearSelection()
            },
            //判断表格处于可编辑状态
            isSelectable(row, index) {
                if (this.isEditable) {
                    return false
                } else {
                    return true
                }
            },
            //判断行可编辑
            getRowEditable(row) {
                let isBlankRow = (row === this.localData[0])
                let isCurrentRow = (row === this.currentRow)
                if (this.isEditable && (isBlankRow || isCurrentRow)) {
                    return true
                } else {
                    return false
                }
            },
            //内嵌表单弹框编辑
            handleIconClick(row) {
                this.currentRow = row
                this.dialogData.typeCode = this.currentRow.typeCode
                this.$refs.codeSelector.open()
            },
            //提交内嵌表单
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.isEditable = false
                        this.clearSelection()
                        this.$message.info('提交成功！')
                    } else {
                        this.$message.info('请完善表单信息。')
                    }
                })
            },
            //重置内嵌表单
            resetForm(formName) {
                this.$refs[formName].resetFields()
                this.isEditable = false
            },
            //切换选中行样式
            tableRowClassName(row, index) {
                const exsist = this.selection.indexOf(row)
                if (exsist !== -1) {
                    return 'selected-row'
                }
            },
            //格式化字段 - 组织形态
            fmtTypeCode(row, column) {
                let item = this.typeCodeOptions.filter((item) => item.id === row.typeCode)
                if (item[0]) { return item[0].name }
            },
            //格式化字段 - 联系人
            fmtContactUser(row, column) {
                let item = this.commonData.contactUser.filter((item) => item.value === row.contactUser)
                if (item[0]) { return item[0].text }
            },
            //格式化字段 - 禁用状态
            fmtIsDel(row, column) {
                let item = this.commonData.isDel.filter((item) => item.value === row.isDel)
                if (item[0]) { return item[0].text }
            },
            //显示红色 '*' 必填列
            //<el-table-column :render-header="required">
            required(h, {
                column,
                $index
            }) {
                return h('span', {}, [h('span', {
                    attrs: {
                        class: 'required-tag'
                    }
                }, '* '), h('span', column.label)])
            },
            //处理表头排序
            handleSortChange({
                column,
                prop,
                order
            }) {
                switch (order) {
                    case 'ascending':
                        this.sortStatus = [prop + '_asc']
                        break
                    case 'descending':
                        this.sortStatus = [prop + '_desc']
                        break
                    default:
                        this.sortStatus = [prop + '_asc']
                }
                this.$store.dispatch('loadTableData1')
            },
        }
    }

</script>

