<template>
    <div class="t8t-table-input">
        <t8t-el-form-item :prop="prop" :row="rowNum" :rules="rules" v-if="editable">
            <el-input v-model="currentValue" :readonly="readonly" :icon="icon" :placeholder="placeholder" :on-icon-click="handleInputClick">
            </el-input>
        </t8t-el-form-item>
        <span v-else="editable" v-text="value">
        </span>
    </div>
</template>
<script>
    export default {
        name: 't8t-table-input',
        data() {
            return {
                currentValue: this.value
            }
        },
        watch: {
            'value' (val) {
                this.currentValue = val
            },
            currentValue(val) {
                this.$emit('input', val)
                this.$emit('change', val)
            }
        },
        props: {
            prop: String, // 绑定字段名
            editable: Boolean, // 切换编辑、显示状态
            rowNum: Number, // 行号
            rules: [Object, Array], // 验证规则
            value: [String, Number], // 表单值
            icon: String, // 图标按钮
            placeholder: String, // 占位文字
            readonly: Boolean,
            onInputClick: Function
        },
        methods: {
            handleInputClick(event) {
                if (this.onInputClick) {
                    this.onInputClick(event)
                }
                this.$emit('onInputClick', event)
            }
        }
    }

</script>
<style lang="css" scoped>
    .el-form-item {
        margin-bottom: 0px;
    }

</style>
