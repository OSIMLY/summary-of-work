<template>
    <div
        class="t8t-tree-container"
        :class="{ 'is-hide': isHide }"
    >
        <div class="t8t-tree">
            <div class="tree-select">
                <el-input
                    icon="search"
                    v-model="queryString"
                    placeholder="搜索"
                ></el-input>
            </div>
            <div class="tree-outer">
                <el-tree
                    :data="treeData"
                    :props="treeProps"
                    ref="treeRef"
                    :filter-node-method="filterData"
                    node-key="id"
                    :default-expanded-keys="keys"
                    @node-click="onClick"
                    emptyText="暂无数据"
                    highlight-current
                    :expand-on-click-node="false"
                ></el-tree>
            </div>
        </div>
        <div
            class="tree-hide el-icon-d-arrow-left"
            @click="onHide"
            :class="{'el-icon-d-arrow-right': isHide}"
        ></div>
    </div>
</template>
<script>
    export default {
        name: 't8t-tree',
        props: {
            data: {
                type: Array,
                default() {
                    return []
                },
                required: true
            }
        },
        data() {
            return {
                keys: [1],
                treeData: this.data,
                treeProps: {
                    label: 'name',
                    children: 'children'
                },
                queryString: '',
                isHide: false
            }
        },
        watch: {
            queryString: function (qs) {
                this.$refs['treeRef'].filter(qs)
            }
        },
        methods: {
            onHide() {
                this.isHide = !this.isHide
            },
            filterData(value, data, node) {
                var item = data[this.treeProps.label].toLowerCase()
                var qs = value.toLowerCase()
                if (!value) return true
                if (item.indexOf(qs) > -1) {
                    return true
                }
            },
            onClick(data, node, component) {
                this.$store.commit('SET_TAB_VIEW_ISLOADING', true)
                this.$store.dispatch('tree2table', {
                    parentId: data.id,
                    size: this.$store.state.organization.tableStatus.pageStatus.pageSize,
                    // 搜索的时候重新从第一页开始
                    page: 0
                })
            }
        }
    }

</script>

<style
    lang="css"
    scoped
>
    .t8t-tree-container {
        width: 300px;
        position: relative;
        transition: all 0.3s;
        border-right: 1px solid #d4dce7;
        -webkit-user-select: none;
    }

    .t8t-tree-container.is-hide {
        width: 0;
        border-right: 0 solid #fff;
    }

    .t8t-tree-container .tree-hide {
        position: absolute;
        top: 14px;
        right: 0;
        transform: translate3d(100%, 0, 0);
        cursor: pointer;
        font-size: 12px;
        color: #666;
        padding: 5px;
    }

    .t8t-tree {
        height: 100%;
        overflow: hidden;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
    }

    .t8t-tree .tree-select {
        padding: 10px;
        border-bottom: 1px solid #d4dce7;
        height: 30px;
        width: 280px;
    }

    .t8t-tree .tree-outer {
        flex: 1;
        position: absolute;
        top: 51px;
        left: 0;
        right: 0;
        bottom: 0;
        overflow: scroll;
    }

    .chrome_lower .t8t-tree .tree-outer {
        position: absolute;
        top: 51px;
        left: 0;
        right: 0;
        bottom: 0;
        overflow: scroll;
    }

    .t8t-tree .tree-select .el-select {
        width: 100%;
    }

    .t8t-tree .el-tree {
        flex: 1;
        padding: 7px;
    }

    .chrome_lower .t8t-tree .el-tree {
        /*flex: 1;*/
        padding: 7px;
    }
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    .t8t-tree .el-input__inner {
        height: 30px;
        font-size: 12px;
    }

    .t8t-tree .el-tree-node__label {
        font-size: 12px;
    }

    .t8t-tree .tree-select {
        font-size: 12px;
    }

    .t8t-tree .el-tree-node__content {
        height: 25px;
        line-height: 25px;
    }

    .t8t-tree .el-checkbox__input {
        margin-top: -3px;
    }
</style>

<style>
    /* tree */
    .chrome_lower .tree-outer .el-tree-node>.el-tree-node__children {
        overflow: inherit !important;
    }

    .t8t-tree .el-tree {
        border: none;
        width: 350px;
    }

    .t8t-tree .el-tree-node__content {
        display: flex;
        align-items: center;
    }

    .t8t-tree .el-tree .erp-tree-icon {
        width: 13px;
        margin: 0px 8px 0;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .el-tree .el-checkbox {
        margin-right: 8px;
    }

    .t8t-tree .erp-tree-plus {
        width: 13px;
        height: 13px;
        margin: 0px 8px 0;
        background-image: url(./img/icon01.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-minus {
        width: 13px;
        height: 13px;
        margin: 0px 8px 0;
        background-image: url(./img/icon02.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-folder {
        width: 15px;
        height: 13px;
        margin: 0px 8px 0 0;
        background-image: url(./img/icon03.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-folder-open {
        width: 15px;
        height: 13px;
        margin: 0px 8px 0 0;
        background-image: url(./img/icon04.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-leaf {
        width: 11px;
        height: 15px;
        margin: 1px 6px 0 2px;
        background-image: url(./img/icon05.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-checked {
        width: 11px;
        height: 15px;
        margin: 1px 8px 0 0;
        background-image: url(./img/icon06.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .el-tree-node__content.is-disabled {
        cursor: not-allowed!important;
    }

    .t8t-tree .el-tree-node__content.is-disabled .el-tree-node__label {
        color: #666!important;
    }

    .t8t-tree .el-tree-node__content.is-disabled .erp-tree-leaf,
    .t8t-tree .el-tree-node__content.is-disabled .erp-tree-checked {
        background-image: url(./img/icon07.png)!important;
    }

    .t8t-tree .el-tree-node__content:hover {
        background: #fff;
        color: #3396fb;
    }

    .t8t-tree .el-tree-node__content:hover .erp-tree-leaf {
        background-image: url(./img/icon06.png);
    }

    .t8t-tree .erp-tree-highlight {
        color: #3396fb;
    }
</style>
