<template>
    <div class="t8t-search" :class="searchMore?'h-auto':''">
        <el-form :inline="true" :model="searchLocal" label-position="left" label-width="100px" @keyup.enter.native="handleSubmit()">
            <div class="search-left-box">
                <div class="search-group">
                    <el-form-item label="组织名称">
                        <el-input v-model="searchLocal.name_like" placeholder=""></el-input>
                    </el-form-item>
                </div>
                <div class="search-group">
                    <el-form-item label="组织形态">
                        <el-select v-model="searchLocal.typeCode" placeholder="--请选择--">
                            <el-option label="--请选择--" value="">
                            </el-option>
                            <el-option v-for="item in typeCodeOptions" :label="item.name" :value="item.code">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </div>
                <div class="search-group">
                    <el-form-item label="组织职能">
                        <el-select v-model="searchLocal.functionCode" placeholder="--请选择--">
                            <el-option label="--请选择--" value="">
                            </el-option>
                            <el-option v-for="item in functionCodeOptions" :label="item.name" :value="item.code">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </div>
                <div class="search-group">
                    <el-form-item label="禁用状态">
                        <el-select v-model="searchLocal.isDel" placeholder="--请选择--">
                            <el-option label="--请选择--" value="">
                            </el-option>
                            <el-option label="是" value='1'></el-option>
                            <el-option label="否" value='0'></el-option>
                        </el-select>
                    </el-form-item>
                </div>
            </div>
            <div class="search-right-box">
                <div class="search-group-cli">
                    <span class="more-serach" @click="toggleSearchBtn()">更多查询 <i class="el-icon-d-arrow-left"></i></span class="more-serach">
                    <el-button type="primary" @click="handleSubmit()">查询</el-button>
                    <el-button @click="resetFrom()">重置</el-button>
                </div>
            </div>
        </el-form>
    </div>
</template>

<script>
    export default {
        name: 'search',
        data() {
            return {
                searchMore: false,
                searchLocal: {
                    name_like: null,
                    typeCode: null,
                    functionCode: null,
                    isDel: null
                }
            }
        },
        computed: {
            typeCodeOptions() {
                return this.$store.state.organization.typeCodeOptions
            },
            functionCodeOptions() {
                return  this.$store.state.organization.functionCodeOptions
            }
        },
        mounted() {
            this.$store.dispatch('getConfigData')
        },
        methods: {
            toggleSearchBtn: function () {
                this.searchMore = !this.searchMore
            },
            handleSubmit: function () {
                var search = this.searchLocal;
                var copySearch = Object.assign({},search);
                if (copySearch.isDel) {
                    copySearch.isDel = parseInt(copySearch.isDel);
                };
                for ( var i in copySearch) {
                    if(copySearch[i]=='') {
                        copySearch[i] = null;
                    }
                }
                // 页数重置
                copySearch.page = 0
                this.$store.commit('SET_SEARCH',copySearch);
                this.$store.dispatch('loadTableData1');
            },
            resetFrom: function () {
                this.searchLocal = {
                    name: null,
                    typeCode: null,
                    functionCode: null,
                    isDel: null
                }
                this.$store.dispatch('resetOrganization')
            }
         }
    }

</script>

<style lang="css" scoped>

</style>


<style>
</style>
