<template>
    <div class="page-organization">
        <t8t-breadcrumb :data="breadcrumbData"></t8t-breadcrumb>
        <search></search>
        <div class="g-main-container">
            <t8t-tree :data="treeData"></t8t-tree>
            <t8t-temp-table></t8t-temp-table>
        </div>
        <t8t-dialog v-if="isShow"></t8t-dialog>
    </div>
</template>

<script>
    import T8tBreadcrumb from '../t8t-breadcrumb/t8t-breadcrumb.vue'
    import T8tTree from './t8t-tree.vue'
    import T8tTempTable from './t8t-temp-table.vue'
    import T8tDialog from './t8t-dialog.vue'
    import Search from './search.vue'
    import T8tToolbar from '../t8t-toolbar/t8t-toolbar.vue'
    export default {
        name: 'page-organization',
        components: {
            T8tBreadcrumb,
            T8tTempTable,
            T8tTree,
            T8tDialog,
            Search,
            T8tToolbar
        },
        data() {
            return {
                breadcrumbData: [{
                    title: '系统管理'
                },
                {
                    title: '主数据'
                },
                {
                    title: '组织机构'
                }
                ]
            }
        },
        computed: {
            treeData() {
                return this.$store.state.organization.treeData
            },
            isShow: {
                get() {
                    return this.$store.state.organization.dialogStatus.isShow
                },
                set(value) {
                    this.status = this.$store.state.organization.dialogStatus.status
                    this.$store.commit('SET_DIALOG_STATUS_ISSHOW', value)
                }
            }
        },
        created() {
            this.$store.dispatch('initTreeData')
            this.$store.dispatch('loadTableData1')
        },
        methods: {
            onView() {
                console.log('view')
            },
            onEdit() {
                console.log('edit')
            }
        }
    }

</script>

<style lang="css" scoped>
.list-container{
    display: flex;
    -ms-flex: 1;
    flex: 1;
    -ms-flex-direction: column;
    flex-direction: column;
    overflow: auto;
}
</style>


<style>
</style>
