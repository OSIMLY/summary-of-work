<template>
    <div class="t8t-table-select">
        <t8t-el-form-item :prop="prop" :row="rowNum" :rules="rules" v-if="editable">
            <el-select v-model="currentValue" :place-holder="placeholder">
                <el-option v-for="item in dataList" :label="item.text" :value="item.value"></el-option>
            </el-select>
        </t8t-el-form-item>
        <span v-else="editable" v-for="item in dataList">
            {{currentValue === item.value ? item.text : ""}}
            </span>
    </div>
</template>
<script>
    export default {
        name: 't8t-table-select',
        data() {
            return {
                currentValue: this.value
            }
        },
        watch: {
            'value' (val) {
                this.currentValue = val
            },
            currentValue(val) {
                this.$emit('input', val)
            }
        },
        props: {
            prop: String, // 绑定字段名
            dataList: Array, // 下拉列表数据源
            editable: Boolean, // 切换编辑、显示状态
            rowNum: Number, // 行号
            rules: [Object, Array], // 验证规则
            value: [String, Number], // 表单值
            placeholder: String, // 占位文字
            showTag: Boolean
        },
        methods: {
            setCurrentValue(value) {
                if (value === this.currentValue) return
                this.currentValue = value
                this.$emit('input', value)
                this.$emit('change', value)
            }
        }
    }

</script>
<style lang="css" scoped>
    .el-form-item {
        margin-bottom: 0px;
    }

</style>
