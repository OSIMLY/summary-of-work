<template>
    <div class="t8t-form-popup">
        <el-autocomplete
            v-model="text"
            :placeholder="placeholder"
            :disabled="disabled"
            :icon="icon"
            :name="name"
            :on-icon-click="onIconClick?onIconClick:toggleDialog"
            @change="onChange"

            :custom-item="customItem"
            :fetch-suggestions="fetchSuggestions?fetchSuggestions:(remote?querySearchAsync:querySearch)"
            :popper-class="popperClass"
            :trigger-on-focus="triggerOnFocus"
            @select="onSelect"
        >
        </el-autocomplete>
        <input type="hidden" ref="input" v-model="value">
        <t8t-form-popup-dialog
            v-if="dialogVisible"
            :size="dialog.size"
            :title="dialog.title"
            :searchForm="dialog.searchForm"
            :table="dialog.table"
            :onConfirm="dialog.onConfirm"
            @close="toggleDialog"
            @confirm="confirm"
        >
        </t8t-form-popup-dialog>
    </div>
</template>

<script>
import T8tFormPopupDialog from './t8t-form-popup-dialog.vue'

import axios from 'src/utils/axios'

    export default {
        name: 't8t-form-popup',
        components: {
            T8tFormPopupDialog,
        },
        data () {
            return {
                value: '',
                text: '',
                dialogVisible: false
            }
        },
        props: {
            name: String,
            placeholder: {
                type: String,
                default: ''
            },
            disabled: Boolean,
            icon: {
                type:String,
                default: 'search'
            },
            onIconClick: Function,
            textValue: String,
            bindValue: [String,Number,Array],
            defaultValue:[String,Number,Array],
            filedValue: String,
            records: {
                type: Array,
                default: []
            },
            dialog: {
                type: Object,
                default: {}
            },

            customItem: String,
            fetchSuggestions: Function,
            popperClass: String,
            triggerOnFocus: Boolean,
            options: {
                type: Array,
                default: []
            },
            remote: {
                type: Boolean,
                default: false
            },
            service: String,
            method: String,
            remoteArgs: {
                type:Object,
                default: {}
            },
            remoteQueryKey: String
        },
        created () {
            this.updateFields(this.records)
            if (this.defaultValue) {
                this.value = this.defaultValue
            }
            else {
                this.value = this.bindValue;
            }
        },
        watch: {
            records: function(val,oldVal) {
                this.updateFields(val)
            },
            value: function(val,oldVal) {
                if (val==='') {
                    this.setText('')
                };
                this.$emit('change',val,this.name)
            },
            textValue: function(val,oldVal) {
                this.setText(val)
            },
            bindValue: function(val,oldVal) {
                this.setValue(val)
            }
        },
        methods: {
            getText: function() {
                return this.text
            },
            getValue: function() {
                return this.value
            },
            getRecords: function(){
                return this.records
            },
            setText: function(text) {
                this.text = text
            },
            setValue: function(value) {
                this.value = value
            },
            updateFields: function(records){
                let length = records.length
                let value = []
                let text = []
                if (length>0) {
                    for(let i =0;i<length;i++){
                        value.push(records[i][this.filedValue])
                        text.push(records[i][this.textValue])
                    }
                    //value赋值
                    if (value.length===1) {
                        this.setValue(value[0])
                    }
                    else {
                        this.setValue(value)
                    }
                    //text赋值
                    this.setText(text.join(';'))
                }
            },
            toggleDialog: function() {
                this.dialogVisible = !this.dialogVisible
            },
            confirm: function(rows) {
                this.records = rows
            },


            onSelect: function(value) {
                this.$emit('select',value[this.filedValue],this.name)
            },
            querySearch(queryString, cb) {
                var list = this.options
                var results = queryString ? list.filter(this.createFilter(queryString)) : list;
                // 调用 callback 返回建议列表的数据
                cb(results);
            },
            createFilter(queryString) {
                return (state) => {
                  return (state.value.indexOf(queryString.toLowerCase()) === 0);
                };
            },
            querySearchAsync(queryString, cb) {
                if (queryString !== '') {
                    if (this.service && this.method) {
                        if (this.remoteQueryKey) {
                            this.remoteArgs[this.remoteQueryKey] = queryString
                        };
                        this.loading = true
                        axios({
                            service: this.service,
                            method: this.method,
                            args: this.remoteArgs
                        })
                        .then((res) => {
                            this.loading = false
                            let response = res.data
                            if (response.status == 200) {
                                let result = Object.assign([],response.result.rows)
                                for(let j=0;j<result.length;j++){
                                    result[j].value = result[j][this.textValue]
                                }
                                cb(result)
                            }

                        })
                        .catch((res) => {
                            // TODO 数据加载失败
                            this.loading = false
                            this.$message.error('数据加载失败')
                        })
                    } else {
                        // TODO 没有传service和method参数处理
                    }
               } else {
                     cb([]);
                }
            }
        }
    }
</script>

<style lang="css">

</style>
