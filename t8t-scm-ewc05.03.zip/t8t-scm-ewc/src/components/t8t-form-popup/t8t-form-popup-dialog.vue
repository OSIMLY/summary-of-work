<template>
    <div class="t8t-form-popup-dialog">
        <div class="t8t-form-popup-bg"></div>

        <el-dialog
            v-model="visible"
            :title="title"
            :modal="modal"
            :show-close="showClose"
            :size="size"
            @close="close"
            >
            <t8t-search
                v-if="searchVisible"
                :fields="searchForm.fields"
                :resetBtnVisible="searchForm.resetBtnVisible"
                :showToggleBtn="searchForm.showToggleBtn"
                :labelWidth="searchForm.labelWidth"
                @submit="submitSearch"
                >
            </t8t-search>
            <t8t-table
                v-if="tableVisible"
                ref="table"
                :columns="table.columns"
                :service="table.service"
                :method="table.method"
                :args="table.args"
                @row-double-click="rowDobuleClick"
            >
            </t8t-table>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="confirm">确 定</el-button>
                <el-button @click="close">取 消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: 't8t-form-popup-dialog',
        data () {
            return {
                visible: true,
                modal: false,
                showClose: true
            }
        },
        props: {
            title: String,
            size: {
                type:String
            },
            searchForm: Object,
            table: Object,
            searchVisible: {
                type: Boolean,
                default: true
            },
            tableVisible: {
                type: Boolean,
                default: true
            },
            onConfirm: Function
        },
        methods: {
            close: function(){
                this.$emit('close')
            },
            confirm: function(){
                let rows = this.$refs['table'].getSelectRows()
                this.$emit('close');
                this.$emit('confirm',rows);
                (typeof this.onConfirm === 'function')&&this.onConfirm(rows)
            },
            //搜索，提交搜索并且发起刷新表格数据的请求
            submitSearch: function(data) {
                this.table.args = {
                    search: data,
                    sort: ['id_desc']
                }
            },
            rowDobuleClick: function(row,event) {
                this.confirm()
            }
        }
    }
</script>
<style lang="css">
.t8t-form-popup-dialog .table-container {
    height: 300px;
}
.t8t-form-popup-dialog .t8t-search .search-group-cli {
    right: 0;
}
.t8t-form-popup-dialog .el-dialog__body {
    padding-bottom: 20px;
}
</style>

<style lang="css">
.t8t-form-popup-dialog .t8t-search {
    padding-top: 0;
    padding-left: 0;
    padding-right: 0;
    margin-top: -30px;
}
.t8t-form-popup-bg {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index: 2000;
}
.t8t-form-popup-dialog .el-dialog__header {
    padding:30px 20px 20px !important;
}
.t8t-form-popup-dialog .el-dialog__body {
    padding: 30px 20px 20px 20px !important;
}
</style>
