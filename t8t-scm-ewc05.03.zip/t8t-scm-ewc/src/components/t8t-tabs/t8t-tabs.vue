<template>
    <div class="t8t-tabs-container">
        <div class="t8t-tabs">
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <el-tab-pane label="基本信息" name="one">基本信息</el-tab-pane>
                <el-tab-pane label="所属分组" name="two">所属分组</el-tab-pane>
                <el-tab-pane label="联系人" name="three">联系人</el-tab-pane>
                <el-tab-pane label="商务信息" name="four">商务信息</el-tab-pane>
                <el-tab-pane label="品牌介绍" name="five">品牌介绍</el-tab-pane>
                <el-tab-pane label="其他信息" name="six">其他信息</el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
    export default {
        name: 't8t-tabs',
        data() {
            return {
                activeName: 'two'
            }
        },
        methods: {
            handleClick(tab, event) {
            }
        }
    }

</script>

<style lang="css" scoped>
    .t8t-tabs .t8t-tabs-line {
        float: left;
    }
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    .t8t-tabs-container {
        margin: 15px 0;
    }
    
    .t8t-tabs .el-tabs__header {
        padding: 0 200px;
        border-top: 1px solid rgb(209, 217, 229);
    }
    
    .t8t-tabs .el-tabs__active-bar {
        left: 200px;
    }
    
    .t8t-tabs .el-tabs__active-bar {
        height: 1px;
    }
    
    .t8t-tabs .el-tabs__item {
        height: 22px;
        line-height: 22px;
        margin-top: 13px;
        margin-bottom: 12px;
    }
    
    .t8t-tabs .el-tabs__item + .el-tabs__item {
        border-left: 1px solid #ddd;
    }
</style>