---
category: components
name: t8t-table
purpose: 显示或批量编辑数据。
---

## 何时使用

- 当有大量结构化的数据需要展现时
- 当需要对数据进行排序、搜索、分页、自定义操作等复杂行为时

## 如何使用

- 直接在页面中引用组件即可

```
import T8tTable from 'src/components/t8t-table/t8t-table.vue'
<t8t-table :dataSource="dataSource" :columns="columns"></t8t-table>
```

- 指定表格的数据源 `dataSource` 为一个数组。
- 指定表格的列格式 `columns` 为一个数组。
- 如果内置配置项无法满足需求，可以使用自定义列模板，通过设置 `slot` 属性为列字段名称即可自动匹配。

```
<t8t-table :dataSource="dataSource" :columns="columns">
    <template
        slot="businessType"
        scope="scope"
    >
        <span
            v-if="scope.row['businessType']===1"
            style="color:red"
        >●</span>
        <span
            v-else-if="scope.row['businessType']===2"
            style="color:green"
        >●</span>
    </template>
</t8t-table>
```

## 温馨提示

- 当页面中包含该多个表格或表格配置项过于复杂时，可以将配置项存储在页面相同目录下的json文件中引用。

```jsx
//tableConfig.json
const dataSource = [{
    "id": 1,
    "businessType": 1,
    "debitObject": 1,
    "debitObjectID": 1,
    "debitObjectName": "二期款",
    "debitType": 1,
    "price": 21157,
    "projectID": 123
},
{
    "id": 2,
    "businessType": 2,
    "debitObject": 2,
    "debitObjectID": 2,
    "debitObjectName": "三期款",
    "debitType": 2,
    "price": 21158,
    "projectID": 123
}];

const columns = [{
    prop: 'businessType',
    label: '业务类型',
    list: 'businessTypes',
    editor: {
        type: 'select',
        rules: [{
            required: true,
            message: "不能为空"
        }]
    }
}, {
    prop: 'debitObject',
    label: '收款对象',
    list: 'debitObjects',
    editor: {
        type: 'select',
        rules: [{
            required: true,
            message: "不能为空"
        }]
    }
}]
```

## API

### Table

| 参数           | 说明                     | 类型             | 默认值   |
|---------------|--------------------------|-----------------|---------|
| dataSource | 表格数据源，请求网关返回的json数组 | Array | [] |
| service | 表格数据绑定的服务名 | String |  |
| method | 服务对应的接口名 | String |  |
| commonData | 辅助资料数据源，用于列表选项或绑定ID的列转为文字 | Object  | null  |
| columns | 表格列配置项，详情见下表 | Object |  |
| selectCol | 是否显示选择列 | Boolean | true |
| radioCol | 是否显示单选列 | Boolean | false |
| indexCol | 是否显示序号列 | Boolean | false |
| isLoading | 数据是否正在加载，请求数据时显示缓冲界面 | Boolean | false |
| pageBar | 是否显示分页栏 | Boolean | true |
| currentPage | 当前页 | Number | 1 |
| total | 总条数，用于生成页数，默认为 `dataSource` 长度 | Number | |
| pageSize | 每页显示条数 | Number | 20 |
| customColumn | 是否允许用户控制列的显示隐藏，若允许需要在 `Column` 中定义 `show` 属性 | Boolean | false |
| indexField | 设置 ID 列名称 | String | 'id' |
| args | 设置数据源查询参数 | Object | |
| editable | 表格是否可编辑 | Boolean | false |
| templateData | 用于新增行的数据模板 | Object | |
| formatters | 用于格式化字段的函数对象 | Object | |
| expandCol | 控制扩展面板显示隐藏的列 | Boolean | false |
| rowKey | 表格行的键集合 | Array | |
| currentRowKey | 预设当前行的键值 | String, Number | |
| expandRowKeys | 预设展开行的键值集合 | Array | |
| selectable | 控制特定行能否选择的回调函数 | Function(row) | |
| highlightCurrentRow | 高亮显示当前行 | Boolean | true |
| reserveSelection | 表格切换页码时是否保留选择的行 | Boolean | false |
| @selection-change | 用于获取表格当前选择集，返回行集合、ID集合和数组序号集合 | Function(selRows, selIDs, selIndexes) | |
| @row-double-click | 用于处理表格行双击事件 | Function(row, event) | |
| @current-row-change | 用于处理表格当前行改变事件 | Function(curRow, oldRow) | |
| @current-page-change | 用于处理分页模块页码改变事件 | Function(pageNum) | |
| @size-change | 用于处理分页模块每页显示行数改变事件 | Function(sizeNum) | |
| @sort-change | 用于处理点击表头进行排序事件，`sortStr` 是请求参数格式的字符串，如 `name_desc` | Function(sortStr, { column, prop, order }) | |


### Column

列描述数据对象，是 columns 中的一项。

| 参数       | 说明                       | 类型            |  默认值  |
|-----------|----------------------------|-----------------|---------|
| prop | 列数据绑定的字段名称 | String | - |
| label | 列头显示的标题文字 | String | '' |
| required | 是否为必填列，如果是则列头显示红色星号 | Boolean | false |
| sortable | 是否支持排序，如果是则点击列头触发 `sort-change` 事件 | Boolean | true |
| width | 设置列宽度，单位为像素 | Number | 150 |
| list | 列绑定的辅助资料，用于ID转为文字或生成 `select` 列表 | Array | - |
| show | 该列是否显示，配合表格 `customColumn` 使用时，必须显式设置此项 | Boolean | true |
| editor | 配置内嵌编辑器 | Object | - |
| editor.type | 内嵌编辑器类型，可设置 `'input'` `'select'` `'button'` `'datetime'` `'date'` `'time'` | String | - |
| editor.rules | 设置编辑器验证规则，如 `[{"required": true, "message": "不能为空"}]` | Array | - |
| editor.filterable | 是否可搜索 | boolean | false |
| editor.allowCreate | 是否允许用户创建新条目，需配合 filterable 使用 | boolean | false |
| editor.filterMethod | 自定义过滤方法 | function | - |

### Table Events

|事件名|说明|参数|
|:---|:---|:---|
| selection-change | 当选择项发生变化时会触发该事件 | |
| row-dobule-click | 当行被双击时会触发该事件 | （row, event） |
| current-row-change | 表格的当前行发生变化时会触发该事件 | （currentRow, oldCurrentRow） |
| row-click | 当前行被点击时会触发该事件 | （row, event, column） |
| sort-change | 排序发生变化时会触发 | {column, prop, order} |
| cell-editor-change | 当内嵌表单值发生变化时触发（支持 `input`、`select`）| cell, val |
| cell-click | 当点击单元格时触发 | cell, val|


