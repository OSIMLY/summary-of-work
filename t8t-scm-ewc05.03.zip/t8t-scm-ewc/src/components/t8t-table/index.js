import T8tTable from './t8t-table'

const install = (Vue) => {
  Vue.component(T8tTable.name, T8tTable)
}

export default {
  install
}
