<template>
    <div class="t8t-table t8t-table-container">
        <div class="table-container">
            <el-form :model="dataSource" ref="form">
                <el-table ref="table" height="height" border stripe fit v-loading="loading" :data="dataSource" :row-class-name="tableRowClassName" :highlight-current-row="highlightCurrentRow" :row-key="rowKey" :current-row-key="dataCurrentRowKey" :expand-row-keys="dataExpandRowKeys" @select="handleSelect" @select-all="handleSelectAll" @cell-click="handleCellClick" @current-change="currentRowChange" @row-dblclick="rowDblclick" @selection-change="selectionChange" @row-click="rowClick" @sort-change="sortChange" @header-contextmenu="headerContextmenu">
                    <el-table-column v-if="selectCol||radioCol" header-align="center" align="center" :type="radioCol?'radio':selectCol?'selection':''" :selectable="selectable" :reserve-selection="reserveSelection" fixed width="38">
                    </el-table-column>
                    <el-table-column v-if="expandCol" type="expand" width="45">
                        <template scope="props">
                            <slot name="expand" :row="props.row" :store="props.store" :$index="props.$index">
                                <t8t-form-panel v-if="typeof expandFields !== 'undefined'" :dataSource="props.row" :fields="expandFields" :commonData="commonData">
                                </t8t-form-panel>
                            </slot>
                        </template>
                    </el-table-column>
                    <el-table-column v-if="indexCol" label="序号" header-align="center" align="center" type="index" width="45">
                    </el-table-column>
                    <el-table-column v-for="item in columns" v-if="typeof item.show==='undefined'?true:item.show" header-align="center" align="center" :prop="item.prop" :label="item.label || ''" :render-header="getColHeaderRender(item)" :sortable="item.sortable==='client'?true:item.sortable==='server'?'custom':false" :min-width="item.minWidth||150" :width="item.width||null" :show-overflow-tooltip="item.tooltip?item.tooltip:false" :summary-type="item.summaryType" :summary-align="item.summaryAlign" :resizable="typeof item.resizable==='undefined'?true:item.resizable">
                        <template scope="cell">
                            <el-form-item v-if="editable && !item.readonly && item.editor && isActiceCell(cell)" :prop="cell.column.property" :row="cell.$index" :rules="item.editor.rules || []" @validated="handleItemValidated(arguments[0],arguments[1],cell)">
                                <t8t-transform-item :type="item.editor.type" :parent="cellEl" :value="cell.row[item.prop]" :placeholder="cell.column.label" :disabled="item.editor.disabled" :readonly="item.editor.readonly" :icon="typeof item.editor.icon==='undefined'?item.editor.icon:null" :filterable="item.editor.filterable" :allow-create="item.editor.allowCreate" :filter-method="typeof item.editor.filterMethod==='undefined'?undefined:item.editor.filterMethod" :common-data="getCommonDataByList(item)" :poper-class="item.editor.poperClass" :show-detail="item.editor.showDetail" :clearable="item.editor.clearable" :end-formater="item.editor.endFormater" :align="item.editor.align" :picker-options="item.editor.pickerOptions" :range-separator="item.editor.rangeSeparator" :options="item.editor.options" :props="item.editor.props" :expand-trigger="item.editor.expandTrigger" :show-all-levels="item.editor.showAllLevels" :change-on-select="item.editor.changeOnSelect" :dialog="item.editor.dialog" :textValue="item.editor.textValue" :filedValue="item.editor.filedValue" :service="item.editor.service" :method="item.editor.method" :dataSource="item.editor.dataSource" :args="typeof item.editor.args==='undefined'?undefined:item.editor.args" :columns="item.editor.columns" :searchExpr="item.editor.searchExpr" :valueExpr="item.editor.valueExpr" :toolbar="typeof item.editor.toolbar==='undefined'?undefined:item.editor.toolbar" :multiple="typeof item.editor.multiple==='undefined'?undefined:item.editor.multiple" :size="item.editor.size" @blur="handleFormItemBlur(cell)" @input-icon-click="handleInputIconClick(cell)" @change="handleFormItemChange(cell, arguments[0])" @mouse-over="handleMouseOver" @button-click="handleButtonClick(cell)">
                                </t8t-transform-item>
                            </el-form-item>
                            <slot v-else-if="!editable || item.readonly || !item.editor || !isActiceCell(cell)" :name="item.prop" :cell="cell" :row="cell.row" :column="cell.column">
                                <div class="cell-text" :class="{readonly:getColHeaderRender(item,true)==='readonly'}" :title="getCellVal(cell.row[item.prop],item.list,item.formatter)">
                                    {{getCellVal(cell.row[item.prop],item.list,item.formatter)}}
                                </div>
                            </slot>
                            <div v-if="isChanged(cell)" class="marker-wrapper">
                                <div class="marker"></div>
                            </div>
                        </template>
                    </el-table-column>
                </el-table>
            </el-form>
        </div>
        <!--分页栏-->
        <div class="pagenav-container" v-if="(!dataSource || dataSource.length === 0)?false:pageBar">
            <el-pagination :current-page="curPage" :total="totalRows" layout="sizes, first, prev, jumper, next, last, refresh, ->, slot" :page-sizes="[5,10,20,30,50]" :page-size="pgSize" @current-change="currentPageChange" @size-change="sizeChange">
                <span class="el-pagination__total">{{getPagebarStatus()}}</span>
            </el-pagination>
        </div>
        <context-menu ref="headerMenu">
            <el-checkbox v-for="item in columns" v-if="typeof item.label!=='undefined'&&item.label!==''" :value="item.show" @input="setColumn(item,arguments[0])">
                {{ item.label }}
            </el-checkbox>
        </context-menu>
    </div>
</template>

<script>
import { isFunction, getBlankData, getTextById, getTextByArray, getCommonData } from './utils/utils.js'
// import { export_json_to_excel, excelToJson } from './vendor/Export2Excel'
import { formatDate } from './utils/dateLib.js'
import ElTable from './src/table.js'
import ElTableColumn from './src/table-column.js'
import ElForm from './src/form.js'
import ElFormItem from './src/form-item.js'
import ElPagination from './src/pagination.js'
import ContextMenu from './src/t8t-context-menu.vue'
import T8tTransformItem from './src/t8t-transform-item.vue'
import T8tFormPanel from 'src/components/t8t-form-panel/t8t-form-panel.vue'
import emitter from './utils/emitter.js'
import Clickoutside from './utils/clickoutside.js'
import './t8t-table.css'
import axios from 'src/utils/axios'
let changedCells = []
let errorFormItems = []
export default {
    name: 't8t-table',
    mixins: [emitter],
    components: {
        ElTable,
        ElTableColumn,
        ElForm,
        ElFormItem,
        ElPagination,
        T8tTransformItem,
        ContextMenu
    },
    data() {
        return {
            blankData: {},
            selectedRows: [],
            selectedIndexes: [],
            deletedIDs: [],
            deletedRows: [],
            addedRows: [],
            editedRows: [],
            activeRow: {},
            activeCol: {},
            validating: false,
            loading: this.isLoading,
            curPage: 1,
            totalRows: 1,
            pgSize: 20,
            cellEl: null,
            dataCurrentRowKey: null,
            dataExpandRowKeys: []
        }
    },
    created() {
        this.blankData = this.templateData
        this.reloadTable()
    },
    mounted() {
        if (process.env.NODE_ENV === "development" && this.debug) {
            if (typeof console !== 'undefined' && console.info) {
                console.info(this)
            }
        }
    },
    directives: {
        Clickoutside
    },
    props: {
        indexField: {
            type: String,
            default: 'id'
        },
        service: String,
        method: String,
        args: Object,
        editable: {
            type: Boolean,
            default: false
        },
        dataSource: {
            type: Array,
            default() {
                return []
            }
        },
        templateData: Object,
        commonData: Object,
        columns: Array,
        formatters: {
            type: Object,
            default() {
                return {}
            }
        },
        selectCol: {
            type: Boolean,
            default: true
        },
        radioCol: {
            type: Boolean,
            default: false
        },
        indexCol: {
            type: Boolean,
            default: false
        },
        expandCol: {
            type: Boolean,
            default: false
        },
        selection: Array,
        selectedIDs: Array,
        currentRow: Object,
        currentID: [Number, String],
        isLoading: {
            type: Boolean,
            default: false
        },
        pageBar: {
            type: Boolean,
            default: true
        },
        currentPage: {
            type: Number,
            default: 1
        },
        total: Number,
        pageSize: {
            type: Number,
            default: 20
        },
        customColumn: {
            type: Boolean,
            default: false
        },
        expandFields: Array,
        rowKey: [Function, String],
        currentRowKey: [Number, String],
        expandRowKeys: Array,
        selectable: Function,
        highlightCurrentRow: {
            type: Boolean,
            default: true
        },
        reserveSelection: {
            type: Boolean,
            default: false
        },
        debug: {
            type: Boolean,
            default: false
        }
    },
    watch: {
        args() {
            this.reloadTable()
        },
        isLoading(val) {
            this.loading = val
        },
        currentPage(val) {
            this.curPage = val
        },
        total(val) {
            this.totalRows = val
        },
        pageSize(val) {
            this.pgSize = val
            this.$refs.table.doLayout()
        },
        dataSource(val) {
            this.$nextTick(function () {
                if (typeof this.rowKeys !== 'undefined') {
                    if (typeof this.expandRowKeys !== 'undefined') {
                        this.dataExpandRowKeys = this.expandRowKeys
                    }
                    if (typeof this.currentRowKey !== 'undefined') {
                        this.dataCurrentRowKey = this.currentRowKey
                    }
                }
            })
        }
    },
    methods: {
        test(a) {
            console.log(a)
        },
        // exportData() {
        //     const tHeader = this.columns.map((i) => { return i.label })
        //     const filterVal = this.columns.map((i) => { return i.prop })
        //     const list = this.dataSource
        //     const data = this.formatJson(filterVal, list)
        //     export_json_to_excel(tHeader, data, 'table-data')
        // },
        // formatJson(filterVal, jsonData) {
        //     return jsonData.map(v => filterVal.map(j => v[j]))
        // },
        // importData(file) {
        //     excelToJson(file)
        // },
        handleItemValidated(status, message, cell) {
            let isInError = this.isInErrorFormItems(cell)
            if (status === 'error') {
                if (!isInError) {
                    errorFormItems.push(cell)
                }
            } else if (status === 'success') {
                if (isInError) {
                    this.delFromErrorFormItems(cell)
                }
            }
            this.$refs.table.doLayout()
        },
        delFromErrorFormItems(cell) {
            errorFormItems.forEach(function (item, index) {
                if (item.row === cell.row && item.column === cell.column) {
                    errorFormItems.splice(index, 1)
                }
            }, this);
        },
        getColHeaderRender(item, returnType = false) {
            if (this.editable) {
                if (item.editor) {
                    if (item.required) {
                        return returnType ? "required" : this.colRequired
                    } else {
                        return returnType ? "normal" : this.colNormal
                    }
                } else {
                    // return returnType?"readonly":this.colReadonly
                    return returnType ? "normal" : this.colNormal
                }
            } else {
                return returnType ? "normal" : this.colNormal
            }
        },
        getCommonDataByList(item) {
            let listName = ''
            if (typeof item.editor.list === 'string') {
                listName = item.editor.list
            } else if (typeof item.list === 'string') {
                listName = item.list
            }
            if (listName === '') {
                return null
            } else if (this.commonData.hasOwnProperty(listName)) {
                return this.commonData[listName]
            } else {
                return null
            }
        },
        getPagebarStatus() {
            let current = this.curPage
            let size = this.pgSize
            let total = this.totalRows
            let startNum = ((current - 1) * size) + 1
            let endNum = current === Math.ceil(total / size) ? total : current * size
            return (
                typeof total === 'number'
                    ? `显示从 ${startNum} 到 ${endNum} 条，总 ${total} 条。每页显示 ${size} 条。`
                    : ''
            )
        },
        isActiceCell(cell) {
            let isInErrorFormItems = this.isInErrorFormItems(cell)
            let isInAddedRow = this.isInAddedRow(cell)
            let isChanged = this.isChanged(cell)
            let isValidating = this.validating
            // let isSelectedRow = this.selectedRows.indexOf(cell.row) !== -1
            let isSelectedRow = false
            let isActiveRow = cell.row === this.activeRow
            let isActiveCol = cell.column === this.activeCol
            if ((isSelectedRow || (isActiveRow && isActiveCol)) || (isValidating && (isChanged || isInAddedRow)) || isInErrorFormItems) {
                return true
            } else {
                return false
            }
        },
        resetActiveCell() {
            this.activeRow = ''
            this.activeCol = ''
        },
        handleSelect(selection, row) {
            this.$emit('select', selection, row)
        },
        handleSelectAll(selection) {
            this.$emit('select-all', selection)
        },
        handleClickoutside(cell) {
            if (this.activeRow === cell.row && this.activeCol === cell.column) {
                resetActiveCell()
            }
        },
        handleCellClick(row, column, cell, event) {
            let isInErrorFormItems = this.isInErrorFormItems({ row, column })
            if (!isInErrorFormItems) {
                event.stopPropagation()
            }
            this.cellEl = cell
            this.activeRow = row
            this.activeCol = column
            this.$emit('cell-click', row, column, cell, event)
        },
        handleFormItemBlur() {
            this.activeRow = null
            this.activeCol = null
        },
        handleFormItemChange(cell, val) {
            let notChanged = changedCells.indexOf(cell) === -1
            let notEdited = this.editedRows.indexOf(cell.row) === -1
            let notAdded = this.addedRows.indexOf(cell.row) === -1
            let notDeled = this.deletedIDs.indexOf(cell.row[this.indexField]) === -1
            // update cell value
            // cell.row[cell.column.property] = val
            let updatedRow = cell.row
            updatedRow[cell.column.property] = val
            this.$set(this.dataSource, cell.$index, updatedRow)
            // this.$refs.table.store.commit('setSummeryRow', this.dataSource)
            // log changed cell for view
            if (notChanged) {
                changedCells.push(cell)
            }
            // log changed cell for data
            if (notAdded && notDeled && notEdited) {
                this.editedRows.push(cell.row)
            }
            // compatible for old call method
            this.$emit('cell-form-item-change', cell, val)
            // recommend call method
            this.$emit('cell-editor-change', cell, val)
        },
        handleMouseOver(event) {
            // event.target.focus()
        },
        handleInputIconClick(cell) {
            this.$emit('input-icon-click', cell)
            this.$emit('cell-input-icon-click', cell)
        },
        handleButtonClick(cell) {
            this.$emit('button-click', cell)
        },
        headerContextmenu(column, e) {
            if (this.customColumn) {
                this.$refs['headerMenu'].openMenu(e)
            }
        },
        setColumn(col, val) {
            let count = this.columns.filter((item) => {
                return item.show === true
            }).length
            if (count !== 1 || val === true) {
                col.show = val
            }
        },
        isInErrorFormItems(cell) {
            let inErrorFormItems = false
            errorFormItems.forEach(function (item, index) {
                if (item.row === cell.row && item.column === cell.column) {
                    inErrorFormItems = true
                }
            }, this);
            return inErrorFormItems
        },
        isInAddedRow(cell) {
            let inAddedRow = false
            this.addedRows.forEach(function (item) {
                if (item === cell.row) {
                    inAddedRow = true
                }
            }, this);
            return inAddedRow
        },
        isChanged(cell) {
            let changed = false
            changedCells.forEach(function (item) {
                if (item.row === cell.row && item.column === cell.column) {
                    changed = true
                }
            }, this);
            return changed
        },
        reloadTable(obj) {
            let self = this
            let args = self.args || {}
            args.page = (obj && obj.page) || self.curPage
            args.size = (obj && obj.pageSize) || self.pgSize
            if (self.service && self.method) {
                this.loading = true
                axios({
                    service: self.service,
                    method: self.method,
                    args: args
                })
                    .then((res) => {
                        this.loading = false
                        let response = res.data
                        if (response.status == 200) {
                            self.dataSource = response.result.rows
                            self.totalRows = response.result.total
                            self.curPage = args.page
                            self.pgSize = args.size
                            if (!this.templateData) {
                                this.blankData = getBlankData(this.dataSource)
                            }
                            this.$emit('data-loaded', self.dataSource)
                        } else {
                            self.dataSource = []
                        }
                    })
                    .catch((res) => {
                        // TODO 数据加载失败
                        this.loading = false
                        console.log("Data load failed.", res)
                        // self.$message.error('表格数据加载失败')
                    })
            } else {
                // TODO 没有传service和method参数处理
            }
        },
        //表格事件处理
        //处理选择行变化
        selectionChange(selRows) {
            let selIDs = [] //数据库ID字段选择集
            let selIndexes = [] //行序号选择集
            selRows.forEach((item, index) => {
                selIDs.push(item[this.indexField])
                selIndexes.push(index)
            })
            this.selectedRows = selRows
            this.selectedIndexes = selIndexes
            //传入数据行、ID字段、行序号三个参数，模板页面可根据需要选用
            this.$emit('selection-change', selRows, selIDs, selIndexes)
        },
        //处理行双击事件
        rowDblclick(row, event) {
            if (!this.editable) {
                this.clearSelection()
                this.$refs.table.toggleRowSelection(row)
            }
            this.$emit('row-double-click', row, event)
        },
        //处理行单击事件
        rowClick(row, event, column) {
            if (!this.editable && !this.radioCol) {
                this.$refs.table.toggleRowSelection(row)
            }
            this.$emit('row-click', row, event, column)
        },
        toggleRowSelection(row, selected) {
            this.$refs.table.toggleRowSelection(row, selected)
        },

        //处理当前行改变
        currentRowChange(curRow, oldRow) {
            // this.currentRow = curRow
            this.$emit('current-row-change', curRow, oldRow)
        },
        //切换选中行样式
        tableRowClassName(row, index) {
            const exsist = this.selectedRows.indexOf(row)
            if (exsist !== -1) {
                return 'selected-row'
            }
        },
        //处理表头排序
        sortChange({
                column,
            prop,
            order
            }) {
            let sortStr
            switch (order) {
                case 'ascending':
                    sortStr = [prop + '_asc']
                    break
                case 'descending':
                    sortStr = [prop + '_desc']
                    break
                default:
                    sortStr = null
            }
            this.$emit('sort-change', sortStr, { column, prop, order })
        },
        colRequired(h, {
                column,
            $index
            }) {
            return h('span', {}, [h('span', {
                attrs: {
                    class: 'required-tag'
                }
            }, '* '), h('span', column.label)])
        },
        colNormal(h, {
                column,
            $index
        }) {
            return h('span', {}, column.label)
        },
        colReadonly(h, {
                column,
            $index
        }) {
            return h('span', {}, [h('sapn', {
                attrs: {
                    class: 'not-editable',
                    title: '不可编辑'
                }
            }), h('span', column.label)])
        },
        //分页部分
        //处理页码变化
        currentPageChange(val) {
            this.reloadTable({ page: val })
            this.$emit('current-page-change', val)
        },
        //处理每页行数变化
        sizeChange(val) {
            this.reloadTable({ page: 1, pageSize: val })
            this.$emit('size-change', val)
        },
        getCellVal(val, listName, formatter) {
            let list
            let isArray
            let haveListName = typeof listName !== 'undefined'
            let haveFormatter = typeof formatter !== 'undefined'
            if (!haveListName && !haveFormatter) {
                return val
            } else if (haveListName) {
                isArray = val instanceof Array
                return !isArray ? this.getText(listName, val) : this.getCascadeText(listName, val)
            } else if (haveFormatter) {
                if (isFunction(formatter)) {
                    return formatter(val)
                } else if (typeof formatter === 'string') {
                    if (this.formatters.hasOwnProperty(formatter)) {
                        return this.formatters[formatter](val)
                    } else if (this.$parent.hasOwnProperty(formatter)) {
                        return this.$parent[formatter](val)
                    } else if (this.hasOwnProperty(formatter)) {
                        return this[formatter](val)
                    }
                }
            } else {
                return ''
            }
        },
        isTimestamp(date) {
            if (typeof date === 'string') {
                return date.match(/^\d{10}$/)
            } else if (typeof date === 'number') {
                return (date + "").match(/^\d{10}$/)
            }

            return false
        },
        dateParser(text) {
            let dateString
            let objDate = new Date(text * 1000)
            if (text === 0 || text === null) {
                dateString = ""
            } else {
                let _newObj = this.isTimestamp(text) ? objDate : new Date(text)
                dateString = formatDate(_newObj, 'yyyy-MM-dd HH:mm:ss')
            }
            return dateString
        },
        getText(listName, value) {
            let list = this.commonData[listName]
            return getTextById(list, value)
        },
        getCascadeText(listName, value) {
            let list = this.commonData[listName]
            return getTextByArray(list, value)
        },
        /*******************************get操作集合************************************** */
        getCurrentRow() {
            return this.currentRow
        },
        getSelectRows() {
            return this.selectedRows
        },
        getSelectRow(row) {
            // 如果要获取单个，默认获取多选中最后选择的一个
            let selLen = this.selectedRows.length
            return (selLen > 0) ? this.selectedRows[selLen - 1] : null
        },
        getRowByIndex(index) {
            return this.dataSource[index] || null
        },
        getSelectRowsWidthFormat(column, value) {
            let newObj = []
            this.selectedRows.forEach((item, index) => {
                item[column] = value
                newObj[index] = item
            })

            return newObj
        },
        /******************************************************************************* */
        //清空选择集
        clearSelection() {
            this.$refs.table.clearSelection()
        },
        //获取表格数据操作记录
        getActionLog(clear = true, increment = false) {
            let actionLog
            let isAdded, isDeled
            let self = this
            let remainRows = []
            this.dataSource.forEach((item) => {
                isAdded = self.addedRows.indexOf(item) === -1
                isDeled = self.deletedIDs.indexOf(item[this.indexField]) === -1
                if (isAdded && isDeled) {
                    remainRows.push(item)
                }
            })
            actionLog = {
                "addedRows": this.addedRows,
                "editedRows": increment ? this.editedRows : remainRows,
                "deletedIDs": this.deletedIDs
            }
            actionLog = Object.assign({}, actionLog)
            if (clear) {
                this.resetActionLog()
            }
            return actionLog
        },
        //重置表格数据操作记录
        resetActionLog() {
            this.addedRows = []
            this.editedRows = []
            this.deletedIDs = []
        },
        //添加新行
        addNewRow(position = 'front') {
            errorFormItems = []
            let newRow = Object.assign({}, this.blankData)
            if (position === 'front') {
                this.dataSource.unshift(newRow)
            } else if (position === 'back') {
                this.dataSource.push(newRow)
            }
            this.addedRows.push(newRow)
            this.$emit('rows-added', this.addedRows, newRow)
        },
        cloneRows() {
            let cloneRow
            this.selectedRows.forEach((row) => {
                cloneRow = Object.assign({}, row)
                this.dataSource.unshift(cloneRow)
                this.addedRows.push(cloneRow)
            })
            this.$emit('rows-added', this.addedRows, newRow)
        },
        //删除行
        delRows(rows = this.selectedRows) {
            let self = this
            errorFormItems = []
            rows.forEach((deletedItem) => {
                let dataSourceIndex = self.dataSource.indexOf(deletedItem)
                if (dataSourceIndex !== -1) {
                    let addedRowsIndex = self.addedRows.indexOf(deletedItem)
                    if (addedRowsIndex !== -1) {
                        self.addedRows.splice(addedRowsIndex, 1)
                    } else {
                        self.deletedIDs.push(deletedItem[this.indexField])
                        self.deletedRows.push(deletedItem)
                    }
                    self.dataSource.splice(dataSourceIndex, 1)
                }
            })
            this.$emit('rows-deleted', this.deletedIDs, this.deletedRows)
        },
        //验证表格内嵌表单
        validate(callback) {
            if (errorFormItems.length === 0) {
                this.validating = true
            }
            this.$nextTick(function () {
                if (this.$refs['form'].fields.length === 0) {
                    callback(true)
                } else {
                    this.$refs['form'].validate((valid) => {
                        if (valid) {
                            callback(valid)
                        } else {
                            callback(valid)
                        }
                    })
                }
                this.validating = false
                this.$refs.table.doLayout()
            })

            // if (errorFormItems.length === 0) {
            //     this.validating = true
            // }

            // this.$nextTick(function () {
            //     let valid = true
            //     let count = 0
            //     let errorPosition = ''
            //     let inErroritems
            //     let fieldsCount = this.$refs['form'].fields.length

            //     if (fieldsCount === 0) {
            //         callback(valid)
            //     } else {
            //         this.$refs['form'].fields.forEach((field, index) => {
            //             field.validate('', errors => {
            //                 errorPosition = field.row + "," + field.prop
            //                 inErroritems = errorFormItems.indexOf(errorPosition)
            //                 if (errors) {
            //                     valid = false
            //                     if (inErroritems == -1) {
            //                         errorFormItems.push(errorPosition)
            //                     }
            //                 }
            //                 else {
            //                     if (inErroritems !== -1)
            //                         errorFormItems.splice(inErroritems, 1)
            //                 }
            //                 if (typeof callback === 'function' && ++count === fieldsCount) {
            //                     if (valid) {
            //                         errorFormItems = []
            //                     }
            //                     callback(valid)
            //                 }
            //             })
            //         })
            //     }
            //     this.validating = false
            //     this.$refs.table.doLayout()
            // })

        },
        //重置表格内嵌表单
        reset() {
            this.$refs['form'].resetFields()
        },
        //控制正在加载界面显示、隐藏
        showLoading(locker) {
            this.loading = true
        },
        hideLoading(locker) {
            this.loading = false
        }
    }
}

</script>