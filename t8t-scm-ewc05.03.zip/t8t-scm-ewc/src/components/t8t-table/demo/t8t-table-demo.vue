<template>
    <div class="page-pay-purpose">
        <t8t-breadcrumb :data="breadcrumbData"></t8t-breadcrumb>
        <div class="toolbar-container">
            <el-button
                size="toolbar"
                @click="handleClick('create')"
            >添加</el-button>
            <el-button
                size="toolbar"
                @click="handleClick('delete')"
            >删除</el-button>
            <el-button
                size="toolbar"
                @click="handleClick('submit')"
            >提交</el-button>
        </div>
        <div class="g-main-container">
            <t8t-table
                ref="table"
                :dataSource="tableData"
                :columns="columns"
                :selectCol="false"
                :indexCol="true"
                :isLoading="isLoading"
                :commonData="commonData"
                :pageBar="false"
                :currentPage="currentPage"
                :total="totalRows"
                :pageSize="pageSize"
                @selection-change="handleSelectionChange"
                @row-double-click="handleRowDblclick"
                @current-row-change="handleCurrentRowChange"
                @current-page-change="handleCurrentPageChange"
                @size-change="handleSizeChange"
                @sort-change="handleSortChange"
            >
                <template
                    slot="businessType"
                    scope="scope"
                >
                    <span
                        v-if="scope.row['businessType']===1"
                        style="color:red"
                    >●</span>
                    <span
                        v-else-if="scope.row['businessType']===2"
                        style="color:green"
                    >●</span>
                </template>
            </t8t-table>
        </div>
    </div>
</template>

<script>
    import { getCommonData } from 'src/components/t8t-table/utils/utils.js'
    import T8tBreadcrumb from 'src/components/t8t-breadcrumb/t8t-breadcrumb.vue'
    import T8tToolbar from 'src/components/t8t-toolbar/t8t-toolbar.vue'
    import T8tTable from 'src/components/t8t-table/t8t-table.vue'
    import * as types from 'src/store/mutation-types.js'
    import api from 'src/utils/api'
    import demoData from './data.json'
    export default {
        name: 'page-pay-purpose',
        components: {
            T8tBreadcrumb,
            T8tToolbar,
            T8tTable
        },
        data() {
            return {
                //面包屑
                breadcrumbData: [
                    { title: '财务' },
                    { title: '财务基础配置' },
                    { title: '款项用途配置' }],
                //表格
                tableData: [],
                columns: [{
                    prop: 'businessType',
                    label: '业务类型',
                    list: 'businessTypes'
                }, {
                    prop: 'debitObject',
                    label: '收款对象',
                    list: 'debitObjects',
                    editor: {
                        type: 'select',
                        rules: [{
                            required: true,
                            message: "不能为空"
                        }]
                    }
                }, {
                    prop: 'debitObjectID',
                    label: '收款对象ID',
                    editor: {
                        type: 'input',
                        rules: [{
                            required: true,
                            message: "不能为空"
                        }]
                    }
                }, {
                    prop: 'debitObjectName',
                    label: '收款对象名称',
                    editor: {
                        type: 'input'
                    }
                }, {
                    prop: 'debitType',
                    label: '收款类型',
                    list: 'debitTypes',
                    editor: {
                        type: 'select'
                    }
                }, {
                    prop: 'price',
                    label: '收款金额',
                    editor: {
                        type: 'input'
                    }
                }, {
                    prop: 'projectID',
                    label: '项目ID',
                    editor: {
                        type: 'input'
                    }
                }],
                selection: [],
                selectedIDs: [],
                currentRow: {},
                currentID: null,
                isLoading: false,
                currentPage: 1,
                pageSize: 20,
                totalRows: 20,
                //表单配置
                formData: {},
                formAction: 'create',
                //请求参数配置
                requestCfg: {
                    create: {
                        service: "fundPurpose",
                        method: "queryPage"
                    },
                    retrieve: {
                        service: "fundPurpose",
                        method: "queryPage"
                    },
                    update: {
                        service: "fundPurpose",
                        method: "queryPage"
                    },
                    delete: {
                        service: "fundPurpose",
                        method: "queryPage"
                    }
                },
                //辅助资料配置
                commonData: {
                    businessTypes: [], // 业务类型
                    debitObjects: [], // 收款对象
                    debitTypes: [] // 收款类型
                }
            }
        },
        created() {
            this.tableData = demoData.demoData
            this.commonData = demoData.demoComData
            // getCommonData(this.commonData)
            // this.getTableData()

            // this.getCommonData('003001', 'businessTypes')
            // this.getCommonData('003006', 'debitObjects')
            // this.getCommonData('003002', 'debitTypes')
        },
        methods: {
            //表格
            //处理选择行变化
            handleSelectionChange(selRows, selIDs) {
                this.selection = selRows
                this.selectedIDs = selIDs
            },
            //处理行双击事件
            handleRowDblclick(row, event) {
                this.formAction = 'update'
                this.formData = Object.assign({}, this.currentRow)
                this.$refs['dlgMain'].dialogShow()
            },
            //处理当前行改变
            handleCurrentRowChange(curRow, oldRow) {
                let index = this.tableData.indexOf(curRow)
                this.currentRow = curRow
                this.currentIndex = index
            },
            //处理页码变化
            handleCurrentPageChange(val) {
                this.currentPage = val
            },
            //处理每页行数变化
            handleSizeChange(val) {
                this.pageSize = val
            },
            //处理表头排序
            handleSortChange(sortStr) {
                console.log(sortStr)
            },

            //工具栏
            //点击添加按钮
            handleBtnAddClick() {
                let blankData = getBlankData(this.dataSource)
                this.formAction = 'create'
                this.formData = Object.assign({}, blankData)
                this.$refs['dlgMain'].dialogShow()
            },
            //点击编辑按钮
            handleBtnEditClick() {
                this.formAction = 'update'
                if (this.selection.length === 0) {
                    this.$message.error('请选择要处理的行。')
                } else if (this.selection.length > 1) {
                    this.$message.error('请选择一行进行处理。')
                } else {
                    this.formData = Object.assign({}, this.selection[0])
                    this.$refs['dlgMain'].dialogShow()
                    // this.dialogVisible = true
                }
                // this.$emit('btn-edit-click')
            },
            //点击作废按钮
            handleBtnVoidClick() {
                let args
                let self = this
                let actGroup = []
                if (this.selection.length === 0) {
                    this.$message.error('请选择要处理的行。')
                } else {
                    this.$confirm(
                        '确认对所选数据进行作废处理？',
                        '作废确认',
                        { type: 'warning' })
                        .then(() => {
                            self.selectedIDs.forEach((item) => {
                                actGroup.push({
                                    "id": item,
                                    "status": 1,
                                    "updateUser": 123
                                })
                            })
                            args = { "fundPurposes": actGroup }
                            api.fundPurpose.batchStatusUpdate(args)
                                .then((res) => {
                                    if (res.data.status === 200) {
                                        self.$message({
                                            type: 'success',
                                            message: '已作废'
                                        })
                                    } else {
                                        self.$message({
                                            type: 'error',
                                            message: '作废失败'
                                        })
                                    }
                                })
                        })
                }
                this.$emit('btn-void-click')
            },
            getTableData() {
                let args = {
                    "page": 1,
                    "size": 10
                }
                this.isLoading = true
                api[this.requestCfg.service][this.requestCfg.method](args)
                    .then((res) => {
                        if (res.data.status === 200) {
                            this.tableData = res.data.result.rows
                            this.totalRows = res.data.result.total
                            this.isLoading = false
                        }
                    })
            },
            $getCommonData(pid, name) {
                let args = { "fatherCode": pid }
                let list = []
                api.allSystemCode.list(args)
                    .then((res) => {
                        if (res.data.status === 200) {
                            res.data.result.rows.forEach((item) => {
                                list.push({
                                    value: item.id,
                                    text: item.name
                                })
                            })
                            this.commonData[name] = list
                        }
                    })
            },
            handleClick(action) {
                switch (action) {
                    case 'create':
                        this.$refs['table'].addNewRow()
                        break
                    case 'update':
                        this.$refs['table'].delRows()
                        break
                }
            }
        }
    }

</script>

<style
    lang="css"
    scoped
>
    .g-main-container {
        display: flex;
        flex: 1;
        flex-direction: column;
        overflow: auto;
    }

    .toolbar-container {
        margin: 13px;
    }

    .el-button--toolbar:first-child {
        margin-left: 8px;
    }

    .el-button--toolbar {
        padding: 5px 11px;
        font-size: 12px;
        border-radius: 2px;
        border-color: rgb(232, 237, 241);
        color: rgb(50, 139, 239);
    }
</style>


<style>

</style>
