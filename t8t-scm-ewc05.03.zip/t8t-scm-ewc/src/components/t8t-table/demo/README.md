## 使用方法
- 访问此URL：http://localhost:8080/#/debug/table-test
- 需要在路由表中增加以下内容：
```
// DEBUG
import tableTest from '../components/t8t-table/demo/t8t-table-demo.vue'
// DEBUG
{
    path: '/debug',
    meta: { auth: debug },
    component: Console,
    children: [
        { path: 'table-test', meta: { auth: debug }, component: tableTest }
    ]
}
```