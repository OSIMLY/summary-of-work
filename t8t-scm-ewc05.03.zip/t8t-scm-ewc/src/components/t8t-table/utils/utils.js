import apiCommon from 'src/services/commonApi/commonApi.js'
import axios from 'src/utils/axios'
/**
 * 检测变量是否为函数
 * @param {*} functionToCheck - variable to check
 * @returns {Boolean} answer to: is a function?
 */
export const isFunction = function (functionToCheck) {
    var getType = {}
    return functionToCheck && getType.toString.call(functionToCheck) === '[object Function]'
}
/**
 * 通过 DOM 节点获取 TD 单元格
 * @param {Object} event
 * @returns cell
 */
export const getCellByEl = function (el) {
    let cell = el
    while (cell && cell.tagName.toUpperCase() !== 'HTML') {
        if (cell.tagName.toUpperCase() === 'TD') {
            return cell
        }
        cell = cell.parentNode
    }
    return null
}
/**
 * 根据数据源生成一条空数据行
 * @param {any} dataSource
 * @returns blankRow
 */
export const getBlankData = function (dataSource) {
    if (dataSource.length > 0) {
        let blankRow = Object.assign({}, dataSource[0])
        for (let prop in blankRow) {
            if (blankRow.hasOwnProperty(prop)) {
                blankRow[prop] = null
            }
        }
        return blankRow
    } else {
        return {}
    }
}
/**
 * 根据ID获取文本
 * @param {Array} list
 * @param {Array} value
 * @returns text
 */
export const getTextById = function (list, value, prop) {
    let item = list.filter((item) => item.value === value)
    if (item[0]) {
        if (item[0].hasOwnProperty(prop)) {
            return item[0][prop]
        } else if (item[0].hasOwnProperty('text')) {
            return item[0]['text']
        } else if (item[0].hasOwnProperty('label')) {
            return item[0]['label']
        }
    } else {
        return ''
    }
}
/**
 * 根据Array获取文本
 * @param {Array} list
 * @param {Array} varArray
 * @returns text
 */
export const getTextByArray = function (list, varArray, prop) {
    let labels = []
    let text = ''
    varArray.forEach(value => {
        const targetOption = list && list.filter(option => option['value'] === value)[0]
        if (targetOption) {
            labels.push(targetOption['label'])
            list = targetOption['children']
        }
    })
    labels.forEach((value, index) => {
        text += (index === 0 ? '' : ' / ') + value
    })
    return text
}
/**
 * 辅助资料配置模板
 * @param {any} fatherCode
 * @param {any} keyName 键对应的字段名，默认为'id'
 * @param {any} valueName 值对应的字段名，默认为'name'
 */
const commonDataInfo = {
    // 业务类型
    businessTypes: {
        fatherCode: '003001',
        keyName: 'id',
        valueName: 'name'
    },
    // 收款对象
    debitObjects: {
        fatherCode: '003006'
    },
    // 收款类型
    debitTypes: {
        fatherCode: '003002'
    }
}
/**
 * 获取辅助资料
 * @param {any} commonData
 * @returns commonData
 */
export const getCommonData = function (commonData) {
    for (let listName in commonData) {
        if (commonDataInfo.hasOwnProperty(listName)) {
            if (commonData.hasOwnProperty(listName)) {
                let infos = commonDataInfo[listName]
                let args = {
                    'fatherCode': infos.fatherCode
                }
                let list = []
                apiCommon.allSystemCodeList(args)
                    .then((res) => {
                        if (res.data.status === 200) {
                            res.data.result.rows.forEach((item) => {
                                list.push({
                                    value: item[infos.keyName || 'id'],
                                    text: item[infos.valueName || 'name']
                                })
                            })
                            commonData[listName] = list
                        }
                    })
            }
        } else {
            console.log('Wrong list name.')
            return []
        }
    }
}
/**
 * 获取全局唯一标识符
 * 用于新增数据行的临时ID
 * @returns uuid
 */
export const uuid = function () {
    var s = []
    var hexDigits = '0123456789abcdef'
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1)
    }
    s[14] = '4'
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1)
    s[8] = s[13] = s[18] = s[23] = '-'

    var uuid = s.join('')
    return uuid
}
/**
 * 定义操作类型
 */
export const M = {
    create: '提交',
    update: '编辑',
    delete: '删除',
    void: '作废',
    valid: '反作废'
}
/**
 * 根据消息和类型生成一个 msgBox 配置项
 * @param {String} message 
 * @param {String} type 
 */
export const mb = function (message, type) {
    let mbCfg = {
        title: '消息',
        type: type || 'success',
        message: message,
        showCancelButton: false,
        confirmButtonText: '知道了',
        confirmButtonClass: 'is-plain'
    }
    return mbCfg
}

// export const dataSource = function (config) {
//     this.store
//     let self = this
//     let args = self.args || {}
//     args.page = (obj && obj.page) || self.curPage
//     args.size = (obj && obj.pageSize) || self.pgSize
//     if (self.service && self.method) {
//         this.loading = true
//         axios({
//                 service: self.service,
//                 method: self.method,
//                 args: args
//             })
//             .then((res) => {
//                 this.loading = false
//                 let response = res.data
//                 if (response.status == 200) {
//                     self.dataSource = response.result.rows
//                     self.totalRows = response.result.total
//                     self.curPage = args.page
//                     self.pgSize = args.size
//                     if (!this.templateData) {
//                         this.blankData = getBlankData(this.dataSource)
//                     }
//                     this.$emit('data-loaded', self.dataSource)
//                 } else {
//                     self.dataSource = []
//                 }
//             })
//             .catch((res) => {
//                 // TODO 数据加载失败
//                 this.loading = false
//                 console.log("Data load failed.", res)
//                 // self.$message.error('表格数据加载失败')
//             })
//     } else {
//         // TODO 没有传service和method参数处理
//     }
// }
