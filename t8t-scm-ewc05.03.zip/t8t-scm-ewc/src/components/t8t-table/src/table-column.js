module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/dist/";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(26);


/***/ },

/***/ 5:
/***/ function(module, exports) {

	module.exports = require("element-ui/lib/checkbox");

/***/ },

/***/ 12:
/***/ function(module, exports) {

	'use strict';

	exports.__esModule = true;

	var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

	/**
	 * 获取 <td> 单元格的 DOM 对象
	 * @param {Object} event 事件对象
	 */
	var getCell = exports.getCell = function getCell(event) {
	  var cell = event.target;

	  while (cell && cell.tagName.toUpperCase() !== 'HTML') {
	    if (cell.tagName.toUpperCase() === 'TD') {
	      return cell;
	    }
	    cell = cell.parentNode;
	  }

	  return null;
	};
	/**
	 * 根据属性名称获取对象的键值，支持级联
	 * @param {Object} object 数据对象
	 * @param {String} prop 属性名称
	 */
	var getValueByPath = exports.getValueByPath = function getValueByPath(object, prop) {
	  prop = prop || '';
	  var paths = prop.split('.');
	  var current = object;
	  var result = null;
	  for (var i = 0, j = paths.length; i < j; i++) {
	    var path = paths[i];
	    if (!current) break;

	    if (i === j - 1) {
	      result = current[path];
	      break;
	    }
	    current = current[path];
	  }
	  return result;
	};
	/**
	 * 判断变量是否为对象
	 * @param {*} obj
	 */
	var isObject = function isObject(obj) {
	  return obj !== null && (typeof obj === 'undefined' ? 'undefined' : _typeof(obj)) === 'object';
	};
	/**
	 * 数组排序函数，返回排序后的新数组实例
	 * @param {Array} array 需要排序的数组
	 * @param {String} sortKey 排序属性名
	 * @param {String} reverse 排序方式
	 * @param {Function} sortMethod 排序函数
	 */
	var orderBy = exports.orderBy = function orderBy(array, sortKey, reverse, sortMethod) {
	  if (typeof reverse === 'string') {
	    reverse = reverse === 'descending' ? -1 : 1;
	  }
	  if (!sortKey) {
	    return array;
	  }
	  var order = reverse && reverse < 0 ? -1 : 1;

	  // sort on a copy to avoid mutating original array
	  return array.slice().sort(sortMethod ? function (a, b) {
	    return sortMethod(a, b) ? order : -order;
	  } : function (a, b) {
	    if (sortKey !== '$key') {
	      if (isObject(a) && '$value' in a) a = a.$value;
	      if (isObject(b) && '$value' in b) b = b.$value;
	    }
	    a = isObject(a) ? getValueByPath(a, sortKey) : a;
	    b = isObject(b) ? getValueByPath(b, sortKey) : b;
	    return a === b ? 0 : a > b ? order : -order;
	  });
	};
	/**
	 * 根据列序号获取列对象
	 * @param {Object} table 表格对象
	 * @param {String} columnId 列序号
	 */
	var getColumnById = exports.getColumnById = function getColumnById(table, columnId) {
	  var column = null;
	  table.columns.forEach(function (item) {
	    if (item.id === columnId) {
	      column = item;
	    }
	  });
	  return column;
	};
	/**
	 * 获取根据单元格 DOM 对象所在的列对象
	 * @param {Object} table 表格对象
	 * @param {Object} cell 单元格 DOM 对象
	 */
	var getColumnByCell = exports.getColumnByCell = function getColumnByCell(table, cell) {
	  var matches = (cell.className || '').match(/el-table_[^\s]+/gm);
	  if (matches) {
	    return getColumnById(table, matches[0]);
	  }
	  return null;
	};
	/**
	 * 判断浏览器是否为 Firefox
	 */
	var isFirefox = typeof navigator !== 'undefined' && navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
	/**
	 * 为 DOM 元素添加鼠标滚动事件
	 * @param {Object} element DOM 元素
	 * @param {Function} callback 事件回调函数
	 */
	var mousewheel = exports.mousewheel = function mousewheel(element, callback) {
	  if (element && element.addEventListener) {
	    element.addEventListener(isFirefox ? 'DOMMouseScroll' : 'mousewheel', callback);
	  }
	};
	/**
	 * 获取行的键值，键名由表格 'row-key' 属性定义
	 * @param {*} row 行对象
	 * @param {*} rowKey 键名
	 */
	var getRowIdentity = exports.getRowIdentity = function getRowIdentity(row, rowKey) {
	  if (!row) throw new Error('row is required when get row identity');
	  if (typeof rowKey === 'string') {
	    return row[rowKey];
	  } else if (typeof rowKey === 'function') {
	    return rowKey.call(null, row);
	  }
	};

	var getSummaryVal = exports.getSummaryVal = function getSummaryVal(data, prop, type) {
	  var sum = 0;
	  var count = 0;
	  var max = 0;
	  var min = 0;
	  var label = {
	    'sum': '求和',
	    'max': '最大值',
	    'min': '最小值',
	    'average': '平均值',
	    'count': '计数'
	  };
	  if (typeof type === 'string') {
	    switch (type) {
	      case 'sum':
	        data.forEach(function (row) {
	          sum += Number(row[prop]);
	        });
	        return label[type] + ': ' + sum;

	      case 'count':
	        data.forEach(function (row) {
	          count += 1;
	        });
	        return label[type] + ': ' + count;

	      case 'max':
	        data.forEach(function (row) {
	          Number(row[prop]) > max ? max = row[prop] : null;
	        });
	        return label[type] + ': ' + max;

	      case 'min':
	        data.forEach(function (row) {
	          Number(row[prop]) < min ? min = row[prop] : null;
	        });
	        return label[type] + ': ' + min;

	      case 'average':
	        data.forEach(function (row) {
	          sum += Number(row[prop]);
	          count += 1;
	        });
	        return Math.round(sum / count, 2);

	      default:
	        return null;
	    }
	  } else if (typeof type === 'function') {
	    return type.call(null, data, prop);
	  }
	};

/***/ },

/***/ 17:
/***/ function(module, exports) {

	module.exports = require("element-ui/lib/tag");

/***/ },

/***/ 26:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _tableColumn = __webpack_require__(27);

	var _tableColumn2 = _interopRequireDefault(_tableColumn);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* istanbul ignore next */
	_tableColumn2.default.install = function (Vue) {
	  Vue.component(_tableColumn2.default.name, _tableColumn2.default);
	};

	exports.default = _tableColumn2.default;

/***/ },

/***/ 27:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	exports.__esModule = true;

	var _checkbox = __webpack_require__(5);

	var _checkbox2 = _interopRequireDefault(_checkbox);

	var _tag = __webpack_require__(17);

	var _tag2 = _interopRequireDefault(_tag);

	var _merge = __webpack_require__(28);

	var _merge2 = _interopRequireDefault(_merge);

	var _util = __webpack_require__(12);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

	var columnIdSeed = 1;

	var defaults = {
	  // 默认列的初始属性
	  default: {
	    order: ''
	  },
	  // 选择列的初始属性
	  selection: {
	    width: 48,
	    minWidth: 48,
	    realWidth: 48,
	    order: '',
	    className: 'el-table-column--selection'
	  },
	  // 展开列的初始属性
	  expand: {
	    width: 48,
	    minWidth: 48,
	    realWidth: 48,
	    order: ''
	  },
	  // 序号列的初始属性
	  index: {
	    width: 48,
	    minWidth: 48,
	    realWidth: 48,
	    order: ''
	  },
	  radio: {
	    width: 48,
	    minWidth: 48,
	    realWidth: 48,
	    order: '',
	    className: 'el-table-column--selection'
	  }
	};

	var forced = {
	  // 定义选择列的列头及单元格渲染方式等
	  selection: {
	    renderHeader: function renderHeader(h) {
	      return h(
	        'el-checkbox',
	        {
	          nativeOn: {
	            'click': this.toggleAllSelection
	          },
	          domProps: {
	            'value': this.isAllSelected
	          },
	          attrs: {
	            indeterminate: this.isIndeterminate }
	        },
	        []
	      );
	    },
	    renderCell: function renderCell(h, _ref) {
	      var row = _ref.row,
	          column = _ref.column,
	          store = _ref.store,
	          $index = _ref.$index;

	      return h(
	        'el-checkbox',
	        {
	          domProps: {
	            'value': store.isSelected(row)
	          },
	          attrs: {
	            disabled: column.selectable ? !column.selectable.call(null, row, $index) : false
	          },
	          on: {
	            'input': function input() {
	              store.commit('rowSelectedChanged', row);
	            }
	          }
	        },
	        []
	      );
	    },
	    sortable: false,
	    resizable: false
	  },
	  // 定义序号列的列头及单元格渲染方式等
	  index: {
	    renderHeader: function renderHeader(h, _ref2) {
	      var column = _ref2.column;

	      return column.label || '#';
	    },
	    renderCell: function renderCell(h, _ref3) {
	      var $index = _ref3.$index;

	      return h(
	        'div',
	        null,
	        [$index + 1]
	      );
	    },
	    sortable: false
	  },
	  // 定义展开列的列头及单元格渲染方式等
	  expand: {
	    renderHeader: function renderHeader(h, _ref4) {
	      _objectDestructuringEmpty(_ref4);

	      return '';
	    },
	    renderCell: function renderCell(h, _ref5, proxy) {
	      var row = _ref5.row,
	          store = _ref5.store;

	      var expanded = store.states.expandRows.indexOf(row) > -1;
	      return h(
	        'div',
	        { 'class': 'el-table__expand-icon ' + (expanded ? 'el-table__expand-icon--expanded' : ''),
	          on: {
	            'click': function click() {
	              return proxy.handleExpandClick(row);
	            }
	          }
	        },
	        [h(
	          'i',
	          { 'class': 'el-icon el-icon-arrow-right' },
	          []
	        )]
	      );
	    },
	    sortable: false,
	    resizable: false,
	    className: 'el-table__expand-column'
	  },
	  radio: {
	    renderHeader: function renderHeader(h) {
	      return '';
	    },
	    renderCell: function renderCell(h, _ref6) {
	      var row = _ref6.row,
	          column = _ref6.column,
	          store = _ref6.store,
	          $index = _ref6.$index;

	      return h(
	        'el-radio',
	        {
	          domProps: {
	            'value': store.states.currentRow === row
	          },
	          attrs: {
	            label: true,
	            disabled: column.selectable ? !column.selectable.call(null, row, $index) : false
	          },
	          on: {
	            'input': function input() {
	              store.commit('setCurrentRow', row);
	            }
	          }
	        },
	        []
	      );
	    },
	    sortable: false,
	    resizable: false
	  }
	};
	// 生成一个默认初始值的列对象
	var getDefaultColumn = function getDefaultColumn(type, options) {
	  var column = {};

	  (0, _merge2.default)(column, defaults[type || 'default']);

	  for (var name in options) {
	    if (options.hasOwnProperty(name)) {
	      var value = options[name];
	      if (typeof value !== 'undefined') {
	        column[name] = value;
	      }
	    }
	  }

	  if (!column.minWidth) {
	    column.minWidth = 80;
	  }

	  column.realWidth = column.width || column.minWidth;

	  return column;
	};
	// 默认单元格渲染函数
	var DEFAULT_RENDER_CELL = function DEFAULT_RENDER_CELL(h, _ref7) {
	  var row = _ref7.row,
	      column = _ref7.column;

	  var property = column.property;
	  if (column && column.formatter) {
	    return column.formatter(row, column);
	  }

	  if (property && property.indexOf('.') === -1) {
	    return row[property];
	  }

	  return (0, _util.getValueByPath)(row, property);
	};

	exports.default = {
	  name: 'ElTableColumn',

	  props: {
	    // 列的类型
	    type: {
	      type: String,
	      default: 'default'
	    },
	    // 列头标题
	    label: String,
	    // 列的样式类名
	    className: String,
	    // 列头的样式类名
	    labelClassName: String,
	    // 列绑定的字段名称
	    property: String,
	    // 列绑定的字段名称，同于 property
	    prop: String,
	    // 列宽
	    width: {},
	    // 列的最小宽度
	    minWidth: {},
	    // 列头渲染函数
	    renderHeader: Function,
	    // 是否可排序或自定义排序
	    sortable: {
	      type: [String, Boolean],
	      default: false
	    },
	    // 指定排序方法
	    sortMethod: Function,
	    // 是否允许调整列宽
	    resizable: {
	      type: Boolean,
	      default: true
	    },
	    // 所属的表格对象
	    context: {},
	    // 列的键值
	    columnKey: String,
	    // 列的单元格排序方式
	    align: String,
	    // 列头排序方式
	    headerAlign: String,
	    // 内容过长时显示气泡提示，兼容老版
	    showTooltipWhenOverflow: Boolean,
	    // 内容过长时显示气泡提示，同上
	    showOverflowTooltip: Boolean,
	    // 是否为固定列
	    fixed: [Boolean, String],
	    // 单元格格式化函数
	    formatter: Function,
	    // 为选择列时，行是否可选的回调函数
	    selectable: Function,
	    // 是否保留选择集
	    reserveSelection: Boolean,
	    // 筛选函数
	    filterMethod: Function,
	    // 过滤选项预设值
	    filteredValue: Array,
	    // 过滤选项列表
	    filters: Array,
	    // 过滤是否允许多选
	    filterMultiple: {
	      type: Boolean,
	      default: true
	    },
	    summaryType: String,
	    summaryAlign: String,
	    summaryFormatter: Function
	  },

	  data: function data() {
	    return {
	      // 是否为子列
	      isSubColumn: false,
	      // 未使用的变量
	      columns: []
	    };
	  },
	  beforeCreate: function beforeCreate() {
	    this.row = {};
	    this.column = {};
	    this.$index = 0;
	  },


	  components: {
	    ElCheckbox: _checkbox2.default,
	    ElTag: _tag2.default
	  },

	  computed: {
	    // 获取所属的表格组件
	    owner: function owner() {
	      var parent = this.$parent;
	      while (parent && !parent.tableId) {
	        parent = parent.$parent;
	      }
	      return parent;
	    }
	  },

	  created: function created() {
	    var _this = this;

	    this.customRender = this.$options.render;
	    this.$options.render = function (h) {
	      return h('div', _this.$slots.default);
	    };
	    this.columnId = (this.$parent.tableId || this.$parent.columnId + '_') + 'column_' + columnIdSeed++;

	    var parent = this.$parent;
	    var owner = this.owner;
	    this.isSubColumn = owner !== parent;

	    var type = this.type;
	    // 计算实际宽度
	    var width = this.width;
	    if (width !== undefined) {
	      width = parseInt(width, 10);
	      if (isNaN(width)) {
	        width = null;
	      }
	    }
	    // 计算最小宽度
	    var minWidth = this.minWidth;
	    if (minWidth !== undefined) {
	      minWidth = parseInt(minWidth, 10);
	      if (isNaN(minWidth)) {
	        minWidth = 80;
	      }
	    }

	    var isColumnGroup = false;
	    // 获取默认列对象
	    var column = getDefaultColumn(type, {
	      id: this.columnId,
	      columnKey: this.columnKey,
	      label: this.label,
	      className: this.className,
	      labelClassName: this.labelClassName,
	      property: this.prop || this.property,
	      type: type,
	      renderCell: null,
	      renderHeader: this.renderHeader,
	      minWidth: minWidth,
	      width: width,
	      isColumnGroup: isColumnGroup,
	      context: this.context,
	      align: this.align ? 'is-' + this.align : null,
	      headerAlign: this.headerAlign ? 'is-' + this.headerAlign : this.align ? 'is-' + this.align : null,
	      sortable: this.sortable === '' ? true : this.sortable,
	      sortMethod: this.sortMethod,
	      resizable: this.resizable,
	      showOverflowTooltip: this.showOverflowTooltip || this.showTooltipWhenOverflow,
	      formatter: this.formatter,
	      selectable: this.selectable,
	      reserveSelection: this.reserveSelection,
	      fixed: this.fixed === '' ? true : this.fixed,
	      filterMethod: this.filterMethod,
	      filters: this.filters,
	      filterable: this.filters || this.filterMethod,
	      filterMultiple: this.filterMultiple,
	      filterOpened: false,
	      filteredValue: this.filteredValue || [],
	      summaryType: this.summaryType || null,
	      summaryAlign: this.summaryAlign ? 'is-' + this.summaryAlign : this.align ? 'is-' + this.align : null
	    });
	    // 将选择列、序号列等特殊列属性并入列对象
	    (0, _merge2.default)(column, forced[type] || {});
	    // columnConfig 指向列对象
	    this.columnConfig = column;
	    // 定义单元格渲染方法
	    var renderCell = column.renderCell;
	    var _self = this;
	    // 对于可展开行还要设置展开面板的渲染方式
	    if (type === 'expand') {
	      owner.renderExpanded = function (h, data) {
	        return _self.$scopedSlots.default ? _self.$scopedSlots.default(data) : _self.$slots.default;
	      };

	      column.renderCell = function (h, data) {
	        return h(
	          'div',
	          { 'class': 'cell' },
	          [renderCell(h, data, this._renderProxy)]
	        );
	      };

	      return;
	    }
	    // 设置单元格渲染方法
	    column.renderCell = function (h, data) {
	      // 未来版本移除
	      if (_self.$vnode.data.inlineTemplate) {
	        renderCell = function renderCell() {
	          data._self = _self.context || data._self;
	          if (Object.prototype.toString.call(data._self) === '[object Object]') {
	            for (var prop in data._self) {
	              if (!data.hasOwnProperty(prop)) {
	                data[prop] = data._self[prop];
	              }
	            }
	          }
	          // 静态内容会缓存到 _staticTrees 内，不改的话获取的静态数据就不是内部 context
	          data._staticTrees = _self._staticTrees;
	          data.$options.staticRenderFns = _self.$options.staticRenderFns;
	          return _self.customRender.call(data);
	        };
	      } else if (_self.$scopedSlots.default) {
	        renderCell = function renderCell() {
	          return _self.$scopedSlots.default(data);
	        };
	      }

	      if (!renderCell) {
	        renderCell = DEFAULT_RENDER_CELL;
	      }
	      // 最终返回的单元格内容，包括气泡提示组件
	      return _self.showOverflowTooltip || _self.showTooltipWhenOverflow ? h(
	        'el-tooltip',
	        {
	          attrs: {
	            effect: this.effect,
	            placement: 'top',
	            disabled: this.tooltipDisabled }
	        },
	        [h(
	          'div',
	          { 'class': 'cell' },
	          [renderCell(h, data)]
	        ), h(
	          'span',
	          { slot: 'content' },
	          [renderCell(h, data)]
	        )]
	      ) : h(
	        'div',
	        { 'class': 'cell' },
	        [renderCell(h, data)]
	      );
	    };
	  },
	  destroyed: function destroyed() {
	    if (!this.$parent) return;
	    // 从表格状态管理对象中移除列
	    this.owner.store.commit('removeColumn', this.columnConfig);
	  },


	  watch: {
	    // 返回列标题
	    label: function label(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.label = newVal;
	      }
	    },

	    // 返回列绑定的字段名
	    prop: function prop(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.property = newVal;
	      }
	    },

	    // 返回列绑定的字段名
	    property: function property(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.property = newVal;
	      }
	    },

	    // 返回过滤选项列表
	    filters: function filters(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.filters = newVal;
	      }
	    },

	    // 返回是否允许多选
	    filterMultiple: function filterMultiple(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.filterMultiple = newVal;
	      }
	    },

	    // 返回对齐方式
	    align: function align(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.align = newVal ? 'is-' + newVal : null;

	        if (!this.headerAlign) {
	          this.columnConfig.headerAlign = newVal ? 'is-' + newVal : null;
	        }
	      }
	    },

	    // 返回列头对齐方式
	    headerAlign: function headerAlign(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.headerAlign = 'is-' + (newVal ? newVal : this.align);
	      }
	    },

	    // 返回列宽
	    width: function width(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.width = newVal;
	        this.owner.store.scheduleLayout();
	      }
	    },

	    // 返回最小列宽
	    minWidth: function minWidth(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.minWidth = newVal;
	        this.owner.store.scheduleLayout();
	      }
	    },

	    // 返回是否为固定列
	    fixed: function fixed(newVal) {
	      if (this.columnConfig) {
	        this.columnConfig.fixed = newVal;
	        this.owner.store.scheduleLayout();
	      }
	    }
	  },

	  mounted: function mounted() {
	    var owner = this.owner;
	    var parent = this.$parent;
	    var columnIndex = void 0;
	    // 获取列序号
	    if (!this.isSubColumn) {
	      columnIndex = [].indexOf.call(parent.$refs.hiddenColumns.children, this.$el);
	    } else {
	      columnIndex = [].indexOf.call(parent.$el.children, this.$el);
	    }
	    // 在表格状态管理对象中插入列
	    owner.store.commit('insertColumn', this.columnConfig, columnIndex, this.isSubColumn ? parent.columnConfig : null);
	  }
	};

/***/ },

/***/ 28:
/***/ function(module, exports) {

	module.exports = require("element-ui/lib/utils/merge");

/***/ }

/******/ });