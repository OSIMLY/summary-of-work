<template>
    <div class="transform-item"
         v-Clickoutside="handleClickoutside">
        <el-input v-if="type==='input'"
                  :style="{width:'100%',height:'100%'}"
                  :icon="typeof icon!=='undefined'?icon:null"
                  :value="value"
                  :placeholder="placeholder"
                  :disabled="disabled"
                  :readonly="readonly"
                  @click.stop="handleInputIconClick"
                  @input.native="handleEditorChange($event.target.value)"
                  @mouseover.native="handleEditorMouseOver($event)">
        </el-input>
        <el-select v-else-if="type==='select'"
                   :style="{width:'100%',height:'100%'}"
                   :value="value"
                   :placeholder="placeholder"
                   :filterable="filterable"
                   :allow-create="allowCreate"
                   :filter-method="filterMethod"
                   :disabled="disabled"
                   :readonly="readonly"
                   @click.native.stop
                   @input="handleEditorChange(arguments[0])">
            <el-option v-for="option in commonData"
                       :label="option.text"
                       :value="option.value"
                       :disabled="option.disabled">
                <span v-if="showDetail">
                                    <span class="option-left">{{option.text}}</span>
                <span class="option-right">{{option.value}}</span>
                </span>
            </el-option>
        </el-select>
        <el-cascader v-else-if="type==='cascader'"
                     :style="{width:'100%',height:'100%'}"
                     :value="value"
                     :options="commonData"
                     :props="props"
                     :clearable="clearable"
                     :expand-trigger="expandTrigger"
                     :show-all-levels="showAllLevels"
                     :filterable="filterable"
                     :change-on-select="changeOnSelect"
                     :poper-class="poperClass"
                     :placeholder="placeholder"
                     :disabled="disabled"
                     :readonly="readonly"
                     @click.native.stop
                     @active-item-change="handleCascaderActiveItemChange"
                     @input="handleEditorChange(arguments[0])">
        </el-cascader>
        <t8t-datetime-picker v-else-if="type==='datetime'||type==='date'||type==='time'"
                             v-model="value"
                             :bindValue="(value===null||value===0)?'':value"
                             :style="{width:'100%',height:'100%'}"
                             :placeholder="placeholder"
                             :type="type || 'date'"
                             :endFormater="endFormater"
                             :clearable="clearable"
                             :poper-class="poperClass"
                             :disabled="disabled"
                             :readonly="readonly"
                             @change="handleEditorChange(arguments[1])">
        </t8t-datetime-picker>
        <el-date-picker v-else-if="type==='el-datetime'"
                        type="datetime"
                        :value="(value===null||value===0)?'':value*1000"
                        :style="{width:'100%',height:'100%'}"
                        :placeholder="placeholder"
                        :disabled="disabled"
                        :readonly="readonly"
                        @input="handleEditorChange(Date.parse(arguments[0])/1000)">
        </el-date-picker>
        <el-button v-else-if="type==='button'"
                   size="small"
                   :disabled="disabled"
                   @click.stop="handleButtonClick">
            {{ text }}
        </el-button>
        <el-radio v-else-if="type==='radio'"
                  :label="value"
                  :disabled="disabled"
                  @change="handleEditorChange(arguments[0])">
        </el-radio>
        <el-switch v-else-if="type==='switch'"
                   :value="value"
                   :disabled="disabled"
                   @input="handleEditorChange(arguments[0])">
        </el-switch>
        <t8t-form-popup v-else-if="type==='popup'"
                        :bindValue="value"
                        :textValue="textValue"
                        :filedValue="filedValue"
                        :style="{width:'100%',height:'100%'}"
                        :dialog="dialog"
                        @change="handleEditorChange(arguments[0])">
        </t8t-form-popup>
        <t8t-lookup v-else-if="type==='lookup'"
                    :style="{width:'100%',height:'100%'}"
                    :value="value"
                    :placeholder="placeholder"
                    :disabled="disabled"
                    :readonly="readonly"
                    :service="service"
                    :method="method"
                    :dataSource="dataSource"
                    :args="args"
                    :columns="columns"
                    :searchExpr="searchExpr"
                    :valueExpr="valueExpr"
                    :toolbar="toolbar"
                    :multiple="multiple"
                    :filter-method="filterMethod"
                    :size="size"
                    @input="handleEditorChange(arguments[0])"
                    @mouseover.native="handleEditorMouseOver($event)">
        </t8t-lookup>
    </div>
</template>

<script>
import T8tDatetimePicker from 'src/components/t8t-form/dateTimePicker.vue'
import T8tFormPopup from 'src/components/t8t-form-popup/t8t-form-popup.vue'
import T8tLookup from './t8t-lookup.vue'
import { getCellByEl } from '../utils/utils.js'
import Clickoutside from '../utils/clickoutside.js'
import emitter from '../utils/emitter.js'
export default {
    name: 't8t-transform-item',
    components: {
        T8tDatetimePicker,
        T8tFormPopup,
        T8tLookup
    },
    directives: { Clickoutside },
    mixins: [emitter],
    created() {

    },
    mounted() {
        let self = this
        if (this.haveSameParent()) {
            setTimeout(function () {
                switch (self.type) {
                    case 'input':
                        self.$children[0].$refs.input.focus()
                        break
                    case 'select':
                        self.$children[0].handleFocus()
                        break
                    case 'lookup':
                        self.$children[0].focus()
                        break
                    default:
                        break
                }
            }, 0)
        }
    },
    props: {
        type: String,
        parent: Object,
        value: [String, Number],
        commonData: [Array, Object],
        text: [String, Function],
        placeholder: {
            type: String,
            default: ''
        },
        disabled: {
            type: Boolean,
            default: false
        },
        readonly: {
            type: Boolean,
            default: false
        },
        poperClass: String,
        clearable: Boolean,
        filterable: Boolean,
        // for input only
        icon: String,
        // for select only
        allowCreate: Boolean,
        filterMethod: Function,
        showDetail: {
            type: Boolean,
            default: false
        },
        // for datetime-picker only
        endFormater: String,
        align: String,
        pickerOptions: Object,
        rangeSeparator: String,
        // for cascader only
        options: Array,
        props: Object,
        expandTrigger: String,
        showAllLevels: Boolean,
        changeOnSelect: Boolean,
        // for popup only
        dialog: Object,
        textValue: String,
        filedValue: String,
        // for lookup only
        service: String,
        method: String,
        dataSource: Array,
        args: Object,
        columns: Array,
        searchExpr: Array,
        valueExpr: String,
        toolbar: Boolean,
        multiple: String,
        size: String
    },
    methods: {
        handleClickoutside(e) {
            if (this.haveSameParent()) {
                this.$emit('blur')
            }
        },
        haveSameParent() {
            let tdEl = getCellByEl(this.$el)
            return this.parent === tdEl
        },
        handleEditorChange(val) {
            this.$emit('change', val)
            this.dispatch('ElFormItem', 'el.form.change', [val])
        },
        handleEditorMouseOver(event) {
            this.$emit('mouse-over', event)
        },
        handleInputIconClick() {
            this.$emit('input-icon-click')
        },
        handleButtonClick() {
            this.$emit('button-click')
        },
        handleCascaderActiveItemChange(val) {
            this.$emit('cascader-active-item-change', val)
        }
    }
}
</script>

<style>

</style>
