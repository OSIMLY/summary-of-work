---
category: components
name: t8t-lookup
purpose: 可搜索并显示详细信息的下拉选单。
---

## 何时使用

- 当传统 select 组件无法满足业务需求时。
- 当需要对下拉列表中的数据进行搜索时。
- 当需要在列表中显示较多字段时。

## 如何使用

- 在表格列配置中定义 editor.type = 'lookup' 即可。

``` json
{
    'prop': 'receiptor',
    'label': '收款对象',
    'editor': {
        'type': 'lookup',
        'service': service.RECEIPTPLANORDER.name,
        'method': service.RECEIPTPLANORDER.methods.QUERYPAGE,
        'columns': [{
            'prop': 'code',
            'label': '单据编号'
        }, {
            'prop': 'receiptOrgName',
            'label': '组织'
        }],
        'valueExpr': 'code'
        'searchExpr': [
            'code'
        ]
    }
}
```

- 指定表格的数据源及列模板 `servive`、`method`、`columns`。
- 指定选择后返回的字段名称 `valueExpr`。
- 指定搜索时自动模糊匹配的字段名称 `searchExpr`，可以为多个。
- 如果需要自定义搜索可以设置 `filter-method` 属性，并在回调函数中处理搜索方式，并返回 args 对象。

``` json
'editor': {
    'type': 'lookup',
    'filterMethod': function (val, args) {
        args['search'] = {
            'code_like': val
        }
        return args
    },
}
```

## API

### lookup

| 参数           | 说明                     | 类型             | 默认值   |
|---------------|--------------------------|-----------------|---------|
| service | 表格数据绑定的服务名 | String |  |
| method | 服务对应的接口名 | String |  |
| dataSource | 内置表格的数据源 | Array |  |
| args | 服务对应的接口名 | String |  |
| value | 选项的值 | String / Number / Object |  |
| placeholder | 占位符 | String |  |
| disabled | 是否禁用 | Boolean |  |
| readonly | 是否为只读 | Boolean |  |
| size | 选项面板的尺寸，可设置 `large`、`small` | String | `large` |
| searchExpr | 模糊搜索时自动匹配的字段名称列表 | Array |  |
| valueExpr | 作为选项返回值的字段名称，若不设置此属性则返回行对象 | String |  |
| multiple | 是否允许多选 | Boolean |  |
| toolbar | 是否显示工具栏，单选默认不显示（双击确定选项），多选默认显示 | Boolean |  |
| filter-method | 自定义搜索方法 | Function |  |