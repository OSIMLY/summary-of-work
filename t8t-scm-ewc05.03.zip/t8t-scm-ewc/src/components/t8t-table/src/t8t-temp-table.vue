<template>
    <div class="t8t-table">
        <!--按钮组-->
        <div class="toolbar-container">
            <el-button
                v-for="item in buttons"
                size="toolbar"
                v-show="!isEditable"
                :disabled="isEditable"
                :symbol="item.symbol"
                @click="handleClick(item.symbol)"
            >{{item.name}}</el-button>
        </div>
        <!--数据表-->
        <div class="table-container">
            <el-table
                ref="mainTable"
                height="theHeight"
                border
                stripe
                v-loading="isLoading"
                :data="localData"
                :style="{height:'100%'}"
                :row-class-name="tableRowClassName"
                @current-change="handleCurrentRowChange"
                @row-dblclick="handleRowDblclick"
                @selection-change="handleSelectionChange"
                @row-click="handleRowClick"
                @sort-change="handleSortChange"
                @select="handleSelect"
            >
                <el-table-column
                    header-align="center"
                    align="center"
                    type="selection"
                    fixed
                    width="38"
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="code"
                    label="组织编码"
                    sortable="custom"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    prop="name"
                    label="组织名称"
                    sortable="custom"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="typeCode"
                    :formatter="fmtTypeCode"
                    label="组织形态"
                    sortable="custom"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="contactUser"
                    label="联系人"
                    sortable="custom"
                    :formatter="fmtContactUser"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    prop="location"
                    label="地址"
                    sortable="custom"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="isDel"
                    label="禁用状态"
                    sortable="custom"
                    min-width="200"
                    :formatter="fmtIsDel"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    prop="description"
                    label="描述"
                    sortable="custom"
                    min-width="200"
                    show-overflow-tooltip
                >
                </el-table-column>
            </el-table>
        </div>
        <!--分页栏-->
        <div class="pagenav-container">
            <t8t-el-pagination
                @current-change="handleCurrentPageChange"
                @size-change="handleSizeChange"
                :current-page="currentPage"
                :total="totalPages"
                :page-sizes="[5,10,20,30,50]"
                layout="sizes, first, prev, jumper, next, last, refresh, ->, total"
                :page-size="pageSize"
            >
            </t8t-el-pagination>
        </div>
    </div>
</template>

<script>
    import T8tTableInput from './t8t-table-input.vue'
    import T8tTableSelect from './t8t-table-select.vue'
    import Perm from 'src/services/permission/Perm.js'
    export default {
        name: 'T8tTempTable',
        components: {
            T8tTableInput,
            T8tTableSelect
        },
        data() {
            return {
                localData: [],
                isEditable: false,
                selection: [],
                buttons: []
            }
        },
        mounted() {
            //Perm.buttons("System/org/index")
            Perm.buttons("#" + this.$route.path)
                .then((res) => {
                    this.buttons = res.data.result
                })
        },
        computed: {
            //表格数据
            tableData: {
                get() {
                    return this.$store.state.organization.tableData
                },
                set(value) {
                    this.$store.commit('SET_TABLEDATA', value)
                }
            },
            //空数据行模板
            blankData: {
                get() {
                    let strBlankData = JSON.stringify(this.$store.state.blankData)
                    return JSON.parse(strBlankData)
                }
            },
            //通用数据
            commonData() {
                return this.$store.state.commonData
            },
            // states
            commonState() {
                return this.$store.state.organization
            },
            //表格状态
            tableStatus: {
                get() {
                    return this.$store.state.organization.tableStatus
                },
                set(value) {
                    this.$store.commit('SET_TABLESTATUS', value)
                }
            },
            //当前行数据对象
            currentRow: {
                get() {
                    return this.$store.state.organization.tableStatus.viewStatus.currentRow
                },
                set(value) {
                    this.$store.commit('SET_TAB_VIEW_CURRENTROW', value)
                }
            },
            //当前行序号
            currentIndex: {
                get() {
                    return this.$store.state.organization.tableStatus.viewStatus.currentIndex
                },
                set(value) {
                    this.$store.commit('SET_TAB_VIEW_CURRENTINDEX', value)
                }
            },
            //是否显示加载中画面
            isLoading: {
                get() {
                    return this.$store.state.organization.tableStatus.viewStatus.isLoading
                },
                set(value) {
                    this.$store.commit('SET_TAB_VIEW_ISLOADING', value)
                }
            },
            //当前页
            currentPage: {
                get() {
                    return this.$store.state.organization.tableStatus.pageStatus.currentPage
                },
                set(value) {
                    this.$store.commit('SET_TAB_PAGE_CURRENTPAGE', value)
                }
            },
            //每页条目数量
            pageSize: {
                get() {
                    return this.$store.state.organization.tableStatus.pageStatus.pageSize
                },
                set(value) {
                    this.$store.commit('SET_TAB_PAGE_PAGESIZE', value)
                }
            },
            //页码总数
            totalPages: {
                get() {
                    return this.$store.state.organization.tableStatus.pageStatus.totalPages
                },
                set(value) {
                    this.$store.commit('SET_TAB_PAGE_TOTAL', value)
                }
            },
            //排序状态
            sortStatus: {
                get() {
                    return this.$store.state.organization.tableStatus.sortStatus
                },
                set(value) {
                    this.$store.commit('SET_TAB_SORT', value)
                }
            },
            // add by allen.yao
            SelectedRows: {
                get() {
                    return this.$store.state.organization.tableStatus.SelectedRows
                },
                set(value) {
                    this.$store.commit('SET_TABLE_SelectedRows', value)
                }
            }
        },
        watch: {
            //state变化更新本地数据localData
            tableData: {
                handler: function (val, oldVal) {
                    this.localData = []
                    let strTableData = JSON.stringify(val)
                    this.localData = JSON.parse(strTableData)
                }
            },
            //切换编辑状态
            isEditable: function (val, oldVal) {
                if (val && !oldVal) {
                    this.clearSelection()
                    this.localData.unshift(this.blankData)
                } else if (oldVal && !val) {
                    console.log()
                    this.localData.shift()
                }
            }
        },
        methods: {
            handleClick(event) {
                if (event == 'VIEW') {
                    this.btnLook()
                } else if (event == 'EDIT') {
                    this.btnEdit()
                }
            },
            /*事件回调函数*/
            //处理选中行变化
            handleSelectionChange(val) {
                this.selection = val
                let selectionLen = val.length
                let _defaultRow = selectionLen > 0 ? val[val.length - 1] : {}
                let index = selectionLen > 0 ? this.localData.indexOf(_defaultRow) : 0
                this.$store.commit('SET_TABLE_SELECTEDROW', {
                    index: index,
                    row: _defaultRow
                })
            },
            handleSelect(selection, row) {
                // 多选情况下默认选第一个当做选中项
                let _defaultRow = selection[selection.length - 1]
                let index = this.localData.indexOf(_defaultRow)
                this.$store.commit('SET_TABLE_SELECTEDROW', {
                    index: index,
                    row: _defaultRow
                })
            },
            //处理页码变化
            handleCurrentPageChange(val) {
                this.$store.commit('SET_TAB_PAGE_CURRENTPAGE', val)
                this.$store.dispatch('loadTableData1')
            },
            //处理每页行数变化
            handleSizeChange(val) {
                this.$store.commit('SET_TAB_PAGE_PAGESIZE', val)
                this.$store.dispatch('loadTableData1')
            },
            //处理行双击事件
            handleRowDblclick(row, event) {
                let index = this.localData.indexOf(row)
                this.$store.commit('SET_TABLE_SELECTEDROW', {
                    index: index,
                    row: row
                })
                this.showEditDialog('retrieve')
            },
            //处理行单击事件
            handleRowClick(row, event, column) {
                if (column.type !== 'selection' && !this.isEditable) {
                    this.$refs.mainTable.toggleRowSelection(row)
                }
            },
            //处理当前行改变
            handleCurrentRowChange(curRow, oldRow) {
                let index = this.localData.indexOf(curRow)
                this.currentRow = curRow
                this.currentIndex = index
            },
            //显示对话框
            showEditDialog(arg) {
                if (!this.isEditable) {
                    this.$store.commit('INIT_DIALOG', {
                        isShow: true,
                        status: arg,
                    })
                }
            },
            //点击新增按钮
            btnInsertClick() {
                //this.localData.unshift(this.blankData)
                this.currentRow = this.blankData
                this.currentIndex = 0
                this.showEditDialog()
            },
            btnEdit() {
                // 编辑
                if (this.selection.length === 0) {
                    this.$msgbox({
                        title: '消息',
                        type: 'warning',
                        message: '请选择要处理的行。',
                        showCancelButton: false,
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        confirmButtonClass: 'is-plain'
                    })
                    return
                } else {
                    this.showEditDialog('update')
                }

            },
            btnLook() {
                // 查看
                if (this.selection.length === 0) {
                    this.$msgbox({
                        title: '消息',
                        type: 'warning',
                        message: '请选择要处理的行。',
                        showCancelButton: false,
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        confirmButtonClass: 'is-plain'
                    })
                    return
                } else {
                    this.showEditDialog('retrieve')
                }
            },
            //点击删除按钮
            btnDeleteClick() {
                let index
                let selectedIndex = []
                if (this.selection.length === 0) {
                    this.$message.error('请选择要处理的行。')
                } else {
                    this.$confirm('确定删除此项吗？', '提示', {
                        type: 'warning'
                    }).then(() => {
                        this.selection.forEach((item) => {
                            selectedIndex.push(item.id)
                        })
                        if (!this.isEditable) {
                            this.$store.commit('DEL_TAB_DATA_ROW', selectedIndex)
                        }
                        this.$message({
                            type: 'success',
                            message: '删除成功！'
                        })
                    })
                }
            },
            //清除选区
            clearSelection() {
                this.$refs.mainTable.clearSelection()
            },
            //判断表格处于可编辑状态
            isSelectable(row, index) {
                if (this.isEditable) {
                    return false
                } else {
                    return true
                }
            },
            //判断行可编辑
            getRowEditable(row) {
                let isBlankRow = (row === this.localData[0])
                let isCurrentRow = (row === this.currentRow)
                if (this.isEditable && (isBlankRow || isCurrentRow)) {
                    return true
                } else {
                    return false
                }
            },
            //内嵌表单弹框编辑
            handleIconClick(row) {
                this.currentRow = row
                this.dialogData.typeCode = this.currentRow.typeCode
                this.$refs.codeSelector.open()
            },
            //提交内嵌表单
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.isEditable = false
                        this.clearSelection()
                        this.$message.info('提交成功！')
                    } else {
                        this.$message.info('请完善表单信息。')
                    }
                })
            },
            //重置内嵌表单
            resetForm(formName) {
                this.$refs[formName].resetFields()
                this.isEditable = false
            },
            //切换选中行样式
            tableRowClassName(row, index) {
                const exsist = this.selection.indexOf(row)
                if (exsist !== -1) {
                    return 'selected-row'
                }
            },
            //格式化字段 - 组织形态
            fmtTypeCode(row, column) {
                let item = this.commonState.typeCodeOptions.filter((item) => item.code === row.typeCode)
                if (item[0]) { return item[0].name }
            },
            //格式化字段 - 联系人
            fmtContactUser(row, column) {
                let item = this.commonData.contactUser.filter((item) => item.value === row.contactUser)
                if (item[0]) { return item[0].text }
            },
            //格式化字段 - 禁用状态
            fmtIsDel(row, column) {
                let item = this.commonData.isDel.filter((item) => item.value === row.isDel)
                if (item[0]) { return item[0].text }
            },
            //显示红色 '*' 必填列
            //<el-table-column :render-header="required">
            required(h, {
                column,
                $index
            }) {
                return h('span', {}, [h('span', {
                    attrs: {
                        class: 'required-tag'
                    }
                }, '* '), h('span', column.label)])
            },
            //处理表头排序
            handleSortChange({
                column,
                prop,
                order
            }) {
                switch (order) {
                    case 'ascending':
                        this.sortStatus = [prop + '_asc']
                        break
                    case 'descending':
                        this.sortStatus = [prop + '_desc']
                        break
                    default:
                        this.sortStatus = [prop + '_asc']
                }
                this.$store.dispatch('loadTableData1')
            },
            //处理表头筛选
            handleFilterChange(filters) {
            }
        }
    }

</script>

<style
    lang="css"
    scoped
>
    .t8t-table {
        display: flex;
        flex: 1;
        flex-direction: column;
        overflow: auto;
    }

    .t8t-table .toolbar-container {
        margin: 13px;
        height: 24px;
    }

    .t8t-table .table-container {
        flex: 1;
        overflow: auto;
        margin-left: -1px;
    }

    .t8t-table .el-form {
        height: 100%
    }

    .t8t-table .pagenav-container {
        padding: 11px;
        background: rgba(245, 245, 250, 1);
        border-top: 1px solid #D3DDE6;
        margin-top: -1px;
    }

    .t8t-table .table-container .el-form-item {
        margin-bottom: 0px;
    }

    .t8t-table .el-button--toolbar:first-child {
        margin-left: 8px;
    }

    .t8t-table .el-button--toolbar {
        padding: 5px 11px;
        font-size: 12px;
        border-radius: 2px;
        border-color: rgb(232, 237, 241);
        color: rgb(50, 139, 239);
        margin-right: 5px;
    }

    .t8t-table .el-button--toolbar:focus {
        border-color: rgb(191, 201, 217)
    }

    .t8t-table .el-button--toolbar:hover {
        border-color: rgb(50, 139, 239)
    }

    .t8t-table .el-button--success.is-plain {
        color: rgb(19, 206, 102)
    }

    .t8t-table .el-button--danger.is-plain {
        color: rgb(255, 86, 97)
    }

    .t8t-table .el-button + .el-button {
        margin-left: 0px;
    }
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    /*此处样式有冲突，暂时强制显示，还需优化*/

    .t8t-table .el-pagination .btn-next,
    .t8t-table .el-pagination .btn-prev,
    .t8t-table .el-pagination .btn-first,
    .t8t-table .el-pagination .btn-last,
    .t8t-table .el-pagination .btn-refresh {
        border: none !important;
        background: transparent !important;
        color: #3296FA !important;
        cursor: pointer;
    }

    .t8t-table .btn-refresh {
        margin-left: 20px !important;
    }

    .t8t-table .el-pagination {
        padding: 0px !important;
    }

    .t8t-table .el-pagination button.disabled {
        border: none !important;
        color: #97a8be !important;
    }

    .t8t-table .table-container .cell {
        padding: 4px 10px !important;
        border-color: rgb(212, 220, 230) !important;
        /*这两行会使内嵌表单错位*/
        /*height: 40px;
        line-height: 32px;*/
    }

    .el-table {
        color: #666 !important;
        font-size: 12px !important;
        border-color: rgb(212, 220, 231)!important;
    }

    .t8t-table .el-checkbox__inner {
        border-color: rgb(142, 143, 143) !important;
        transition: none !important;
    }

    .t8t-table .el-checkbox__input.is-checked .el-checkbox__inner {
        border-color: rgb(50, 150, 250) !important;
    }

    .t8t-table .el-checkbox__input.is-disabled .el-checkbox__inner {
        border-color: rgb(209, 217, 229) !important;
    }

    .t8t-table .t8t-table .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner {
        background-color: rgb(209, 217, 229) !important;
        border-color: rgb(209, 217, 229) !important;
    }

    .t8t-table .el-checkbox__inner::after {
        border-color: rgb(50, 150, 250) !important;
        transition: none !important;
    }

    .t8t-table .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner::after {
        border-color: #fff !important;
    }

    .t8t-table .el-table td {
        border-color: rgb(226, 223, 239) !important;
    }

    .t8t-table .el-table td .cell {
        user-select: none;
        cursor: default;
    }

    .t8t-table .el-table th {
        border-color: rgb(226, 223, 239) !important;
    }

    .t8t-table .el-table th .cell {
        user-select: none;
        cursor: pointer;
    }

    .t8t-table .el-table th,
    .t8t-table .el-table th .cell {
        background-color: rgba(245, 245, 250, 1) !important;
    }

    .t8t-table .selected-row {
        background-color: rgba(243, 246, 255, 1) !important;
    }

    .t8t-table .el-table--striped .el-table__body tr:nth-child(2n).selected-row td {
        background-color: rgba(243, 246, 255, 1)
    }

    .t8t-table .el-table--striped .el-table__body tr:nth-child(2n).current-row td {
        background-color: rgba(243, 246, 255, 1)
    }

    .t8t-table .el-table__body tr.hover-row>td {
        background-color: rgba(235, 240, 255, 1) !important;
    }

    .t8t-table .el-table--enable-row-hover tr:hover>td {
        background-color: rgba(235, 240, 255, 1) !important;
    }

    .t8t-table .el-table--enable-row-transition .el-table__body td {
        transition: none !important;
    }

    .t8t-table .el-button.is-disabled,
    .t8t-table .el-button.is-disabled:hover,
    .t8t-table .el-button.is-disabled:focus {
        background-color: rgb(250, 250, 250) !important
    }

    .t8t-table .el-input__inner {
        font-size: 12px !important;
    }

    .t8t-table .el-pagination .el-select .el-input {
        width: 60px !important;
    }
    /*分页器按钮*/

    .t8t-table .nav-icon {
        display: block;
        width: 16px;
        height: 16px;
        background-position-y: 0px;
        background-image: url(../images/page-arrow.png);
    }

    .t8t-table button.disabled .nav-icon {
        background-position-y: -16px;
    }

    .t8t-table .icon-first {
        background-position-x: 0px;
    }

    .t8t-table .icon-prev {
        background-position-x: -25px;
    }

    .t8t-table .icon-next {
        background-position-x: -50px;
    }

    .t8t-table .icon-last {
        background-position-x: -75px;
    }

    .t8t-table .icon-refresh {
        background-position-x: -105px;
    }
    /*pageBtn end*/

    .t8t-table .el-pagination__jump {
        margin-left: 0px !important;
    }

    .t8t-table .el-pagination__jump input {
        font-size: 12px;
    }

    .t8t-table .el-pagination__jump input:disabled {
        background-color: rgb(238, 241, 246);
        color: #bbb;
    }

    .t8t-table .el-pagination span,
    .t8t-table .el-pagination button {
        font-size: 12px !important;
    }

    .t8t-table .required-tag {
        color: rgb(255, 73, 74);
        font-family: sans-serif;
    }

    .t8t-table .el-table__fixed,
    .t8t-table .el-table__fixed-right {
        /*box-shadow: 1px -2px 10px rgb(233, 233, 238) !important;*/
        box-shadow: none!important;
    }

    .t8t-table .el-loading-mask {
        z-index: 1000!important;
    }

    .t8t-table .el-select .el-input .el-input__icon {
        color: rgb(31, 48, 69)!important;
        transform: translateY(-50%) rotateZ(180deg) scaleX(0.8)!important;
    }

    .el-select .el-input .el-input__icon.is-reverse {
        transform: translateY(-50%) scaleX(0.8)!important;
    }

    .el-table .caret-wrapper {
        display: none !important;
    }

    .el-table .ascending .caret-wrapper {
        display: inline-block !important;
    }

    .el-table .descending .caret-wrapper {
        display: inline-block !important;
    }

    .el-table .sort-caret.descending {
        display: none;
    }

    .el-table .sort-caret.ascending {
        display: none;
    }

    .el-table .ascending .sort-caret.ascending {
        display: block;
        top: 15px;
        border-bottom: 5px solid #48576a!important;
    }

    .el-table .descending .sort-caret.descending {
        display: block;
        bottom: 15px;
        border-top: 5px solid #48576a!important;
    }
    /* 低版本 */

    .chrome_lower .t8t-table .table-container {
        position: relative;
        min-height: 100%;
    }

    .chrome_lower .t8t-table .table-container .el-table {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
</style>
