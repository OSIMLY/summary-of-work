<template>
    <div class="t8t-table">
        <div class="table-container">
            <el-table
                :data="dataSource"
                :height="height"
                :stripe="stripe"
                :border="border"
                :fit="fit"
                :show-header="showHeader"
                :highlight-current-row="highlightCurrentRow"
                :current-row-key="currentRowKey"
                :row-class-name="rowClassName"
                :row-style="rowStyle"
                :row-key="rowKey"
                :empty-text="emptyText"
                :default-expand-all="defaultExpandAll"
                :expand-row-keys="expandRowKeys"
                :default-sort="defaultSort"
                @select="onSelect"
                @select-all="onSelectAll"
                @row-click="onRowClick"
                @selection-change="onSeletionChange"
                @cell-mouse-enter="onCellMouseEnter"
                @cell-mouse-leave="onCellMouseLeave"
                @cell-click="onCellClick"
                @cell-dblclick="onCellDbClick"
                @row-contextmenu="onRowContextmenu"
                @row-dblclick="onRowDbClick"
                @header-click="onHeaderClick"
                @sort-change="onSortChange"
                @filter-change="onFilterChange"
                @current-change="onCurrentChange"
                @header-dragend="onHeaderDragend"
                @expand="onExpand"
            >
                <el-table-column
                    v-for="item in columns"
                    :type="item.type"
                    :column-key="item.columnKey"
                    :min-width="item.minWidth"
                    :fixed="item.fixed"
                    :render-header="item.renderHeader"
                    :sortable="item.sortable"
                    :sort-method="item.sortMethod"
                    :resizable="item.resizable"
                    :formatter="item.formatter"
                    :show-overflow-tooltip="item.showOverFlowTooltip"
                    :align="item.align"
                    :header-align="item.headerAlign"
                    :class-name="item.className"
                    :selectable="item.selectable"
                    :reserve-selection="item.reserveSelection"
                    :filters="item.filters"
                    :filter-multiple="item.filterMultiple"
                    :filter-method="item.filterMethod"
                    :filtered-value="item.filteredValue"
                    :prop="item.prop"
                    :label="item.label"
                    :width="item.width"
                >
                </el-table-column>
            </el-table>
        </div>
        <!--分页栏-->
        <div class="pagenav-container">
            <t8t-el-pagination
                @current-change="handleCurrentPageChange"
                @size-change="handleSizeChange"
                :current-page="currentPage"
                :total="totalPages"
                :page-sizes="[5,10,20,30,50]"
                layout="sizes, first, prev, jumper, next, last, refresh, ->, total"
                :page-size="pageSize"
            >
            </t8t-el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: 't8t-base-table',
        props: {
            columns: Array,
            dataSource: Array,
            height: Number,
            stripe: Boolean,
            border: {
                type: Boolean,
                default: true
            },
            fit: {
                type: Boolean,
                default: true
            },
            "showHeader": {
                type: Boolean,
                default: true
            },
            "highlightCurrentRow": {
                type: Boolean,
                default: false
            },
            "currentRowKey": [String, Number],
            "rowClassName": [String, Function],
            "rowStyle": [Object, Function],
            "rowKey": [Function, String],
            "emptyText": {
                type: String,
                default: "暂无数据"
            },
            "defaultExpandAll": {
                type: Boolean,
                default: false
            },
            "expandRowKeys": Array,
            "defaultSort": Object
        },
        data() {
            return {

            }
        },
        methods: {
            onSelect(selection, row) {
                this.$emit('select', selection, row)
            },
            onSelectAll(selection) {
                this.$emit('selectAll', selection)
            },
            onSeletionChange(selection) {
                this.$emit('selectionChange', selection)
            },
            onCellMouseEnter(row, column, cell, event) {
                this.$emit('cellMouseEnter', row, column, cell, event)
            },
            onCellMouseLeave(row, column, cell, event) {
                this.$emit('cellMouseLeave', row, column, cell, event)
            },
            onRowClick(row, event, column) {
                this.$emit('rowClick', row, event, column)
            },
            onCellClick(ow, column, cell, event) {
                this.$emit('CellClick', row, event, column)
            },
            onCellDbClick(row, column, cell, event) {
                this.$emit('cellDbClick', row, column, cell, event)
            },
            onRowContextmenu(row, event) {
                this.$emit('rowContextmenu', row, event)
            },
            onRowDbClick(row, event) {
                this.$emit('rowDbClick', row, event)
            },
            onHeaderClick(column, event) {
                this.$emit('headerClick', column, event)
            },
            onSortChange(event) {
                this.$emit('sortChange', event)
            },
            onFilterChange(filters) {
                this.$emit('filterChange', filters)
            },
            onCurrentChange(currentRow, oldCurrentRow) {
                this.$emit('currentChange', currentRow, oldCurrentRow)
            },
            onHeaderDragend(newWidth, oldWidth, column, event) {
                this.$emit('headerDragend', newWidth, oldWidth, column, event)
            },
            onExpand(row, expanded) {
                this.$emit('expand', row, expanded)
            }
        }
    }

</script>

<style
    lang="css"
    scoped
>
    .t8t-table .el-form {
        height: 100%
    }
    
    .t8t-table .pagenav-container {
        padding: 11px;
        background: rgba(245, 245, 250, 1);
        border-top: 1px solid #D3DDE6;
        margin-top: -1px;
    }
    
    .t8t-table .table-container .el-form-item {
        margin-bottom: 0px;
    }
    
    .t8t-table .el-button--toolbar:first-child {
        margin-left: 8px;
    }
    
    .t8t-table .el-button--toolbar {
        padding: 5px 11px;
        font-size: 12px;
        border-radius: 2px;
        border-color: rgb(232, 237, 241);
        color: rgb(50, 139, 239);
        margin-right: 5px;
    }
    
    .t8t-table .el-button--toolbar:focus {
        border-color: rgb(191, 201, 217)
    }
    
    .t8t-table .el-button--toolbar:hover {
        border-color: rgb(50, 139, 239)
    }
    
    .t8t-table .el-button--success.is-plain {
        color: rgb(19, 206, 102)
    }
    
    .t8t-table .el-button--danger.is-plain {
        color: rgb(255, 86, 97)
    }
    
    .t8t-table .el-button + .el-button {
        margin-left: 0px;
    }
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    /*此处样式有冲突，暂时强制显示，还需优化*/
    
    .t8t-table .el-pagination .btn-next,
    .t8t-table .el-pagination .btn-prev,
    .t8t-table .el-pagination .btn-first,
    .t8t-table .el-pagination .btn-last,
    .t8t-table .el-pagination .btn-refresh {
        border: none !important;
        background: transparent !important;
        color: #3296FA !important;
        cursor: pointer;
    }
    
    .t8t-table .btn-refresh {
        margin-left: 20px !important;
    }
    
    .t8t-table .el-pagination {
        padding: 0px !important;
    }
    
    .t8t-table .el-pagination button.disabled {
        border: none !important;
        color: #97a8be !important;
    }
    
    .t8t-table .table-container .cell {
        padding: 4px 10px !important;
        border-color: rgb(212, 220, 230) !important;
        /*这两行会使内嵌表单错位*/
        /*height: 40px;
        line-height: 32px;*/
    }
    
    .el-table {
        color: #666 !important;
        font-size: 12px !important;
        border-color: rgb(212, 220, 231)!important;
    }
    
    .t8t-table .el-checkbox__inner {
        border-color: rgb(142, 143, 143) !important;
        transition: none !important;
    }
    
    .t8t-table .el-checkbox__input.is-checked .el-checkbox__inner {
        border-color: rgb(50, 150, 250) !important;
    }
    
    .t8t-table .el-checkbox__input.is-disabled .el-checkbox__inner {
        border-color: rgb(209, 217, 229) !important;
    }
    
    .t8t-table .t8t-table .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner {
        background-color: rgb(209, 217, 229) !important;
        border-color: rgb(209, 217, 229) !important;
    }
    
    .t8t-table .el-checkbox__inner::after {
        border-color: rgb(50, 150, 250) !important;
        transition: none !important;
    }
    
    .t8t-table .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner::after {
        border-color: #fff !important;
    }
    
    .t8t-table .el-table td {
        border-color: rgb(226, 223, 239) !important;
    }
    
    .t8t-table .el-table td .cell {
        user-select: none;
        cursor: default;
    }
    
    .t8t-table .el-table th {
        border-color: rgb(226, 223, 239) !important;
    }
    
    .t8t-table .el-table th .cell {
        user-select: none;
        cursor: pointer;
    }
    
    .t8t-table .el-table th,
    .t8t-table .el-table th .cell {
        background-color: rgba(245, 245, 250, 1) !important;
    }
    
    .t8t-table .selected-row {
        background-color: rgba(243, 246, 255, 1) !important;
    }
    
    .t8t-table .el-table--striped .el-table__body tr:nth-child(2n).selected-row td {
        background-color: rgba(243, 246, 255, 1)
    }
    
    .t8t-table .el-table--striped .el-table__body tr:nth-child(2n).current-row td {
        background-color: rgba(243, 246, 255, 1)
    }
    
    .t8t-table .el-table__body tr.hover-row>td {
        background-color: rgba(235, 240, 255, 1) !important;
    }
    
    .t8t-table .el-table--enable-row-hover tr:hover>td {
        background-color: rgba(235, 240, 255, 1) !important;
    }
    
    .t8t-table .el-table--enable-row-transition .el-table__body td {
        transition: none !important;
    }
    
    .t8t-table .el-button.is-disabled,
    .t8t-table .el-button.is-disabled:hover,
    .t8t-table .el-button.is-disabled:focus {
        background-color: rgb(250, 250, 250) !important
    }
    
    .t8t-table .el-input__inner {
        font-size: 12px !important;
    }
    
    .t8t-table .el-pagination .el-select .el-input {
        width: 60px !important;
    }
    /*分页器按钮*/
    
    .t8t-table .nav-icon {
        display: block;
        width: 16px;
        height: 16px;
        background-position-y: 0px;
        background-image: url(./images/page-arrow.png);
    }
    
    .t8t-table button.disabled .nav-icon {
        background-position-y: -16px;
    }
    
    .t8t-table .icon-first {
        background-position-x: 0px;
    }
    
    .t8t-table .icon-prev {
        background-position-x: -25px;
    }
    
    .t8t-table .icon-next {
        background-position-x: -50px;
    }
    
    .t8t-table .icon-last {
        background-position-x: -75px;
    }
    
    .t8t-table .icon-refresh {
        background-position-x: -105px;
    }
    /*pageBtn end*/
    
    .t8t-table .el-pagination__jump {
        margin-left: 0px !important;
    }
    
    .t8t-table .el-pagination__jump input {
        font-size: 12px;
    }
    
    .t8t-table .el-pagination__jump input:disabled {
        background-color: rgb(238, 241, 246);
        color: #bbb;
    }
    
    .t8t-table .el-pagination span,
    .t8t-table .el-pagination button {
        font-size: 12px !important;
    }
    
    .t8t-table .required-tag {
        color: rgb(255, 73, 74);
        font-family: sans-serif;
    }
    
    .t8t-table .el-table__fixed,
    .t8t-table .el-table__fixed-right {
        /*box-shadow: 1px -2px 10px rgb(233, 233, 238) !important;*/
        box-shadow: none!important;
    }
    
    .t8t-table .el-loading-mask {
        z-index: 1000!important;
    }
    
    .t8t-table .el-select .el-input .el-input__icon {
        color: rgb(31, 48, 69)!important;
        transform: translateY(-50%) rotateZ(180deg) scaleX(0.8)!important;
    }
    
    .el-select .el-input .el-input__icon.is-reverse {
        transform: translateY(-50%) scaleX(0.8)!important;
    }
    
    .el-table .caret-wrapper {
        display: none !important;
    }
    
    .el-table .ascending .caret-wrapper {
        display: inline-block !important;
    }
    
    .el-table .descending .caret-wrapper {
        display: inline-block !important;
    }
    
    .el-table .sort-caret.descending {
        display: none;
    }
    
    .el-table .sort-caret.ascending {
        display: none;
    }
    
    .el-table .ascending .sort-caret.ascending {
        display: block;
        top: 15px;
        border-bottom: 5px solid #48576a!important;
    }
    
    .el-table .descending .sort-caret.descending {
        display: block;
        bottom: 15px;
        border-top: 5px solid #48576a!important;
    }
    /* 低版本 */
    
    .chrome_lower .t8t-table .table-container {
        position: relative;
        min-height: 100%;
    }
    
    .chrome_lower .t8t-table .table-container .el-table {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
</style>