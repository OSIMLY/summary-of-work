<template>
    <transition name="fade">
        <div :style="{top:menuTop+'px',left:menuLeft+'px'}"
             v-clickoutside="handleOutsideClick"
             v-show="menuVisible"
             class="ctx-menu-content"
             @contextmenu.prevent>
            <slot></slot>
        </div>
    </transition>
</template>

<script>
import Clickoutside from '../utils/clickoutside.js'
export default {
    name: 'CtxMenu',
    directives: {
        Clickoutside
    },
    props: {
        menuVisible: {
            type: Boolean,
            default: false
        },
        menuTop: Number,
        menuLeft: Number
    },
    methods: {
        openMenu(event) {
            debugger
            event.preventDefault()
            event.stopPropagation()
            this.setPositionFromEvent(event)
            this.$nextTick(function () {
                this.menuVisible = true
            })
        },
        closeMenu() {
            this.menuVisible = false
        },
        itemClick(item) {
            console.log(item)
            this.$emit('menuClick', item.action)
            this.closeMenu()
        },
        handleOutsideClick(event) {
            this.closeMenu()
        },
        setPositionFromEvent(event) {
            const { pageX, pageY } = event
            this.menuTop = pageY - (document.body.scrollTop)
            this.menuLeft = pageX
        }
    }
}

</script>

<style>
.ctx-menu {
    user-select: none;
}

.ctx-menu-content {
    position: fixed;
    z-index: 5000;
    padding: 10px;
    overflow: hidden;
    background-color: #fff;
    border-radius: 3px;
    user-select: none;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.ctx-menu-content .el-checkbox {
    display: block;
    margin-bottom: 8px;
    margin-left: 5px;
}

.fade-enter {
    opacity: 0
}

.fade-enter-active {
    transition: opacity .2s
}
</style>