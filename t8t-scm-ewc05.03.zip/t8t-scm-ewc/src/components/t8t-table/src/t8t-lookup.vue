<template>
    <div class="t8t-lookup">
        <el-popover1 ref="popover"
                    placement="bottom"
                    :width="size==='small'?530:660"
                    trigger="click"
                    v-model="popoverVisible">
            <div class="lookup-container"
                 :class="{small:size==='small'}">
                <div class="search-box">
                    <slot name="searchEditor">
                        <el-input ref="searcher"
                                  placeholder="请输入搜索内容"
                                  v-model="searchVal"
                                  @input="handleSearch()"
                                  @keyup.enter.native="handleSearch()">
                            <template slot="icon">
                                <i class="el-input__icon"
                                   :class="['el-icon-circle-close',onIconClick ? 'is-clickable' : '']"
                                   @click="handleClear()">
                                                    </i>
                                <i class="el-input__icon"
                                   :class="['el-icon-search',onIconClick ? 'is-clickable' : '']"
                                   @click="handleSearch()">
                                                    </i>
                            </template>
                        </el-input>
                    </slot>
                </div>
                <div class="table-box">
                    <t8t-table ref="table"
                               :radioCol="!multiple"
                               :selectCol="multiple"
                               :dataSource="dataSource"
                               :service="service"
                               :method="method"
                               :columns="columns"
                               :args="currentArgs"
                               :row-key="getRowKeys"
                               :current-row-key="currentValue"
                               :reserve-selection="true"
                               @current-row-change="handleCurrentRowChange"
                               @selection-change="handleSelectionChange"
                               @row-double-click="handleRowDoubleClick">
                    </t8t-table>
                </div>
                <div class="toolbar-box"
                     v-if="showToolbar()">
                    <el-button type="primary"
                               size="small"
                               :disabled="btnOkDisabled"
                               @click="handleBtnOKClick()">
                        确定
                    </el-button>
                    <el-button type="toolbar"
                               size="small"
                               @click="handleBtnCancleClick()">
                        取消
                    </el-button>
                </div>
            </div>
        </el-popover1>
        <el-input v-model="currentValue"
                  ref="mainInput"
                  v-popover:popover
                  :placeholder="placeholder"
                  :disabled="disabled"
                  :readonly="readonly">
        </el-input>
    </div>
</template>

<script>
import ElPopover1 from 'src/components/element-ui/lib/popover'
import T8tTable from '../t8t-table.vue'
export default {
    name: 't8t-lookup',
    created() {
    },
    components:{ElPopover1},
    mounted() {
        this.currentRowKey = this.currentValue
    },
    data() {
        return {
            currentValue: this.value,
            currentArgs: this.args,
            searchVal: null,
            popoverVisible: false,
            currentRow: null,
            selection: [],
            btnOkDisabled: true,
            currentRowKey: null
        }
    },
    props: {
        value: [String, Number],
        placeholder: String,
        disabled: Boolean,
        readonly: {
            type: Boolean,
            default: true
        },
        size: {
            type: String,
            default: 'large'
        },
        dataSource: Array,
        service: String,
        method: String,
        columns: {
            type: Array,
            default() {
                return [{
                    prop: 'id',
                    label: '编号'
                }, {
                    prop: 'Name',
                    label: '名称'
                }]
            }
        },
        searchExpr: Array,
        valueExpr: {
            type: String,
            default: ''
        },
        args: {
            type: Object,
            default() {
                return {}
            }
        },
        multiple: Boolean,
        toolbar: Boolean,
        filterMethod: Function
    },
    computed: {

    },
    watch: {
        value(val) {
            this.currentValue = val
        },
        args(val) {
            this.currentArgs = val
            this.$refs.table.reloadTable()
        },
        currentValue(val) {
            this.$emit('input', val)
            this.$emit('change', val)
        },
        currentRow(val) {
            if (val === null) {
                this.btnOkDisabled = true
            } else {
                this.btnOkDisabled = false
            }
        },
        selection(val) {
            if (val.length === 0) {
                this.btnOkDisabled = true
            } else {
                this.btnOkDisabled = false
            }
        }
    },
    methods: {
        getRowKeys(row) {
            return row[this.valueExpr]
        },
        focus() {
            this.$refs.mainInput.$refs.input.click()
            this.$nextTick(function () {
                this.$refs.searcher.$refs.input.focus()
            })
        },
        showToolbar() {
            if (typeof this.toolbar === 'undefined') {
                return this.multiple
            } else {
                return this.toolbar
            }
        },
        handleClear() {
            this.searchVal = ''
            this.handleSearch()
        },
        handleSearch() {
            if (typeof this.filterMethod === 'function') {
                this.currentArgs = this.filterMethod(this.searchVal, this.currentArgs)
                this.$refs.table.reloadTable()
            } else {
                if (typeof this.searchExpr !== 'undefined') {
                    let search = {}
                    this.searchExpr.forEach((item) => {
                        search[item + '_like'] = this.searchVal
                    })
                    this.currentArgs.search = search
                    this.$refs.table.reloadTable()
                }
            }
        },
        setCurrentValue() {
            if (this.multiple) {
                if (this.valueExpr === '') {
                    this.currentValue = this.selection
                } else {
                    this.currentValue = this.selection.map((item) => {
                        return item[this.valueExpr]
                    })
                }
            } else {
                if (this.valueExpr === '') {
                    this.currentValue = this.currentRow
                } else {
                    this.currentValue = this.currentRow[this.valueExpr]
                }
            }
        },
        handleRowDoubleClick(row) {
            this.setCurrentValue()
            this.popoverVisible = false;
        },
        handleCurrentRowChange(row) {
            this.currentRow = row
        },
        handleSelectionChange(selection) {
            this.selection = selection
        },
        handleBtnOKClick() {
            this.setCurrentValue()
            this.popoverVisible = false;
        },
        handleBtnCancleClick() {
            this.popoverVisible = false;
        }
    }
}

</script>

<style scoped>
.lookup-container {
    display: flex;
    flex-direction: column;
    height: 400px;
}

.lookup-container.small {
    height: 320px;
}

.search-box {
    flex: content;
    margin-bottom: 10px;
}

.table-box {
    display: flex;
    flex: 1;
}
</style>
<style>
.lookup-container .t8t-table {
    width: 100%
}

.lookup-container .table-box th {
    height: 36px;
}

.lookup-container .table-box td {
    height: 36px;
}

.lookup-container .table-box .el-table tr td div.cell {
    height: 36px;
    line-height: 36px;
}

.lookup-container .table-box .t8t-table-container .table-container .el-table tr td div.cell {
    height: 36px;
    line-height: 36px;
}

.lookup-container .table-box .pagenav-container {
    padding: 3px 0;
}

.lookup-container.small .table-box .pagenav-container .el-pagination__jump {
    display: none
}

.lookup-container.small .table-box .pagenav-container .btn-refresh {
    margin-left: 0
}

.lookup-container .table-box .pagenav-container .el-pagination {
    padding: 0 3px;
}

.lookup-container .toolbar-box {
    display: flex;
    justify-content: center;
    margin-top: 10px;
}

.lookup-container .toolbar-box .el-button {
    padding: 7px 25px;
}

.lookup-container .toolbar-box .el-button+.el-button {
    margin-left: 10px;
}

.lookup-container .search-box .el-input__icon+.el-input__inner {
    padding-right: 60px;
}

.lookup-container .search-box .el-input__icon {
    cursor: pointer;
}

.lookup-container .search-box .el-icon-circle-close {
    width: 20px;
    right: 30px;
    color: #c1c2c3;
}

.lookup-container .search-box .el-icon-circle-close:hover {
    color: #d7d8d9;
}

.lookup-container .search-box .el-icon-search {
    width: 30px;
}

.lookup-container .search-box .el-icon-search::before {
    color: #6b6b6b;
}

.lookup-container .search-box .el-icon-search:hover::before {
    color: #3197FC;
}
</style>
