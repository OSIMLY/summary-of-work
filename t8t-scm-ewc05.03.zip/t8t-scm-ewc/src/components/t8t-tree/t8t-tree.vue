<template>
    <div
        class="t8t-tree-container"
        :class="{ 'is-hide': isHide }"
    >
        <div class="t8t-tree">
            <div class="tree-header">
                <slot name="tree-header"></slot>
            </div>
            <div class="main-container">
                <div class="tree-select">
                    <input
                        v-model.trim="queryString"
                        class="tree-input"
                        placeholder="搜索"/>
                    <i class="search-icon"></i>
                </div>
                <div class="tree-outer">
                    <el-tree
                        ref="treeRef"
                        :data="data"
                        :props="props"
                        :default-expanded-keys="defaultExpandedKeys"
                        :show-checkbox="showCheckbox"
                        :node-key="nodeKey"
                        @node-click="onClick"
                        @check-change="onChange"
                        emptyText="暂无数据"
                        highlight-current
                        :expand-on-click-node="false"
                        :filter-node-method="filterData"
                    ></el-tree>
                </div>
            </div>
        </div>
        <div
            class="tree-hide el-icon-d-arrow-left"
            @click="onHide"
            :class="{'el-icon-d-arrow-right': isHide, hide: hideArrow}"
        ></div>
    </div>
</template>
<script>
    import {debounce} from 'lodash'
    export default {
        name: 't8t-tree',
        props: {
            data: {
                type: Array,
                default() {
                    return []
                },
                required: true
            },
            props: {
                type: Object,
                default() {
                    return {
                        label: 'label',
                        children: 'children',
                        disabled: 'disabled',
                        symbol: 'symbol'
                    }
                },
                required: true
            },
            nodeKey: {
                type: String,
                default: 'id',
                required: false
            },
            defaultExpandedKeys: {
                type: Array,
                default() {
                    return []
                },
                required: false
            },
            showCheckbox: {
                type: Boolean,
                default: false,
            },
            hideArrow: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                queryString: '',
                isHide: false
            }
        },
        watch: {
            queryString: function (qs) {
                this.debounceData(qs)
            }
        },
        methods: {
            debounceData: debounce(
                function(qs) {
                    this.$refs['treeRef'].filter(qs)
                },
                250
            ),
            onHide() {
                this.isHide = !this.isHide
            },
            filterData(value, data, node) {
                var item = data[this.props.label].toLowerCase()
                var qs = value.toLowerCase()
                if (!value) return true
                if (item.indexOf(qs) > -1) {
                    return true
                }
            },
            onClick(data, node, component) {
                // 禁用节点直接返回
                if(node.disabled)return
                this.$emit('node-click', data, node, component)
            },
            onChange(data, checked, indeterminate){
                this.$emit('check-change', data, checked, indeterminate)
            }
        }
    }

</script>

<style
    lang="css"
    scoped
>
    .t8t-tree-container {
        width: 300px;
        position: relative;
        transition: all 0.3s;
        -webkit-user-select: none;
        border: 1px solid #d4dce7;
    }
    .t8t-tree-container .hide{
        display: none;
    }
    .t8t-tree-container.is-hide {
        width: 0;
        border: 1px solid #fff;
    }

    .t8t-tree-container .tree-hide {
        position: absolute;
        top: 14px;
        right: 0;
        transform: translate3d(100%, 0, 0);
        cursor: pointer;
        font-size: 12px;
        color: #666;
        padding: 5px;
    }

    .t8t-tree {
        position: absolute;
        overflow: hidden;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        flex-direction: column;
    }

    .t8t-tree .tree-select {
        padding: 9px;
        border-bottom: 1px solid #d4dce7;
        position: relative;
    }

    .t8t-tree .tree-outer {
        position: absolute;
        top: 49px;
        left: 0;
        right: 0;
        bottom: 0;
        overflow: auto;
    }
    .t8t-tree .tree-input{
        bottom: 1px solid;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-color: #fff;
        background-image: none;
        border-radius: 2px;
        border: 1px solid #bfcbd9;
        box-sizing: border-box;
        color: #1f2d3d;
        display: block;
        font-size: 12px;
        height: 30px;
        line-height: 1;
        outline: 0;
        padding: 3px 10px;
        transition: border-color .2s cubic-bezier(.645,.045,.355,1);
        width: 100%;
    }
    .t8t-tree .tree-input:focus{
        border-color: #20a0ff;
    }
    .t8t-tree .tree-input:hover {
        border-color: #8391a5;
    }
    .search-icon{
        position: absolute;
        width: 20px;
        height: 100%;
        right: 15px;
        top: 0;
        text-align: center;
        color: #bfcbd9;
        transition: all .3s;
        font-family: element-icons!important;
        speak: none;
        font-style: normal;
        font-weight: 400;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        vertical-align: baseline;
        display: inline-block;
        -webkit-font-smoothing: antialiased;
    }
    .search-icon:before{
        content: "\E61D";
        color: #23334c;
        font-size: 16px;
        margin-top: 16px;
        display: block;
    }
    .t8t-tree .tree-top{
        height: 49px;
        border-bottom: 1px solid #d4dce7;
    }
    .main-container{
        flex: 1;
        position: relative;
    }
    .tree-header{
        width: 300px;
    }
</style>
<!-- 样式尽量写上边, 必要时写下边 -->
<style lang="css">
    .t8t-tree .el-tree{
        border: none;
    }
    .t8t-tree .el-tree-node{
        line-height: 0px;
    }
    .t8t-tree .el-tree-node>.el-tree-node__children{
        overflow: visible;
    }
    .t8t-tree .el-input__inner {
        height: 30px;
        font-size: 12px;
    }

    .t8t-tree .el-tree-node__label {
        font-size: 12px;
    }

    .t8t-tree .tree-select {
        font-size: 12px;
    }

    .t8t-tree .el-tree-node__content {
        height: 25px;
        line-height: 25px;
        display: inline-flex;
        align-items: center;
    }

    .t8t-tree .el-checkbox__input {
        margin-top: -3px;
    }
</style>

<style>

    .t8t-tree .el-tree .erp-tree-icon {
        display: inline-block;
        width: 13px;
        margin: 0px 8px 0;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .el-tree .el-checkbox {
        margin-right: 8px;
    }

    .t8t-tree .erp-tree-plus {
        width: 13px;
        height: 13px;
        margin: 0px 8px 0;
        background-image: url(./img/icon01.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-minus {
        width: 13px;
        height: 13px;
        margin: 0px 8px 0;
        background-image: url(./img/icon02.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-folder {
        display: inline-block;
        width: 15px;
        height: 13px;
        margin: 0px 8px 0 0;
        background-image: url(./img/icon03.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-folder-open {
        display: inline-block;
        width: 15px;
        height: 13px;
        margin: 0px 8px 0 0;
        background-image: url(./img/icon04.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-leaf {
        display: inline-block;
        width: 11px;
        height: 15px;
        margin: 1px 10px 0 2px;
        background-image: url(./img/icon05.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .erp-tree-checked {
        display: inline-block;
        width: 11px;
        height: 15px;
        margin: 1px 10px 0 2px;
        background-image: url(./img/icon06.png);
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .t8t-tree .el-tree-node.is-disabled>.el-tree-node__content {
        cursor: not-allowed!important;
    }
    .t8t-tree .el-tree-node.is-disabled>.el-tree-node__content .el-tree-node__label {
        color: rgb(220, 220, 220)!important;
    }

    .t8t-tree .el-tree-node.is-disabled>.el-tree-node__content  .erp-tree-leaf,
    .t8t-tree .el-tree-node.is-disabled>.el-tree-node__content  .erp-tree-checked {
        background-image: url(./img/icon07.png)!important;
    }

    .t8t-tree .el-tree-node__content:hover {
        background: #fff;
        color: #3396fb;
    }

    .t8t-tree .el-tree-node__content:hover .erp-tree-leaf {
        background-image: url(./img/icon06.png);
    }

    .t8t-tree .erp-tree-highlight {
        color: #3396fb;
    }
    .t8t-tree .is-current>.el-tree-node__content .erp-tree-leaf{
        background-image: url(./img/icon06.png);
    }
    .t8t-tree .el-tree-node.is-current>.el-tree-node__content .el-tree-node__label{
        color: #3396fb;
    }
    .t8t-tree .el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content{
        background-color: #fff;
    }
</style>
