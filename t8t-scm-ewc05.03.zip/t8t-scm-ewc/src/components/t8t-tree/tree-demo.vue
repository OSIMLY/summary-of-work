<template>
    <div class="g-main-container">
        <t8t-tree
            class="my-treeName"
            :data="treeData"
            :props="treeProps"
            :show-checkbox="true"
            :default-expanded-keys="defaultExpandedKeys"
            @node-click="onTreeClick"
        >
          <div slot="tree-header">
            <el-button>1223</el-button>
            <el-button>1223</el-button>
            <el-button>1223</el-button>
            <el-button>1223</el-button>
            <el-button>1223</el-button>
          </div>
        </t8t-tree>
    </div>
</template>

<script>
    import api from 'src/utils/api'
    export default {
        data() {
            return {
                defaultActive: '1-1',
                treeData: [],
                treeProps: {
                  label: 'name',
                  children: 'children',
                  disabled: 'isDel',
                  symbol: 'name'
                },
                defaultExpandedKeys: [1]
            }
        },
        methods: {
            onTreeClick(data, node, component) {
                console.log(data, node, component)
                node.expanded = !node.expanded
            }
        },
        created(){
          api.organization.queryTree()
              .then((res) => {
                  if (res.data.status === 200) {
                      this.treeData = [res.data.result]
                  }
              });
        }
    }

</script>

<style lang="css">
  .my-treeName [symbol="深圳市彬讯科技有限公司"]{
    color: red
  }
  .my-treeName [symbol="综合管理"]{
    color: blue
  }
</style>
