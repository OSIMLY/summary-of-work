<template>
    <div class="t8t-form-autocomplete">
        <el-autocomplete
            v-model="value"
            :placeholder="placeholder"
            :disabled="disabled"
            :custom-item="customItem"
            :fetch-suggestions="fetchSuggestions?fetchSuggestions:(remote?querySearchAsync:querySearch)"
            :popper-class="popperClass"
            :trigger-on-focus="triggerOnFocus"
            :on-icon-click="onIconClick"
            :icon="icon"
            @select="onSelect"
        >
        </el-autocomplete>
    </div>
</template>

<script>
import axios from 'src/utils/axios'
    export default {
        name: 't8t-form-autocomplete',
        data () {
            return {
                value: ''
            }
        },
        props: {
            bindValue: [Number, String],
            defaultValue: [Number, String],
            name: String,
            placeholder: {
                type: String,
                default: ''
            },
            disabled: Boolean,
            customItem: String,
            fetchSuggestions: Function,
            popperClass: String,
            triggerOnFocus: Boolean,
            onIconClick: Function,
            icon: String,
            options: {
                type: Array,
                default: []
            },
            remote: {
                type: Boolean,
                default: false
            },
            service: String,
            method: String,
            remoteArgs: {
                type:Object,
                default: {}
            },
            remoteQueryKey: String
        },
        watch: {
            bindValue: function (val,oldVal) {
                this.value = val;
            },
            value: function() {
                this.$emit('change',this.value,this.name)
            }
        },
        created () {
            this._init()
        },
        methods: {
            _init: function() {
                if (this.defaultValue) {
                    this.value = this.defaultValue
                }
                else {
                    this.value = this.bindValue;
                }
            },
            onSelect: function(value) {
                this.$emit('select',value.value,this.name)
            },
            querySearch(queryString, cb) {
                var list = this.options
                var results = queryString ? list.filter(this.createFilter(queryString)) : list;
                // 调用 callback 返回建议列表的数据
                cb(results);
            },
            createFilter(queryString) {
                return (state) => {
                  return (state.value.indexOf(queryString.toLowerCase()) === 0);
                };
            },
            querySearchAsync(queryString, cb) {
                if (queryString !== '') {
                    if (this.service && this.method) {
                        if (this.remoteQueryKey) {
                            this.remoteArgs[this.remoteQueryKey] = queryString
                        };
                        this.loading = true
                        axios({
                            service: this.service,
                            method: this.method,
                            args: this.remoteArgs
                        })
                        .then((res) => {
                            this.loading = false
                            let response = res.data
                            if (response.status == 200) {
                                let result = response.result.rows
                                cb(result)
                            }

                        })
                        .catch((res) => {
                            // TODO 数据加载失败
                            this.loading = false
                            this.$message.error('数据加载失败')
                        })
                    } else {
                        // TODO 没有传service和method参数处理
                    }
               } else {
                     cb([]);
                }
            }
        }
    }
</script>

<style lang="css" scoped>

</style>
