<template>
    <div class="t8t-form-select">
        <el-select
            v-model="value"
            :placeholder="placeholder"
            :filterable="filterable"
            :multiple="multiple"
            :disabled="disabled"
            :size="size"
            :clearable="clearable"
            :multiple-limit="multipleLimit"
            :allow-create="allowCreate"
            :filter-method="filterMethod"
            :remote="remote"
            :remote-method="remoteMethod?remoteMethod:queryRemote"
            :loading="loading"
            :loading-text="loadingText"
            :no-match-text="noMatchText"
            :no-data-text="noDataText"
            :popper-class="popperClass"
            :name="name"
            @change="onChange"
            @visible-change="onVisibleChange"
            >
            <el-option-group
                v-if="isGroup"
                v-for="group in options"
                :disabled="group.disabled"
                :label="group.label">
              <el-option
                v-for="item in group.options"
                :key="remote?item.value:null"
                :label="item.text"
                :value="item.value"
                :disabled="item.disabled">
              </el-option>
            </el-option-group>
            <el-option
                v-if="!isGroup"
                v-for="p in options"
                :key="remote?item.value:null"
                :label="p.text"
                :value="p.value"
                :disabled="p.disabled">
            </el-option>
        </el-select>
    </div>
</template>

<script>
import axios from 'src/utils/axios'
    export default {
        name: 't8t-form-select',
        data () {
            return {
                value: ''
            }
        },
        props: {
            bindValue: [Number, String],
            defaultValue: [Number, String],
            name: String,
            placeholder: {
                type: String,
                default: '--请选择--'
            },
            size: String,
            filterable: Boolean,
            multiple: Boolean,
            clearable:{
                type:Boolean,
                default: true
            },
            multipleLimit:Number,
            disabled: Boolean,
            options: Array,
            allowCreate: Boolean,
            filterMethod: Function,
            remote: Boolean,
            remoteMethod: Function,
            service: String,
            method: String,
            remoteArgs: {
                type:Object,
                default: {}
            },
            remoteQueryKey: String,
            loading: Boolean,
            loadingText: String,
            noMatchText: String,
            noDataText: String,
            popperClass:String,
            isGroup: {
                type:Boolean,
                default: false
            }
        },
        created () {
            this._init()
        },
        watch: {
            bindValue: function () {
                this.value = this.bindValue;
            }
        },
        methods: {
            _init: function() {
                if (this.defaultValue!==undefined) {
                    this.value = this.defaultValue
                }
                else {
                    this.value = this.bindValue;
                }
            },
            onChange: function(value) {
                this.$emit('change', value,this.name)
            },
            onVisibleChange: function(value) {
                this.$emit('visible-change', value,this.name)
            },
            queryRemote: function(query) {
                if (query !== '') {
                    if (this.service && this.method) {
                        if (this.remoteQueryKey) {
                            this.remoteArgs[this.remoteQueryKey] = query
                        };
                        this.loading = true
                        axios({
                            service: this.service,
                            method: this.method,
                            args: this.remoteArgs
                        })
                        .then((res) => {
                            this.loading = false
                            let response = res.data
                            if (response.status == 200) {
                                this.options = response.result.rows
                            }

                        })
                        .catch((res) => {
                            // TODO 数据加载失败
                            this.loading = false
                            this.$message.error('数据加载失败')
                        })
                    } else {
                        // TODO 没有传service和method参数处理
                    }
               } else {
                     this.options = [];
                }
            }
        }
    }
</script>

<style lang="css" scoped>

</style>
