<template>
    <div class="t8t-form-date-picker">
        <el-date-picker
             v-model="value"
             :name="name"
             :placeholder="placeholder"
             :readonly="readonly"
             :disabled="disabled"
             :editable="editable"
             :clearable="clearable"
             :size="size"
             :type="pickertype"
             :format="format"
             :align="align"
             :popper-class="popperClass"
             :picker-options="pickerOptions"
             :range-separator="rangeSeparator"
             @change="onChange"
        >
        </el-date-picker>
    </div>
</template>

<script>
    export default {
        name: 't8t-form-date-picker',
        data () {
            return {
                value: ''
            }
        },
        props: {
            bindValue: [String],
            name: String,
            placeholder: {
                type: String,
                default: ''
            },
            size: String,
            readonly: Boolean,
            disabled: Boolean,
            editable: Boolean,
            clearable: Boolean,
            size: String,
            pickertype: String,
            format: String,
            align: String,
            popperClass: String,
            pickerOptions: Object,
            rangeSeparator: String,
            startField: String,
            endField: String
        },
        created() {
            this.value = this.bindValue
        },
        watch: {
            value: function(val,oldVal){
                this.$emit('change',val,this.name)
            },
            bindValue: function (val,oldVal) {
                this.value = val;
            }
        },
        methods: {
            onChange: function(val){
                let value = this.value
                if (this.pickertype==='datetimerange'&&value) {
                    var valStart=null;
                    var valEnd=null;
                    if (value[0]&&value[1]) {
                        valStart = value[0].getTime()/1000;
                        valEnd = value[1].getTime()/1000;

                        if (valStart>valEnd) {
                            this.value = ''
                        };
                    };
                };
            }
        }
    }
</script>

<style lang="css" scoped>

</style>
