<template>
    <div class="t8t-form-input">
        <el-input
            v-model="value"
            :placeholder="placeholder"
            :type="inputType"
            :maxlength="maxlength"
            :minlength="minlength"
            :disabled="disabled"
            :size="size"
            :icon="icon"
            :rows="rows"
            :autosize="autosize"
            :auto-complete="autoComplete"
            :name="name"
            :readonly="readonly"
            :max="max"
            :min="min"
            :step="step"
            :resize="resize"
            :autofocus="autofocus"
            :form="form"
            :on-icon-click="onIconClick"
            @click="onClick"
            @blur="onBlur"
            @focus="onFocus"
            @change="onChange"
        >
            <template v-if="slotType==='text'" :slot="slotPosition">{{slotTemplate}}</template>
            <el-select
            v-if="slotType==='select'"
            class="select"
            v-model="select"
            :slot="slotPosition"
            :slotPlaceholder="slotPlaceholder"
            @change="onChangeSlot">
                <el-option
                    v-for="p in slotOptions"
                    :label="p.text"
                    :value="p.value">
                </el-option>
            </el-select>
        </el-input>
    </div>
</template>

<script>
    export default {
        name: 't8t-form-input',
        data () {
            return {
                value: '',
                select: ''
            }
        },
        props: {
            bindValue: [Number, String],
            defaultValue: [Number, String],
            name: String,
            slotName: String,
            bindSlotValue: [Number, String],
            placeholder: {
                type: String,
                default: ''
            },
            size: String,
            inputType: String,
            slotType: {
                type:String,
                default: 'text'
            },
            slotPosition: String,
            slotTemplate:{
                type: String,
                default: ''
            },
            slotPlaceholder:{
                type: String,
                default: '请选择'
            },
            slotOptions: {
                type: Array,
                default: []
            },
            slotDefault: [String,Number],
            maxlength: Number,
            minlength: Number,
            disabled: Boolean,
            icon: String,
            rows: Number,
            autosize: [Boolean,Object],
            autoComplete: String,
            readonly: Boolean,
            max: [Number, String],
            min: [Number, String],
            step: [Number, String],
            resize: String,
            autofocus: Boolean,
            form: String,
            onIconClick: Function
        },
        created () {
            this._init()
        },
        watch: {
            bindValue: function () {
                this.value = this.bindValue;
            },
            bindSlotValue: function(val,oldVal) {
                this.select = val;
            }
        },
        methods: {
            _init: function() {
                if (this.defaultValue) {
                    this.value = this.defaultValue
                }
                else {
                    this.value = this.bindValue;
                }
                //slot
                if (this.slotDefault) {
                    this.select = this.slotDefault
                }
                else {
                    this.select = this.bindSlotValue;
                }
            },
            onClick: function(event) {
                this.$emit('click',event,this.name)
            },
            onBlur: function(event) {
                this.$emit('blur',event,this.name)
            },
            onFocus: function(event) {
                this.$emit('focus',event,this.name)
            },
            onChange: function(value) {
                this.$emit('change',value,this.name)
            },
            onChangeSlot: function(value) {
                this.$emit('change',value,this.slotName)
            }
        }
    }
</script>

<style lang="css">
.t8t-search .t8t-form-input .select .el-input {
    width: 94px;
}
</style>
