<template>
    <div class="t8t-form-checkbox">
        <el-checkbox
            v-model="checked"
            :disabled="disabled"
        >
        {{text}}
        </el-checkbox>
    </div>
</template>

<script>
    export default {
        name: 't8t-form-checkbox',
        data () {
            return {
                checked: false
            }
        },
        props: {
            bindValue: Boolean,
            defaultValue: Boolean,
            name: String,
            text: String,
            disabled: {
                type: Boolean,
                default: false
            },
            falseValue: {
                type:[Number, String, Boolean],
                default: false
            },
            trueValue: {
                type:[Number, String, Boolean],
                default: true
            }
        },
        created () {
            this._init()
        },
        watch: {
            checked: function(val,oldVal){
                let value = this.handleChecked(val)
                this.$emit('change',value,this.name)
            }
        },
        methods: {
            _init: function() {
                if (this.defaultValue) {
                    this.checked = this.defaultValue
                }
                else {
                    this.checked = this.bindValue;
                }
            },
            handleChecked: function(checked) {
                if (checked) {
                    return this.trueValue
                }
                else {
                    return this.falseValue
                }
            }
        }
    }
</script>

<style lang="css">

</style>
