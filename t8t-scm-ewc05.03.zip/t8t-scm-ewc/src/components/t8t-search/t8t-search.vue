<template>
    <div class="t8t-search" :class="searchMore?'h-auto':''">
        <el-form
            :inline="true"
            :model="formData"
            ref="form"
            label-position="left"
            :label-width="labelWidth"
            @keyup.enter.native="handleSubmit()">
            <div class="search-left-box">
                <input type="text" class="input-hidden">
                <input type="text" class="input-hidden">
                <div class="search-group" v-for="item in fields">
                    <el-form-item :label="item.label">
                        <!-- select下拉选项 -->
                        <t8t-form-select
                           v-if="item.type==='select'"
                           :defaultValue="item.defaultValue"
                           :bindValue="formData[item.name]"
                           :name="item.name"
                           :placeholder="item.placeholder"
                           :filterable="item.filterable"
                           :allowCreate="item.allowCreate"
                           :multiple="item.multiple"
                           :disabled="item.disabled"
                           :options="item.selectSourceKey?selectSource[item.selectSourceKey]:null"
                           :size="item.size"
                           :clearable="item.clearable"
                           :multipleLimit="item.multipleLimit"
                           :filterMethod="item.filterMethod"
                           :remote="item.remote"
                           :service="item.service"
                           :method="item.method"
                           :remoteArgs="item.remoteArgs"
                           :remoteQueryKey="item.remoteQueryKey"
                           :loading="item.loading"
                           :loadingText="item.loadingText"
                           :noMatchText="item.noMatchText"
                           :noDataText="item.noDataText"
                           :popperClass="item.popperClass"
                           :isGroup="item.isGroup"
                           @change="onChange"
                           @visible-change="onVisibleChange"
                        >
                        </t8t-form-select>
                        <!-- 输入input -->
                        <t8t-form-input
                            v-else-if="item.type==='input'"
                            :defaultValue="item.defaultValue"
                            :bindValue="formData[item.name]"
                            :inputType="item.inputType"
                            :slotType="item.slotType"
                            :slotPosition="item.slotPosition"
                            :slotTemplate="item.slotTemplate"
                            :slotPlaceholder="item.slotPlaceholder"
                            :slotName="item.slotName"
                            :bindSlotValue="formData[item.slotName]"
                            :slotDefault="item.slotDefault"
                            :slotOptions="item.selectSourceKey?selectSource[item.selectSourceKey]:null"
                            :name="item.name"
                            :placeholder="item.placeholder"
                            :maxlength="item.maxlength"
                            :minlength="item.minlength"
                            :disabled="item.disabled"
                            :size="item.size"
                            :icon="item.icon"
                            :rows="item.rows"
                            :autosize="item.autosize"
                            :autoComplete="item.autoComplete"
                            :readonly="item.readonly"
                            :max="item.max"
                            :min="item.min"
                            :step="item.step"
                            :resize="item.resize"
                            :autofocus="item.autofocus"
                            :form="item.form"
                            :onIconClick="item.onIconClick"
                            @click="onClick"
                            @blur="onBlur"
                            @focus="onFocus"
                            @change="onChange"
                        >
                        </t8t-form-input>
                        <!-- popup -->
                        <t8t-form-popup
                            v-else-if="item.type==='popup'"
                            :bindValue="formData[item.name]"
                            :defaultValue="item.defaultValue"
                            :ref="item.name"
                            :records="item.records"
                            :textValue="item.textValue"
                            :filedValue="item.filedValue"
                            :name="item.name"
                            :placeholder="item.placeholder"
                            :disabled="item.disabled"
                            :icon="item.icon"
                            :onIconClick="item.onIconClick"
                            :dialog="item.dialog"

                            :customItem="item.customItem"
                            :fetchSuggestions="item.fetchSuggestions"
                            :popperClass="item.popperClass"
                            :triggerOnFocus="item.triggerOnFocus"
                            :options="item.selectSourceKey?selectSource[item.selectSourceKey]:null"
                            :remote="item.remote"
                            :service="item.service"
                            :method="item.method"
                            :remoteArgs="item.remoteArgs"
                            :remoteQueryKey="item.remoteQueryKey"
                            :autoText="item.autoText"
                            :autoValue="item.autoValue"
                            @select="onSelect"
                            @change="onChange"
                        >
                        </t8t-form-popup>
                        <!-- autocomplete -->
                        <t8t-form-autocomplete
                            v-else-if="item.type==='autocomplete'"
                            :defaultValue="item.defaultValue"
                            :bindValue="formData[item.name]"
                            :name="item.name"
                            :placeholder="item.placeholder"
                            :disabled="item.disabled"
                            :customItem="item.customItem"
                            :fetchSuggestions="item.fetchSuggestions"
                            :popperClass="item.popperClass"
                            :triggerOnFocus="item.triggerOnFocus"
                            :onIconClick="item.onIconClick"
                            :icon="item.icon"
                            :options="item.selectSourceKey?selectSource[item.selectSourceKey]:null"
                            :remote="item.remote"
                            :service="item.service"
                            :method="item.method"
                            :remoteArgs="item.remoteArgs"
                            :remoteQueryKey="item.remoteQueryKey"
                            @select="onSelect"
                            @change="onChange"
                        ></t8t-form-autocomplete>
                         <!-- 选择日期时间 -->
                         <t8t-form-date-picker
                             v-else-if="item.type==='date'||item.type==='datetime'||item.type==='datepicker'"
                             :bindValue="formData[item.name]"
                             :name="item.name"
                             :placeholder="item.placeholder"
                             :readonly="item.readonly"
                             :disabled="item.disabled"
                             :editable="item.editable"
                             :clearable="item.clearable"
                             :size="item.size"
                             :pickertype="item.pickertype?item.pickertype:item.type"
                             :format="item.format"
                             :align="item.align"
                             :popperClass="item.popperClass"
                             :pickerOptions="item.pickerOptions"
                             :rangeSeparator="item.rangeSeparator"
                             :startField="item.startField"
                             :endField="item.endField"
                             @change="onChange"
                             >
                         </t8t-form-date-picker>
                         <!-- 省市区联动 -->
                         <t8t-division
                            v-else-if="item.type==='area'"
                            :changeOnSelect="true"
                            :filterable="true"
                            v-model="formData[item.name]"
                            :placeholder="item.placeholder?item.placeholder:'选择区域'"
                            @change="onDivisionChange"
                            >
                        </t8t-division>
                        <t8t-form-checkbox
                            v-else-if="item.type==='checkbox'"
                            :bindValue="formData[item.name]"
                            :defaultValue="item.defaultValue"
                            :text="item.text"
                            :name="item.name"
                            :disabled="item.disabled"
                            :trueValue="item.trueValue"
                            :falseValue="item.falseValue"
                            @change="onChange"
                        >
                        </t8t-form-checkbox>
                    </el-form-item>
                </div>
            </div>
            <div class="search-group-cli">
                <span
                    class="more-serach"
                    v-if="showToggleBtn"
                    @click="toggleSearchBtn()"
                    >更多查询
                    <i class="el-icon-d-arrow-left"></i>
                </span>
                <el-button type="primary" @click="handleSubmit()">查询</el-button>
                <el-button v-if="resetBtnVisible" @click="resetFrom()">重置</el-button>
            </div>
        </el-form>
    </div>
</template>

<script>
    import api from 'src/utils/api.js'
    import T8tDivision from 'src/components/t8t-division/index'
    import T8tFormSelect from './t8t-form-select.vue'
    import T8tFormInput from './t8t-form-input.vue'
    import T8tFormAutocomplete from './t8t-form-autocomplete.vue'
    import T8tFormDatePicker from './t8t-form-date-picker.vue'
    import T8tFormCheckbox from './t8t-form-checkbox.vue'
    export default {
        name: 't8t-search',
        components: {
            T8tDivision,
            T8tFormSelect,
            T8tFormInput,
            T8tFormAutocomplete,
            T8tFormDatePicker,
            T8tFormCheckbox
        },
        data() {
            return {
                searchMore : false
            }
        },
        props: {
            fields : Array,
            selectSource : Object,
            showToggleBtn: {
                type: Boolean,
                default: true
            },
            formData: {
                type: Object,
                default: {}
            },
            resetBtnVisible: {
                type: Boolean,
                default: true
            },
            labelWidth: {
                type: String,
                default: '100px'
            }
        },
       created() {
            //初始化表单字段
            let fields = this.fields
            let formDatas = {}
            for(let i = 0;i<fields.length;i++) {
                if (fields[i].defaultValue) {
                    formDatas[fields[i].name] = fields[i].defaultValue
                }
                else {
                    formDatas[fields[i].name] = ''
                }
                //slot select
                if (fields[i].slotDefault&&fields[i].slotName) {
                    formDatas[fields[i].slotName] = fields[i].slotDefault
                }
                else {
                    if (fields[i].slotName) {
                        formDatas[fields[i].slotName] = ''
                    };
                }
            }
            this.formData= formDatas
        },
        methods: {
            toggleSearchBtn: function () {
                this.searchMore = !this.searchMore
            },
            handleSubmit: function (e) {
                let formData = this.formData;
                let copySearch = Object.assign({},formData);
                for ( let i in copySearch) {
                    //空字符串置null
                    if(copySearch[i]==='') {
                        copySearch[i] = null;
                    }
                    //字符串前后空格去除
                    if (copySearch[i]&&typeof(copySearch[i])==='string') {
                        copySearch[i] = copySearch[i].replace(/(^\s*)|(\s*$)/g,'')
                    }
                }

                let fields = this.fields
                for(let j = 0;j<fields.length;j++) {
                    //遍历fields，类型为int类型的转换
                    if (fields[j].valueType==='int'&&copySearch[fields[j].name]) {
                        copySearch[fields[j].name] = Number(copySearch[fields[j].name])
                    }
                    //类型为时间，时间转换时间戳
                    else if ((fields[j].type==='date'||fields[j].type==='datetime'||fields[j].type==='datepicker')&&copySearch[fields[j].name]){
                        //时间范围类处理
                        if(fields[j].pickertype==='datetimerange'||fields[j].pickertype==='daterange'){
                            let value = copySearch[fields[j].name]
                            var valStart=null;
                            var valEnd=null;
                            if (value[0]&&value[1]) {
                                valStart = value[0].getTime()/1000;
                                valEnd = value[1].getTime()/1000
                            };
                                copySearch[fields[j].startField] = valStart
                                copySearch[fields[j].endField] = valEnd
                            //跟其他name重名则不删除
                            if (fields[j].name!==fields[j].startField&&fields[j].name!==fields[j].endField) {
                                delete copySearch[fields[j].name]
                            }
                        }
                        else {
                            copySearch[fields[j].name] = copySearch[fields[j].name].getTime()/1000
                        }
                    }
                    //类型为area的将value分别赋值给对应的subNames
                    else if(fields[j].type==='area') {
                        let subNames = fields[j].subNames
                        let name = fields[j].name
                        for (var i = 0; i < subNames.length; i++) {
                            if (copySearch[name][i]) {
                                copySearch[subNames[i]] = copySearch[name][i]
                            }
                            else {
                                copySearch[subNames[i]] = null
                            }
                        }
                        //跟subNames重名则不删除
                        let sameName = false
                        for (var i = 0; i < subNames.length; i++) {
                            if (name===subNames[i]) {
                                sameName = true
                                break;
                            }
                        }
                        if (!sameName) {
                            delete copySearch[name]
                        }
                    }
                }
                this.$emit('submit',copySearch)
            },
            resetFrom: function () {
                let formData = this.formData
                let fields = this.fields
                for(let elem of fields) {
                    if (elem.defaultValue!==undefined) {
                        formData[elem.name] = elem.defaultValue
                    }
                    else {
                        formData[elem.name] = ''
                    }
                }
            },
            //api设置formData的值
            setFormData: function(data) {
                for(let i in data) {
                    this.formData[i] = data[i]
                }
            },
            //更新弹窗的input的record
            updateRecord: function(name,records) {
                this.$refs[name][0].records = records
            },
            onChange: function(value,name) {
                this.formData[name] = value
                this.$emit('change', value, name)
            },
            onDivisionChange: function(value,lastValue) {
                this.$emit('changeDivision', value, lastValue)
            },
            //select下拉框出现隐藏时触发
            onVisibleChange: function(value,name) {
                this.$emit('visible-change', value,name)
            },
            onClick: function(e,name) {
                this.$emit('click', e,name)
            },
            onBlur: function(e,name) {
                this.$emit('blur', e,name)
            },
            onFocus: function(e,name) {
                this.$emit('focus', e,name)
            },
            onSelect: function(value,name){
                this.formData[name] = value
                this.$emit('select', value,name)
            }
         }
    }

</script>

<style lang="css" scoped>

</style>


<style>
.t8t-search{
    position: relative;
    height: 44px;
    min-height: 44px;
    padding: 10px 20px 0;
    border-bottom: 1px solid #eff7fa;
    overflow: hidden;
    font-size: 12px;
}
 .t8t-search .el-form {
    position: relative;
}
.t8t-search .search-group-cli {
    position: absolute;
    right: 0;
    top: 2px;
    width: 222px;
    z-index: 2;
    text-align: right;

}
.search-left-box {
    float: left;
    width: 80%;
}
.t8t-search.h-auto {
    height: auto !important;
}
.t8t-search.h-auto .more-serach .el-icon-d-arrow-left {
    transform: rotate(90deg);
    vertical-align: text-top;
}
.t8t-search .more-serach {
    padding-right: 15px;
    color: #3396fb;
    cursor: pointer;
    -webkit-user-select: none;
}
.t8t-search .search-group {
    display: inline-block;
    width: auto;
    margin-right: 30px;
}

.t8t-search .more-serach .el-icon-d-arrow-left {
    padding-left: 5px;
    font-size: 12px;
    transform: rotate(-90deg);
    vertical-align: text-bottom;
}
.t8t-search .el-input {
    width: 180px;
}
.t8t-search .el-date-editor--datetimerange.el-input {
    width: 350px;
}
.t8t-search .el-form--label-left .el-form-item__label {
    text-align: right;
    font-size: 12px;
    vertical-align: top;
}
.t8t-search .el-input__inner{
    font-size: 12px;
    height: 32px;
}
.t8t-search .el-form-item__content{
    font-size: 12px;
}
.t8t-search .el-button{
    padding: 8px 17px;
    font-size: 12px;
}
.t8t-search .el-select-dropdown__item{
    font-size: 12px;
}
.input-hidden {
    display: none;
}
.t8t-search .el-form-item{
    margin-top: 0;
    margin-bottom: 10px;
}
</style>
