<template>
    <div class="app-content-container"
         :class="{'stretch':stretch}">
        <router-view class="app-content"></router-view>
        <router-view name="popView"></router-view>
    </div>
</template>

<script>
export default {
    name: 'app-content',
    props: {
        stretch: {
            type: Boolean,
            default: false
        }
    }
}

</script>

<style lang="css">
.app-content-container {
    width: calc(100% - 199px);
    height: 100%;
    overflow: hidden;
    position: absolute;
    /*transition: width 0.3s;*/
    right: -1px;
}

.app-content-container.stretch {
    /*transition: width 0.3s;*/
    width: calc(100%);
}

.app-content {
    height: 100%;
    display: flex;
    flex-direction: column;
    flex: 1;
}

.g-main-container {
    flex: 1;
    display: flex;
    flex-direction: row;
}

.g-main-container-column {
    display: -ms-flexbox;
    display: flex;
    -ms-flex: 1;
    flex: 1;
    -ms-flex-direction: column;
    flex-direction: column;
    overflow: auto;
}
</style>

