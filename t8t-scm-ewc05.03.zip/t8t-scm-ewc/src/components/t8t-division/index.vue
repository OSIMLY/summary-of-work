<template>
    <span class="t8t-division">
        <el-cascader
            v-model="defaultSelects"
            :options="cities"
            :popper-class="popperClass"
            :placeholder="placeholder"
            :disabled="disabled"
            :clearable="clearable"
            :expand-trigger="expandTrigger"
            :show-all-levels="showAllLevels"
            :filterable="filterable"
            :debounce="debounce"
            :change-on-select="changeOnSelect"
            :size="size"
            @change="onChange"
            :defaultValue="defaultValue"
            @active-item-change="onActiveItemChange"
        >
        </el-cascader>
        <input type="hidden" ref="input" v-bind:value="defaultSelects" v-on:input="updateValue($event.target.value)">
    </span>
</template>

<script>
    import cities from './division.json'
    import oMap from './parentMaps.json'
    export default {
        name: 't8t-division',
        props: {
            value: Array,
            popperClass: String,
            disabled: {
                type: Boolean,
                default: false
            },
            clearable: {
                type: Boolean,
                default: false
            },
            expandTrigger: {
                type: String,
                default: 'click'
            },
            showAllLevels: {
                type: Boolean,
                default: true
            },
            placeholder: String,
            debounce: {
                type: Number,
                default: 300
            },
            filterable: {
                type: Boolean,
                default: true
            },
            changeOnSelect: {
                type: Boolean,
                default: false
            },
            size: String,
            defaultValue: String
        },
        data () {
            return {
                cities: cities,
                defaultSelects: [],
                defaultValue: ""
            }
        },
        created () {
            this._init()
        },
        methods: {
            _init () {
                if (this.defaultValue) {
                    let defaults = this.getParentList(this.defaultValue);
                    this.defaultSelects = defaults
                }
            },
            updateValue: function (value) {
                // 通过 input 事件发出数值
                this.$emit('input', value)
            },
            getParentList (code) {
                if (typeof oMap[code] === 'undefined') {
                    return null;
                }

                return this.deepLoop(code);
            },
            deepLoop (code, list) {
                let curList = list || [(code + "")];
                if (oMap[code]) {
                    curList.unshift(oMap[code] + "");
                    this.deepLoop(oMap[code], curList);
                }

                return curList;
            },
            onChange (value) {
                this.$emit('change', value, value[ value.length - 1 ])
                this.$emit('input', value)
            },
            onActiveItemChange (parents) {
                this.$emit('active-item-change', parents)
            }
        },
        watch: {
            defaultValue: function () {
                this._init()
            }
        }
    }
</script>

<style lang="css">
    .t8t-division {
        display: inline-block;
        position: relative;
        background-color: #fff;
    }
    .el-cascader.is-disabled .el-cascader__label {
        z-index: 2;
        color: #bbb
    }
</style>
