<template>
    <el-dialog v-model="visible" @close="closeImgDialog" size="full" class="gallery-transparent-dialog">
        <el-carousel :interval="0" arrow="always" autoplay="false">
            <el-carousel-item v-for="item in data">
                <img :src="item.src" :title="item.title">
            </el-carousel-item>
        </el-carousel>
    </el-dialog>
</template>

<script>
    import Popup from '../element-ui/lib/utils/popup'
    export default {
        name: 't8t-gallery',
        mixins: [Popup],
        data(){
            return {
                visible: false
            }
        },
        props: {
            data: {
                type: Array,
                default: []
            }
        },
        method: {
            closeImgDialog(){
                // this.visible = false
            }
        },
        watch: {
            visible(val) {
                this.$emit('input', val);
            }
        }
    }
</script>
<style lang="css" scoped>
</style>
<style lang="css">
    .gallery-transparent-dialog .el-dialog--full{
        background: transparent;
        display: flex;
        flex-direction: column;
    }
    .gallery-transparent-dialog .el-dialog__body{
        flex: 1;
        display: flex;
    }
    .gallery-transparent-dialog .el-carousel{
        width: 100%;
        height: 100%;
    }
    .gallery-transparent-dialog .el-carousel__container{
        height: 100%;
    }
    .gallery-transparent-dialog .el-carousel__item{
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>

