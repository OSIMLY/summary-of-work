<template>
    <div>
        <div>
            <el-button @click="galleryVisible=true">111</el-button>
        </div>
        <!-- 相册 -->
        <t8t-gallery
            v-model="galleryVisible"
            :data="galleryData"
        ></t8t-gallery>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                galleryVisible: false,
                galleryData: [
                    {title: 'img1', src: 'http://pic2.to8to.com/case/1704/07/20170407_5d13ce10edb9b0fc2eb03v5wzql16d9c_sp.jpg'},
                    {title: 'img2', src: 'http://pic2.to8to.com/case/1704/07/20170407_622b1616157bf09f09cfohxwbzl1ogt4_sp.jpg'},
                    {title: 'img3', src: 'http://pic2.to8to.com/case/1704/07/20170407_2dc607143383d2e1ea389c958il1mrvk_sp.jpg'}
                ]
            }
        }
    }
</script>

<style lang="css" scoped>

</style>

