<template>
    <div class="t8t-toolbar">
        <el-button
                v-for="item in buttons"
                size="toolbar"
                :disabled="false"
                :symbol="item.symbol"
                @click="handleClick(item.symbol, $event)"
        >{{item.name}}</el-button>
    </div>
</template>

<script>
    import Perm from '../../services/permission/Perm.js'
    export default{
        name: 'T8tToolbar',
        data(){
            return {
                buttons: []
            }
        },
        props: {
            symbol: String
        },
        mounted () {
            let that = this
            Perm.buttons('#' + this.$route.path)
            .then((res) => {
                that.buttons = res.data.result
            })
        },
        components:{
        },
        watch: {
            $route: function () {
                let that = this
                Perm.buttons('#' + this.$route.path)
                .then((res) => {
                    that.buttons = res.data.result
                })
            }
        },
        methods: {
            handleClick (event, sourceEvent) {
                this.$emit(event, event, sourceEvent)
            },
            /**
             * 根据symbol禁用按钮
             * @param symbol
             */
            disableBySymbol (symbol) {
                let itemSymbol, that = this;
                this.$children.forEach((child) => {
                    itemSymbol = child.$el.getAttribute('symbol')
                    if (itemSymbol === symbol) that.disable(child.$el)
                })
            },
            unDisableBySymbol (symbol) {
                let itemSymbol, that = this;
                this.$children.forEach((child) => {
                    itemSymbol = child.$el.getAttribute('symbol')
                    if (itemSymbol === symbol) that.unDisable(child.$el)
                })
            },
            disable (target) {
                let nodeType = target.nodeName.toLowerCase()
                let source = (nodeType === 'span') ? target.parentNode : target
                source.classList.add('is-disabled')
                source.setAttribute('disabled', true)
            },
            unDisable (target) {
                let nodeType = target.nodeName.toLowerCase()
                let source = (nodeType === 'span') ? target.parentNode : target
                source.classList.remove('is-disabled')
                source.removeAttribute('disabled')
            }
        }
    }
</script>
<style lang="css" scoped>

.t8t-toolbar {
    padding: 13px;
    height: 24px;
}

.t8t-toolbar .el-button--toolbar:first-child {
    margin-left: 8px;
}

.t8t-toolbar .el-button--toolbar {
    padding: 5px 11px;
    font-size: 12px;
    border-radius: 2px;
    border-color: rgb(232, 237, 241);
    color: rgb(50, 139, 239);
    margin-right: 5px;
}

.t8t-toolbar .el-button--toolbar:focus {
    border-color: rgb(191, 201, 217)
}

.t8t-toolbar .el-button--toolbar:hover {
    border-color: rgb(50, 139, 239)
}

.t8t-toolbar .is-disabled {
    color: rgb(191, 203, 217);
    border-color: rgb(209, 219, 229);
}

.t8t-toolbar .is-disabled:hover {
    border-color: rgb(209, 219, 229);
}

.t8t-toolbar .el-button--success.is-plain {
    color: rgb(19, 206, 102)
}

.t8t-toolbar .el-button--danger.is-plain {
    color: rgb(255, 86, 97)
}

.t8t-toolbar .el-button + .el-button {
    margin-left: 0px;
}
/* 深色皮肤 */
.t8t-toolbar.t8t-dark .el-button--toolbar{
    background-color: #1e3046;
    color: #d1dde9;
    border: 1px solid #09131d;
}
.t8t-toolbar.t8t-dark .el-button--toolbar:hover{
    color: #1e3046;
    background-color: #d2deeb;
}
</style>
