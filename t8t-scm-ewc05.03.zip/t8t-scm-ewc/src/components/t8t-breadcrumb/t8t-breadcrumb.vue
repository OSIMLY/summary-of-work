<template>
    <div class="t8t-breadcrumb">
        <el-breadcrumb separator=">">
            <el-breadcrumb-item v-for="item in data">{{item.title}}</el-breadcrumb-item>
        </el-breadcrumb>
    </div>
</template>

<script>
    export default {
        name: 't8t-breadcrumb',
        props: {
            data: {
                type: Array,
                default: []
            }
        }
    }

</script>

<style lang="css" scoped>
    .t8t-breadcrumb {
        height: 35px;
        min-height: 35px;
        border-bottom: 1px solid #eff7fa;
        display: flex;
        align-items: center;
    }

    .t8t-breadcrumb .el-breadcrumb {
        margin-left: 20px;
        font-size: 12px;
    }
</style>


<style>
    .t8t-breadcrumb .el-breadcrumb__item__inner,
    .t8t-breadcrumb .el-breadcrumb__separator {
        color: #666!important;
    }

    .t8t-breadcrumb .el-breadcrumb__item__inner,
    .t8t-breadcrumb .el-breadcrumb__separator {
        cursor: default!important;
    }
</style>
