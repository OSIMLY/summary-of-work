<template>
    <div id="app" class="chrome_higer">
        <router-view></router-view>
        <vue-progress-bar></vue-progress-bar>
    </div>
</template>

<script>
import Cookie from 'js-cookie'
export default {
    beforeCreate () {
        // 检测登陆状态，没有登陆直接跳转登录页
        let uid = Cookie.get('t8t-it-uid');
        let ticket = Cookie.get('t8t-it-ticket');

        // 开发环境为了方便开发，不校验登陆
        if (!(document.domain === 'localhost') && (!uid || !ticket) ) {
            location.href = 'http://erp.to8to.com/index.php/admin/login'
        }
    },
    mounted () {
        this.$Progress.finish()
    },
    created () {
        this.$Progress.start()
        this.$router.beforeEach((to, from, next) => {
            if (to.meta.progress !== undefined) {
                let meta = to.meta.progress
                this.$Progress.parseMeta(meta)
            }
            this.$Progress.start()
            next()
        })
        this.$router.afterEach((to, from) => {
            this.$Progress.finish()
        })
    }
}
</script>

<style>
    [v-cloak] {
        display: none;
    }

    html {
        font-family: "Helvetica Neue", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
        color: #48556a;
        background: #fff;
        overflow: hidden;
    }

    button,
    input,
    select,
    textarea {
        font-family: "Helvetica Neue", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
    }

    html,
    body {
        width: 100%;
        height: 100%;
        margin: 0;
    }

    #app {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
    }

    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }

    ::-webkit-scrollbar-thumb {
        border-radius: 3px;
        background-color: #b2b2b2;
    }

    ::-webkit-scrollbar-thumb:hover {
        background-color: #666;
    }

    ::-webkit-scrollbar-track {
        background-color: transparent;
    }

    ::-webkit-scrollbar-corner {
        background-color: transparent;
    }
    /* 需要滚动条请使用内部滚动 */
    /* 全局样式 */
    .g-transparent-dialog .el-dialog--full{
        background: transparent;
        display: flex;
        flex-direction: column;
    }
    .g-transparent-dialog .el-dialog__body{
        flex: 1;
        display: flex;
    }
    .g-transparent-dialog .g-img-container {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .g-w-450 .el-dialog{
        width: 450px;
    }
    .g-w-640 .el-dialog{
        width: 640px;
    }
    .g-w-1000 .el-dialog{
        width: 1000px;
    }
</style>
<!-- 单据页样式 -->
<style>
    .t8t-full-dialog2 .el-dialog__header{
        padding: 0;
    }
    .t8t-full-dialog2 .el-dialog__body{
        padding: 0;
        height: 100%;
    }
    .t8t-full-dialog2 .t8t-full-dialog2-container{
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .t8t-full-dialog2 .dialog2-main-container{
        flex: 1;
        display: flex;
        padding: 0 30px 20px 30px;
        flex-direction: column;
        overflow: hidden;
        position: relative;
    }
    .t8t-full-dialog2 .full-dialog-toolbar-container{
        height: 38px;
        background-color: #1e3046;
    }
    .t8t-full-dialog2 .toolbar-container{
        width: 1220px;
        margin: 0 auto;
        padding-left: 15px;
        height: 100%;
        display: flex;
        align-items: center;
        background-color: #1e3046;
    }
    .t8t-full-dialog2 .full-dialog-form-container{
        width: 1220px;
        margin-left: auto;
        margin-right: auto;
        overflow: hidden;

    }
    .t8t-full-dialog2.isHide .full-dialog-form-container{
        height: 0;
        padding-top: 0;
    }
    .t8t-full-dialog2 .dialog2-form-item-container{
        width: 25%;
    }
    .t8t-full-dialog2 .full-dialog-form-container .el-form-item__content,
    .t8t-full-dialog2 .full-dialog-form-container .el-date-editor.el-input{
        width: 180px;
    }
    .t8t-full-dialog2 .full-dialog-tabs-container{
        display: flex;
        flex: 1;
        overflow: auto;
    }
    .t8t-full-dialog2 .top-hide{
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 1;
        transform: rotate(90deg);
        cursor: pointer;
    }
    .t8t-full-dialog2.isHide .top-hide{
        transform: rotate(-90deg);
    }
    .t8t-full-dialog2 .el-tabs{
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    .t8t-full-dialog2 .el-tabs__item{
        font-size: 12px;
        height: 22px;
        line-height: 22px;
        margin-top: 13px;
        margin-bottom: 12px;
    }
    .t8t-full-dialog2 .el-tabs__header{
        border-top: 2px solid #eff7fa;
        border-bottom: 2px solid #eff7fa;
    }
    .t8t-full-dialog2 .el-tabs__active-bar{
        height: 1px;
    }
    .t8t-full-dialog2 .el-tabs__item + .el-tabs__item {
        border-left: 1px solid #d4dce7;
    }
    .t8t-full-dialog2 .el-tabs__nav-wrap{
        width: 1220px;
        margin: 0 auto;
    }
    .t8t-full-dialog2 .el-tabs__content{
        flex: 1;
        display: flex;
    }
    .t8t-full-dialog2 .el-tab-pane{
        display: flex;
        flex: 1;
        overflow: auto;
    }
    .t8t-full-dialog2 .dialog2-form-container{
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
    }
    .t8t-full-dialog2 .dialog2-flex-column{
        display: flex;
        flex-direction: column;
    }
</style>
