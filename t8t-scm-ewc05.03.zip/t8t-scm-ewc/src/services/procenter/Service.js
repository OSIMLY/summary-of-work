
let Services = {
	//流程分类树
	PROCENTERTREE:{
		// /biz/t8t-wkf-dat/app
		name:'tac4MBKgFxtkOyGS5xolDBVgEEqR4_j',		
		methods:{
			// listProcessCategorys
			LISTCATEGIRY:'N4VlGazqhEV4O7p5tFECXLmvbMA87jp'
		}
	},

	//流程分类
	PROCENTERCATEGORY:{
		// /biz/to8to-it/app.tit-configure
		name:'UXCW5_FfDpVAC4RS04cKtoUQPAo0Ct1bM6DkpEzEh-tmghj',
		methods:{
			// systemCode.searchByPage
			CATEGORY:'P5ZnSOIfU9FZfG5oeLRcGlaqV3mIzl0g-JG',
		}
	},

	//列表 
	PROCENTERDEPLOYLIST:{
		//  /biz/t8t-wkf-dat/app
		name:'kahC43ofmx3VBfYN4D86B0aWN7xyrzY',
		methods:{
			// getProcessDef 获取部署列表
			DEPLOYLIST:'5k_j_P_WD8RwL8UqaGgemLL',
			//   retrieveProcessPicture 获取流程图
			PRODIAGRAM:'ocM-RfcwmwgITykyYSQX_K9vYW-g7j.vb43',
			// getUserTask 获取流程列表
			FLOWLIST:'Hi_a7GN6TG85Q0RgZpY',
			//获取审批流程
			PROCESSDETAIL:'h9Gn7JK_3a-JnhpyXXPI7xixH31',

			// getUserTaskWeb 待办
			GETUSERTASKSWEB:'9bMs6cQMGe_LEaZPtnQU6_k',

			//getAllProcessName 获取流程名
			PROCESSNAME:'bzPfRPsZAIkInrHzR0Ww3jYQ_-B',
			//   getProcessInstsWeb 获取已办进行中
			PROCESSINSTSWEB:'mN-bBZSV7j6gslGBe2R8YAd8iBn',
			//  getHistoricProcessInstsWeb  获取已办已完成
			HISTORYPROCESSINSTSWEB:'NXGklFkG5yvT_vupqPexl6hpmeFSq4FqJKrsYWV'
		}
	},

	//部署列表操作
	PROCENTERDEPLOYCTL:{
		// /biz/t8t-wkf-ctl/app
		name:'ubBdWrXdnC-1cRnPgZs7CXA6xZRnzF0',
		methods:{
			// suspendProcDef 部署流程挂起
			SUSPENDPROCDEF:'5nyeHyB7ZEuri3TpRh3tD0d',
			// activateProcDef 部署流程恢复
			ACTIVATEPROCDEF:'fcpjGsaCz11JaX2oP0Tevt2',
			// suspendProcess 流程挂起
			SUSPENDPROCESS:'IiBNEwBUZHvaZEd884hkl9s',
			// activateProcess 流程恢复 
			ACTIVAREPROCESS:'r-jGv4CJ2_eJr8ju5dL55tG',
			// updateAssignee 更改处理人
			UPDATEASSIGNEE:'vhuF2ysepV8qxRGxwy2tauE'
		}
	},

	//部署流程
	PROCENTERDEPLOY:{
		///biz/workflow/app.bpmnserver
		name:'75HlZS4nGZjFaJVfcJTtxqRfF8pIixrHj8VLVGRXNwD',
		methods:{
			//  deployByZip //部署新流程
			DEPLOYBYZIP:'3qjAn-cqKdzGCqqoRdo'
		}
	},


	//获取用户账号信息
	USERINFODATD:{
		// /biz/to8to-it/app.account
		name:'VVFThqq6Am6swm_FAiqN6rrCR46gTZuiCR5qQ5N',
		methods:{
			// account.query  
			ACOUNT:'1zrMMREJIKUfTbFF_QMtddb',
			// account.findByName
			FINDUIDBYNAME:'rWhkvIhueB4zmbk3Mhcl3hYq2q5'
		}
	},
	//获取系统人员列表
	SYSTEMCODE:{
		// /biz/to8to-it/app.tit-configure
		name:'6ke2igQ72I0buaw0iMB5QK05wLEnhMQ7HuZlwSYYzEgGJCu',
		// systemCode.listNextLevel
		methods:{
			GETSYSTEMCODE:'MXXlQL4yf_XaY2HZLHGADkzYymPhjUU-DJJ'
		}
		
	},
	//供应商人员列表
	SUPPLIERSHOP:{
		// /biz/supply-chain/app.supply-server
		name:'a4huh3BDf-pU0emKmyu7Fiwcu9ytbRyd6R4fJGCtTE1xcMLdnKS',
		methods:{
			// shop.query 供应商人员列表
			GETSUPPSHOPPERSONS:'CxHWEqtWE6yKZEE5n1c'
		}
	}

}

export default Services