/*
 * @FileName: Perm
 * @Description: 
 * @Date: 2017-03-03
 * @version: 1.0
 * @author: <carl.wu@corp.to8to.com>
 */

import Cookie from 'js-cookie'
import Service from '../../utils/Service'
import axios from '../../utils/axios.js'

export default {

	buttons(fid) {
		let args = {
			fatherUrl: fid,
			accountID: Cookie.get('t8t-it-uid')
		}

		return axios({
			method: Service.PERM.methods.LIST_BY_ACCOUNTID_FATHERURL,
			service: Service.PERM.name,
			args: args
		})
	}

}
