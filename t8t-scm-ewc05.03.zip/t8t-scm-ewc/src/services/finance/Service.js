// 财务模块
let Services = {
    DEBITCHANNEL: {
        // /biz/t8t-fi-fcm/app
        name: 'niz-D89-bg7zuH4V_XEQ5J3gfP4es_t',
        methods: {
            // debitChannel.create
            CREATE: 'N8LxpSi9bJT-PkTue0QuVmPMMskaGl5',
            // debitChannel.update
            UPDATE: 'sZan4wrmKzZbGy9dwl7cDsLKKtlHIiZ',
            // debitChannel.queryPage
            PAYMETHOD_QUERY: 'fKfmTjLLnPN6TtgmTQtKP7dhNygAN0yiYM4',
            // debitChannel.status.update
            STATUSUPDATE: 'VBPLAUJ-A_56nUQO_TGk2wTR6bLZq0bV6KaH_77',
            //batchDebitChannel.status.update
            BATCHSTATUSUPDATE: 'VNDxAvHBRLCUVAFTAPvrAUetWVdOZSARArHfWAYS8CbXNo5',
            // debitType.queryPage
            DEBITTYPE_QUERYPAGE: 'TS8-ZWQ9OdQ5cySscBWVGzKv8jS86f_',
            // debitType.create
            DEBITTYPE_CREATE: 'VxDUZSSR_JDBQ1jKrXWEwWP34b7',
            // debitType.update
            DEBITTYPE_UPDATE: 'kgjt0zqkiomgbAYGi94ok_zeLla',
            // batchDebitType.status.update
            BATCHDEBITTYPE_STATUS_UPDATE: 'VeyxFyf_B-0Sct9yoG6F-rUkOOZFQbzS-vBy-eY694l',
            //款项用途
            //fundPurpose.create
            FUNDPERPOSE_CREATE: 'tpsDqe9VHId3UHyOVzoHc5aumF2',
            //fundPurpose.queryPage
            FUNDPERPOSE_QUERY_PAGE: '2itdfkd7LsTe21eAayedfuixbUOgU_c',
            //fundPurpose.status.update
            FUNDPERPOSE_STATUS_UPDATE: 'j1e_lWXL_rk_6qwfF7pELrrQ-m_dxf_WEQCTbNN',
            //batchfundPurpose.status.update
            FUNDPERPOSE_BATCH_STATUS_UPDATE: 'YnHgGhvqOnZT0RR1UhwXxqzaUlhIzGwaS5rLWwfDERm',
            //fundPurpose.update
            FUNDPERPOSE_UPDATE: 'ivqDuHNXKnxYeM5Ua1j1Jtgsm.6'
        }
    },
    // 财务基础数据服务
    FINA_BASEDATA: {
        // /biz/t8t-fi-fmd/app
        name: 'MB4Ke6f494fflDr2l8r4NlN3WxyAE.R',
        methods: {
            // bankAccount.queryPage
            QUERY_PAGE: 's1UwuBX1bHQGeqisrnbo5r2nklovSwo',
            // bankAccount.update
            BANK_UPDATE: 'X82nC9DZ3-JyOb-NkOu2hIo5llI',
            // batch.bankAccount.update
            BANK_BATCH_UPDATE: 'PtS6Tvo8mdQ0WuUemFEsi0WpWfPyPigYXeh',
            // bankAccount.excel.query
            EXCEL_QUERY: 'IAtXi1eiQIjXf1R9MyE_RTz-ZJG0CVSJBOa'
        }
    },
    //收款方式分配
    DEBITWAYDISTRIBUTION: {
        // /biz/t8t-fi-fcm/app
        name: 'Q2VkTJ8qT30vdX2QPHDE2YqRvb2tfMp',
        methods: {
            // debitWayDistribution.queryPage
            QUERYPAGE: 'idi9-z2w02vyNl3pP3ux8r07ksC6VVM0kew8DArjtm8',
            // debitWayDistribution.status.update
            STATUSUPDATE: 'xerGiv_ov8vMo-A1YJMd-61t1-DNQS10e1FGv5gxAtIvqacwokY',
            //batchDebitWayDistribution.status.update
            BATCHSTATUSUPDATE: 'ga8T2Q64WHHjOTdR4hslWHxQuTqeLM_VQZjOmE6f8NoUZEySaLciLFY',
            // debitWayDistribution.create
            CREATE_ALLOT: 'SFNdVAMSVOMkDZOIXuWeNbcPLMkExzrPeIkPSLf',
            // debitWayDistribution.update
            UPDATE_ALLOT: '8rpI7-iA89aIWDAgwJy57FCr3KCHmhSD6TNBqm7',
            //receipt.order.and.item.query
            RECEIPT_ORDER_AND_ITEM_QUERY: 'Pj5tqev9EyVP0x5n_0UpTAou-Xzzvl6uo-GwsvKlqHT'
        }
    },
    //收款计划单
    RECEIPTPLANORDER: {
        ///biz/t8t-fi-rvm/app
        name: 'wdb7BHhaftcyRtM1N8Q-SyIXTBkmRKK',
        methods: {
            // receipt.plan.order.query
            QUERYPAGE: 'YhRePUhsI84XZ_DBm0NOluUCQoJjBg1TWw3',
            //verify.order.query
            VERIFYORDERQUERY: 'r0U_vYRkEGvN9jjCQBGxWDnWG33',
            //verify.order.item.create.by.receipt
            VERIFY_ORDER_ITEM_CREATE: 'Gc7sRNUtEeK-nX_78Xw8bPdP8ulPy9eQB2LANueARyb-wMgX7J4',
            //verify.order.query.item
            VERIFY_ORDER_QUERY_ITEM: 'goQxbZX0IqsgFD4XeMkA4bSIj6OkgxwdFis',
            //verify.order.left.join.query
            VERIFY_ORDER_LEFT_JOIN_QUERY: 'IN8Hv_u4M2NRbsaqzdHw6IQAOlDD7QUC2iExrAXynrn',
            // 供测试方使用的页面
            //receipt.plan.order.create
            VERIFY_ORDER_ADD: 'GgCCULWChpFt4pUAD9oGP6cTF9v3iGaEV-tTI67'
        }
    },
    //收款计划单 - 新增
    RECEIPTPLANORDER_ADD: {
        ///biz/t8t-fi-rvm/app
        name: 'MnzGUabreIzhNtETjsagUuIzwsVuqB6',
        methods: {
            // 供测试方使用的页面
            //receipt.plan.order.create
            VERIFY_ORDER_ADD: 'GgCCULWChpFt4pUAD9oGP6cTF9v3iGaEV-tTI67'
        }
    },
    // 收款单服务
    FINA_BILLS: {
        // /biz/t8t-fi-rvm/app
        name: 'UwU1ZdHqIBZolrtjjil2FWBMRrXK2z6',
        methods: {
            // receipt.order.and.item.query
            QUERY: 'jnETaMYkyQCs0dYPkLui4ocVAhcWGTYbF-yPUUhePHB',
            // receipt.order.query
            ORDER_QUERY: 'GDDM2GOK2bDTeKGD9N3Aib6E-PO5arZ',
            // receipt.order.item.query
            ITEM_QUERY: 'JmOlZXmrZx1tcj_gJPjWd_SXtMoAxI.3TH5',
            // receipt.order.audit.notify
            AUDIT: 'riTtWjitaTH-aMblzfxqdFwZUbmq_2rsFgoY1wO',
            // receipt.order.anti.audit
            ANTIAUDIT: 'xoXzco3AwWKAb1glskV62dzphsd4VIWtX2z',
            // receipt.order.audit.reject
            REJECT: '8w_ukyb4ItUOGiqkm3toL12vS-CiVRCrrArcKiR',
            // receipt.order.left.join.query
            QUERYFLAT: 'CcJYTIZmV4fm_YDYDGawSPKOu9affnQ8vJROJIMAeK2',
            // receipt.plan.order.query
            PLAN_QUERY: '7VHQLyRf8NxoZKyvJ4BImRI4CknT0l1IGyo',
            // receipt.order.item.create
            CREATE: 'khcwmexAsJ0q4Ueg9wVe1xYNwi6TydBgROsRfL5',
            // verify.order.item.audited.create
            VERIFY: 'TdvLsERSy2c3qR7AcAOdqQMuYTQOPQRJdOtjnYEevLYTA-7',
            // receipt.plan.order.query.orOper
            OR_QUERY: 'gBYm0w5EYhZ9GeZfHjpY210JYNl7Z5wbf8eAVWKWSFAfjba',
            // receipt.order.item.update
            UPDATE: 'eqbWIWnuNF8ygpCl4KiT4CrhMIcLpTgcJI4cBAu',
            // verify.query.by.receipt.order
            RECEIPT_ORDER_QUERY: 'ORRJiJEEt6GhmJH5koCoE2q2b5UGhJY7jBeLn0B3E5r'
        }
    },
    //核销记录
    VERIFYCANCELRECORD: {
        // /biz/t8t-fi-rvm/app
        name: 'I1KqcRD6Sw3TgKWpsPlIqK3GumLGG3E',
        methods: {
            // systemCode.list
            SYS_CODE_LIST: 'vPnFi_QA4HeBWeU61ZjQPCn',
            //verify.order.query.detail
            VERIFY_ORDER_QUERY_DETAIL: 'YgsItUQRuw9e1tQ-oLtGf9wTKEzFeIXV-AgT277',
            //verify.order.query
            VERIFYORDERQUERY: 'r0U_vYRkEGvN9jjCQBGxWDnWG33',
            //verify.order.item.anti.verify
            VERIFY_ORDER_ITEM_ANTI: 'QM7tAP_9xCMlYO6KrD-KZHn_8vUR8xrA6frNMCh9bXm',
            //verify.order.query.item
            VERIFYORDERQUERYITEM: '7SbJYCIAByEd4lP-LrFK7qOLvh9OetHQRn2',
            //verify.order.left.join.source
            VERIFY_ORDER_LEFT_JOIN_SOURCE: 'HQCjFvyhkEqOE2SwN6OCYhPDUBZz_lC5PVeLSwh0m-q'
        }
    },
    //付款单服务
    PAYREMIT:{
        // /biz/t8t-fi-pvm/app
        name: 'oOQH76H9Yiv249sE1dh5Kj9jN0KJKTa',
        methods:{
            //remitOrderService.create
            REMIT_ORDER_SERVICE_CREATE: 'v0S3ZTjNc1OhvyI0n3Z8mkzetUJHlnhUN4V',
            // 驳回 remitOrderService.disapprove
            REMIT_ORDER_SERVICE_DISAPPROVE: 'MjUZHFOKJiQnK-gQUH3TVZVV1AbHDggUWDeXpshFMw9',

            //批量驳回 remitOrderService.batchDisapprove
            REMIT_ORDER_SERVICE_BATCH_DISAPPROVE: 'qvg2pmigtwjuZ1LzYxW3hBd9n3lWFiIqBqVbadmaEP7mAo0',
            //remitOrderService.tryOffline
            REMIT_ORDER_SERVICE_TRYOFFLINE: 'zFIqAE8-1kw-pKDOxODx6uA6hrQEreNrO-NEqODslXi',
            //remitOrderService.tryOnline
            REMIT_ORDER_SERVICE_TRYONLINE: '9H1aO3zxdBDiH_JtDG4ImK5W1L5nPXewHbP-2aB',
            //remitOrderService.queryPage
            REMIT_ORDER_SERVICE_QUERYPAGE: '9EILN8JHv_UCJSKZpASLY3K2p0QON1IKYS-MJKU',
            //remitOrderService.findById
            REMIT_ORDER_SERVICE_FINDBYID: 'ACzQrzucx7K0EysxIoB7L2N0U3_1DyN9noJexsf',
            //重复校验 remitOrderService.checkRepeat
            REMIT_ORDER_SERVICE_CHECKREPEAT: 'ltd3jmebUyIvkhZcIi-0UQyf-e3nDtdkt3aVj4rlSZH',
            //remitOrderItemService.query
            REMIT_ORDER_ITEM_SERVICE_QUERY: 'IA_IGDr9JA_xRV5-xQkJGO_zBkiGw7SlVxSzC5p',
            //remitOrderItemService.queryPage
            REMIT_ORDER_ITEM_SERVICE_QUERY_PAGE: '2wiHPoiyx9Fu04BxoS0xPtjkjEl3vGqEUR2jynUvgfxmqOL',
            //remitOrderService.count
            REMIT_ORDER_SERVICE_COUNT: 'Qd2cOGI_QH1b9cCTAcLdPXDiHHtt5p-8LGh',
            //remitOrderService.batchDistributeForWkf
            REMIT_ORDER_SERVICE_BATCH_DISTRIBUTE_FOR_WKF: 'SVId86DJy_HtYHGNFtaPc3fHpEQ7YoXKsC163CnREbRQHzIDJgkLXeG',
            //remitOrderService.submitForWkf
            REMIT_ORDER_SERVICE_SUBMIT_FOR_WKF: "fradeLZRQhsTWQl-tq7NuisM-Ffe3WnhYWoRXFjc_wa"
        }
    },
    // 工作流
    WKF: {
        // /biz/t8t-wkf-ctl/app
        name: 'J0AjJN7yEv7kiYzph3PFyZ53MHF-27p',
        methods: {
            // startProcess
            startProcess: 'LWEkwROUAxRarEH3CpV',
            // completeTask
            completeTask: 'iw3jS8ntm-NbphRjCyt'
        }
    },

    //付款方式配置板块
    FINA_PAY_METHOD_CONFIG: {
        // /biz/t8t-fi-pvm/app
        name: 'VmHS1srPCZUThqolu6uXm3c_R-lSOfL',
        methods: {
            // remitChannelService.query
            QUERY: 'PFGudKLCv4DzygOaKDa0SIl8XVTNDlPKDHlS-ug',
            // remitChannelService.queryPage
            QUERY_PAGE: 'SdfximiHNffOOjTwe1Da7hoUwavkID2lfKqoeKneCK3',
            // remitChannelService.findIdsCodesAndNamesById
            FIND_BY_ID_NAMES: 'lShTnTO8uC8CsGkSjTKdAoYkfcQ9kOQT3PQT94p3hzfXRG4GR5EVUgjZb_g9ML-',
            // remitChannelService.findById
            FIND_BY_ID: 'mPG133vrioeP8pz03uYOi89GvBAxsY0ygHydGwjxNKg',
            // remitChannelService.create
            CREATE: 'D76_93SzqBbXrV9Jy1NpKmZyL3G50gKx48DAm1V',
            // remitChannelService.update
            UPDATE: '9JzKR5osk6UeUKoGD4IvDjTAEJCqtaVqVtu9pwb',
            // remitChannelService.status
            CHANGE_STATUS:'i9p2iIgaY2KqJ1h5xo0c_x406uribOPhKM6wqUI',
            // remitChannelService.status.batch
            CHANGE_STATUS_BATCH:'OaLgPMIc9T5oUCf8eHpMkRcYYOJzseQprbW-H-hLd3oOpV1'
        }
    },

    //付款类型配置板块
    FINA_PAY_TYPE_CONFIG: {
        // /biz/t8t-fi-pvm/app
        name: 'VmHS1srPCZUThqolu6uXm3c_R-lSOfL',
        methods: {
            // remitTypeService.query
            QUERY: '3GeQrUVKAUW8hQtTbFNPNRNt3rbPBoidL88',
            // remitTypeService.queryPage
            QUERY_PAGE: 'ktbvPbakcWMLuHudH8merrgY7mhfdqTfKUR-eJn',
            // remitTypeService.findIdsCodesAndNamesById
            FIND_BY_ID_NAMES: 'FhSlap_LMFdUBlRuPeVQdMUPxmCQxjPWRwIwpcDP28YZeR2SO0ic0GxMCIq',
            // remitTypeService.findById
            FIND_BY_ID: 'YxP7pnRekXgJecyhssubxffkMH1qjJdZveRVM6R',
            // remitTypeService.create
            CREATE: 'XzOIzmkfaoUQGdPvh3VztemL_vp0bXlWLM7',
            // remitTypeService.update
            UPDATE: '-UFdNK-EfAE1bIYFmAEYFHCpoPzBDKq6K00',
            // remitTypeService.status
            CHANGE_STATUS:'q_0K5vby3R3OGfEwNqsGFxyxWS1QjNr9ktL',
            // remitTypeService.status.batch
            CHANGE_STATUS_BATCH:'NV3aGKEH9041VECj0PzRbUUI0mfQ54T-LrcFFioNlRv'
        }
    },

    //付款方式分配板块
    FINA_PAY_METHOD_DISTRIBUTION: {
        // /biz/t8t-fi-pvm/app
        name: 'VmHS1srPCZUThqolu6uXm3c_R-lSOfL',
        methods: {
            // channelDistributionService.queryPage
            QUERY_PAGE: 'PDYXigvrlf7ajmDL3gQsOsq9b2VbTvTwTzkwZ0WcMyTdsJKOcnc',
            // channelDistributionService.findIdsCodesAndNamesById
            FIND_BY_ID_NAMES: 'OaSTSGwJMzIMKlxoJK5rB3Xm7cxWLe8XGWKdyNWbSK2cETY-eQpoDhkwMoYDcpeLOt5CFUb',
            // channelDistributionService.create
            CREATE: 'juanhuHzqrNe2V-buijCAV_r1jzb0l0mifAQJ2lwUdRdXit',
            // channelDistributionService.update
            UPDATE: 'AjHFGpOhNGe6_DRoXEv0dKsJayDN1Q2QvQyNZ5Y2CpR-78N',
            // channelDistributionService.status
            CHANGE_STATUS:'-O4395Q7uum_HM7Zw9vb1d7Ru8j4G8vUtrg7mEDhd350d3G',
            // channelDistributionService.status.batch
            CHANGE_STATUS_BATCH:'4Ytxp0WG9TccM5HxC418mV_S19pCuSHry8GoWkM7UxDpXjBoHrwopq4',
            // channelDistributionService.query
            QUERY: 'iT3726WuxMaD3PqKxzbm_6c_KvCWJ7kwzEwP.sF50fCyB_U'


        }
    },

    //操作记录获取接口
    LOG_SERVICE: {
        // /biz/t8t-sys-opl/app
        name: "BtRjXvD_I-d1jvvBZNDmSK3apNL_67b",
        methods:{
            // queryPage
            QUERY_PAGE: "AK1xE_JF3yW56Bc"
        }
    }
}

export default Services
