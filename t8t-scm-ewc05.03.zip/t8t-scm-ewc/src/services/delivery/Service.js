//交付模块接口
let Services = {
    TEMPLATE:{
        ///biz/t8t-ps-pmd/app
        name: 'rk2RJ6Qwg5g0AL966MJ2RE5jlMKzsKr',
        methods: {
            QUERY: '1JRusrk7_hen1kdQc9juE-erLIuqPI_sZMwgjZG', //schedule.module.queryPage
            CREATE: 'sxa1kfPFmVTrllG1gniw1Gza9iUV_oQP9Kp', //schedule.module.create
            UPDATE: 'yftIu5zW_u8Au_P5C_Ha70H1F8oDmYTB4ST', //schedule.module.update
            GETBYID: 'oNrBxieCL7QdH7hV-9f5xrEu8pjGEifSDpqTnHif1dZ8t9w', //schedule.moduleRedundancy.getById
            SETMODULESTATUS: 'rOf6dog2zbjDcYsMohZOx0j4blvVOApFq1VlBogWA9mJVzlsItI', //schedule.module.batchSetModuleStatus
            QUERYMODULEANDMODULEITEMBYID: 'IS6Y23AS5j1hJBZP6KFSRnU1S6GmXw3wSIycS_3lAAGaFMzPCzK_Q3_L2oz2Cst', //
            queryModuleQuotaionById: 'dPfrxviIqhIMWvhrQ40ZKmk5INyoc_ZY-qypF8XwWIvJudCsJ_IgVr5', //schedule.module.queryModuleQuotaionById
            moduleItemQueryPage: 'PpDcN4DlKlEP_JIuY8o1hYFNFZ9Epg8G2WQG1A4mHNz', //schedule.moduleItem.queryPage
            scheduleRef:'qxX2gkmJBXScponPosTrRCVgL1ZfRxlfEFghecoCfwlUGcXRM8M', //schedule.quotation.queryByModuleId
            scheduleRefUpdate:'4h7DHE09R71yAgM2wcG830QFEYc5SlBMk_Y0yuDJGtQ', //schedule.quotation.batchUpdate
            NodeRelation:'2kmQDwvgJgRtY4GXBNWBf_AwR5P1z0T1fvRKwae2Vfjy_zTyxzBy6dw', //schedule.moduleItemRelation.queryPage
            NodeRelationSave:'Z9U0pfzJEVBQoWlKfYRBiZed1kNYfWGC_vpje4pG3KokykJ', //schedule.moduleItemRelation.save
            referenceRelation:'DKfN2E_92Wwp8E_s7Vy3pobuoiUyMmK8_fclNLi-Z4Jtr7w-hVj', //schedule.quotation.queryByModuleId
            itemBillQueryPage: '3JQAfbU5ybYChd3qO4iqdkEuJI0haZ8xr5Xevws', //schedule.moduleItemRelation.queryPage
            moduleItemSave: 'WGGygmLAiCc5imExpQ8fiQbsrMdE67_Ufks', //schedule.moduleItem.save
            itemBillSave: 'i6MaJIV8M6XHtefQYdc5vfFieO6LMn9NT_E',
            queryPagePqmQuotaion: 'WvDKL8HrApLhQPkVTIcSlfEdnn_N_eT394cS8ynNJ_uRZDHQMiR', //schedule.module.queryPqmQuotaion
        }
    },
    PROPERTY:{
        ///biz/supply-chain/app.supply-server
        name: '8m7ufp84fb2V0f5Z0e1LiSKvI9wfWGyPcR5O8IydTmjLcK9YcKE',
        methods:{
            propertyQueryPage:'xxyFxYonI0x3Fv7Po3D98lC_z76' //property.queryPage
        }
    }
};

export default Services
