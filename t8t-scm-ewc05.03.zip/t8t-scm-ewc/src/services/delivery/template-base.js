import axios from 'src/utils/axios.js'
import Service from './Service.js'

export default {
    getById(args) {
        return axios({
            method: Service.TEMPLATE.methods.GETBYID,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    create(args) {
        return axios({
            method: Service.TEMPLATE.methods.CREATE,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    update(args) {
        return axios({
            method: Service.TEMPLATE.methods.UPDATE,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    setModuleStatus(args){
        return axios({
            method: Service.TEMPLATE.methods.SETMODULESTATUS,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    queryModuleQuotaionById(args) {
        return axios({
            method: Service.TEMPLATE.methods.queryModuleQuotaionById,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    moduleItemQueryPage(args) {
        return axios({
            method: Service.TEMPLATE.methods.moduleItemQueryPage,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    queryQuoteList(args) {
        return axios({
            method: Service.TEMPLATE.methods.queryPagePqmQuotaion,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    moduleItemSave(args) {
        return axios({
            method: Service.TEMPLATE.methods.moduleItemSave,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    propertyQueryPage(args) {
        return axios({
            method: Service.PROPERTY.methods.propertyQueryPage,
            service: Service.PROPERTY.name,
            args: args
        })
    },
    itemBillSave(args) {
        return axios({
            method: Service.TEMPLATE.methods.itemBillSave,
            service: Service.TEMPLATE.name,
            args: args
        })
    },
    itemBillQueryPage(args) {
        return axios({
            method: Service.TEMPLATE.methods.itemBillQueryPage,
            service: Service.TEMPLATE.name,
            args: args
        })
    }
}
