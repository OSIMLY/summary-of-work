import axios from 'src/utils/axios.js'
import Service from './Service.js'

export default {
    // 辅助资料配置接口
    allSystemCodeList(args) {
        return axios({
            method: Service.CONFIGURE.methods.SYS_CODE_LIST,
            service: Service.CONFIGURE.name,
            args: args
        })
    },
    // 辅助资料查询某个父节点的下一级非禁用节点集
    listNextLevelUnforbidden(args) {
        return axios({
            method: Service.CONFIGURE.methods.LIST_UNFORBIDDEN,
            service: Service.CONFIGURE.name,
            args: args
        })
    },
    // 供应链辅助资料
    queryUnionParent(args) {
        return axios({
            method: Service.SUPPLY_CONFIGURE.methods.queryUnionParent,
            service: Service.SUPPLY_CONFIGURE.name,
            args: args
        })
    },
    // 通过组织职能查询组织，暂时只支持或的关系
    queryByFunctionCode(args) {
        return axios({
            method: Service.ORGANIZATION.methods.QUERY_BY_FUNCTIONCODE,
            service: Service.ORGANIZATION.name,
            args: args
        })
    },
    // 获取全部组织
    queryAll(args) {
        return axios({
            method: Service.ORGANIZATION.methods.ORG_QUERY,
            service: Service.ORGANIZATION.name,
            args: args
        })
    }
}
