// 财务模块
let Services = {
    // 辅助资料
    CONFIGURE: {
        // /biz/to8to-it/app.tit-configure
        name: 'OnLYil9jY0PiKilsavskNJvygGUxhME7eLPWccmGmYjb_ED',
        methods: {
            // systemCode.list
            SYS_CODE_LIST: 'vPnFi_QA4HeBWeU61ZjQPCn',
            // systemCode.listNextLevelUnforbidden
            LIST_UNFORBIDDEN: 'vL0y_oFhAeDM3YTmFrp2oaHn1UDcQEzq1orWi41sEc2pVcjlpGN'
        }
    },
    // 供应链辅助资料
    SUPPLY_CONFIGURE: {
        // /biz/supply-chain/app.supply-server
        name: 'qVq5B_KUuBzTC3kyP9TiuA53IS1kiBn5fR5JVjR7fUS6nsTm4Zc',
        methods: {
            // property.queryPage
            QUERY_PAGE: 'Ewi6YId8aELgLHFBBSBMT4BvG3R',
            // property.queryUnionParent
            queryUnionParent: '5l6jR2KUJ4QdYxLFz0ZJGFy5XZkLajNNSEdLf0t',

        }
    },
    // 组织架构
    ORGANIZATION: {
        // /biz/to8to-it/app.account
        name: 'UTf-nq7ZR1Q7Ql5_QqDxLUq5dV3xyq94Rx4kKaU',
        methods: {
            // organization.queryByFunctionCode
            QUERY_BY_FUNCTIONCODE: 'UwBgld0zWv.T_KSfK6W2_uSPCGXiv-mkEbmTNx6qeGoR_hH',
            // organization.query
            ORG_QUERY: 'DOiN6_9fU1yNwZE_gRuTrdwwvEg'
        }
    }

}

export default Services
