// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import store from './store'
import router from './router'

import ElementUI from './components/element-ui/lib/index.js'
import './components/element-ui/lib/theme-default/index.css'
// 皮肤覆盖文件
import './components/element-ui/erp-theme.css'
// t8t组件全局注册
import T8tTree from 'src/components/t8t-tree/t8t-tree.vue'
Vue.component('T8tTree', T8tTree)
import T8tBreadcrumb from 'src/components/t8t-breadcrumb/t8t-breadcrumb.vue'
Vue.component('T8tBreadcrumb', T8tBreadcrumb)
import T8tTable from 'src/components/t8t-table/t8t-table.vue'
Vue.component('T8tTable', T8tTable)
import T8tToolbar from 'src/components/t8t-toolbar/t8t-toolbar.vue'
Vue.component('T8tToolbar', T8tToolbar)
import T8tSearch from 'src/components/t8t-search/t8t-search.vue'
Vue.component('T8tSearch', T8tSearch)
import T8tFormPanel from 'src/components/t8t-form-panel/t8t-form-panel.vue'
Vue.component('T8tFormPanel', T8tFormPanel)
import T8tGallery from 'src/components/t8t-gallery/t8t-gallery.vue'
Vue.component('T8tGallery', T8tGallery)
import T8tFormPopup from 'src/components/t8t-form-popup/t8t-form-popup.vue'
Vue.component('T8tFormPopup', T8tFormPopup)


import VueProgressBar from 'vue-progressbar'
Vue.use(VueProgressBar, {
    color: 'rgb(119, 182, 255)',
    failedColor: 'red',
    height: '2px'
})

import App from './App'
import Filter from './utils/filter'

Vue.use(ElementUI)

Vue.config.silent = true

var app = new Vue({
    el: '#app',
    template: '<App/>',
    components: { App },
    store,
    router
})
